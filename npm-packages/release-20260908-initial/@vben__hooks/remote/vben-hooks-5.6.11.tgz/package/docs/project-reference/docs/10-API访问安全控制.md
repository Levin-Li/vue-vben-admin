# API 访问安全控制

本文说明已有访问控制能力。开发与验收须同时遵循 [安全开发规则](../20-安全开发规则.md) 的通用基线及 [后端开发规则](../10-后端开发规则.md) 的数据访问要求；API 变更使用 [API安全审计模板](API安全审计模板.md)。URL 访问控制、验证码和限流不能替代目标数据及字段授权。

#### 一、模块说明

     可以实现动态控制API的访问,比如临时禁用API,或是临时开放API,或是临时加强访问验证,如要求短信验证码,谷歌验证码等等。
     可区分,租户,域名和全局配置.

##### 1.1 API访问拦截&配置

      控制器访问拦截:  com.levin.oak.base.interceptor.UrlAclInterceptor, 通过系统设置表进行配置.
                     配置属性参考: com.levin.oak.base.biz.bo.commons.UrlAcl

      控制器验证码拦截:  com.levin.oak.base.interceptor.DynamicVerificationInterceptor, 通过系统设置表进行配置.
                     配置属性参考: com.levin.oak.base.biz.bo.commons.DynamicVerifyCodeAcl

API 动态验证码的完整设计、前后端流程、实现类和使用方式见 `docs/13-API动态验证码设计使用指南.md`。

##### 1.2 本地控制台启停保护

`admin-bootstrap` 和 `client-bootstrap` 的 `/local/console/stop`、`/local/console/start` 只用于本机运维控制，不是普通管理 API。两个条件必须同时满足才会改变阻断状态：

1. 请求的真实远端地址是 loopback（例如 `127.0.0.1` 或 `::1`）。`Host` 头不能作为可信条件。
2. 应用配置了非空 `localConsoleControlToken`，且请求头 `X-Local-Console-Token` 与该值恒定时间比较相等。

未配置 token 时，该控制能力默认关闭。不要把 token 放进前端代码、页面 URL、日志或版本库；通过本机环境变量、受保护的配置中心或部署密钥注入。完整登录挑战与 MFA 安全约束见 `docs/15-密码登录挑战与MFA安全开发指南.md`。
