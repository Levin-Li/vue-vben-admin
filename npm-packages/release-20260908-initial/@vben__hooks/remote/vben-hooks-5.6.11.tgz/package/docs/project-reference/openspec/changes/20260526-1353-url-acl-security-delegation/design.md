# Design: URL ACL Security Delegation

## Boundary

`ClientAppAuthFilter` is intentionally not part of this flow. That filter authenticates a third-party client application and logs the request in as a bound service user. URL ACL signature verification and data crypto are different concerns: they protect selected URL requests according to `UrlExAcl` policy and must not implicitly create a login token or depend on client-app authentication.

## Flow

```
request
  -> normal web filters
  -> UrlAclInterceptor matches UrlExAcl rules
  -> SignVerify/DataRsaCrypt delegates to UrlAclSecurityService
  -> controller runs only when the delegated action passes
```

## Security Manifest

`BizUrlExAclController` exposes a public manifest endpoint for clients to discover which URL patterns currently require signature or data crypto handling. The manifest is a client-side optimization and protocol hint; the server still enforces the active `UrlExAcl` rules on every request.

The first client implementation may keep the manifest in memory only. The response includes `version`, `generatedAt`, and `ttlSeconds`; clients refresh after expiration or after receiving a server response that advertises a different manifest version.

The manifest endpoint itself must not require `SignVerify` or `DataRsaCrypt`, otherwise clients could not discover the rules needed to protect later requests.

The manifest must never include secrets, private keys, or decrypt keys. It may include only rule matching information, protocol names, algorithm identifiers, TTL, and version metadata.

## Service Contract

Add a dedicated URL ACL security service in the web/security boundary. The interceptor passes request context and the matched ACL; the service owns signature and crypto protocol decisions.

Suggested methods:

```
boolean verifySignature(operator, acl, request, response, tenantInfo);
boolean handleDataCrypto(operator, acl, request, response, tenantInfo);
```

## Signature Verification

`SignVerify` should validate request-level signature material supplied by the caller, such as timestamp, nonce, request body digest, and signature. Key lookup should be explicit and configurable for this URL ACL security mechanism; it should not infer success from `ClientAppAuthFilter`.

Possible later key sources:

- `acl.exInfo` for a simple shared secret or key reference.
- A dedicated URL ACL credential table if multiple callers or key rotation are required.
- A named Spring bean resolver when deployments need custom key lookup.

## Data Crypto

`DataRsaCrypt` should delegate to the same service boundary, but actual request-body decryption and response encryption may require a filter or request/response wrapper. The ACL decides when crypto is required; the delegated service/filter owns how crypto is performed.

## Concrete Protocol

The implementation must provide an executable default protocol rather than a pass-through placeholder.

### Signature

Request headers:

- `X-UrlAcl-Client-Id`: client credential id.
- `X-UrlAcl-Timestamp`: epoch milliseconds.
- `X-UrlAcl-Nonce`: per-request nonce.
- `X-UrlAcl-Body-Sha256`: lowercase hex SHA-256 of the request body bytes.
- `X-UrlAcl-Signature`: lowercase hex HMAC-SHA256.

Canonical string:

```
METHOD
path
queryString
timestamp
nonce
bodySha256
```

The default key source is `ClientApp.appSignSecret` looked up by `clientId` and tenant. This reuses the credential data only; it must not use `ClientAppAuthFilter` or create/login an operator. The signing service must reject missing headers, stale timestamps, duplicate nonce, disabled/missing client apps, body hash mismatch, and signature mismatch.

### Data Crypto

Request headers:

- `X-UrlAcl-Client-Id`: client credential id.
- `X-UrlAcl-Crypto`: `AES_GCM` or compatibility alias `RSA_AES_GCM`.
- `X-UrlAcl-Crypto-Iv`: base64 12-byte GCM IV.
- `X-UrlAcl-Plain-Content-Type`: optional decrypted request content type; defaults to `application/json`.

The default executable implementation derives an AES-256 key from `ClientApp.appSignSecret`, expects the encrypted request body to be base64 AES-GCM ciphertext, decrypts it in a servlet filter before MVC request binding, and encrypts successful 2xx response bodies back to base64 AES-GCM ciphertext. Response headers include `X-UrlAcl-Crypto`, `X-UrlAcl-Crypto-Iv`, and `X-UrlAcl-Crypto-Content: base64`.

## Compatibility

Missing `UrlAclSecurityService` remains pass-through for compatibility in tests or partial application contexts. In a normal Spring context the default executable service is present and enforces the signature/crypto gates above.

## Demo Defaults

Module data initialization should create a public Demo-only client credential, two public URL ACL rules, and a public Demo traffic-control sample rule for the Demo request-body test endpoint pattern:

- Client app id: `demo-url-acl-client`.
- Demo URL pattern: `/com.levin.oak.base/V1/api/Demo/testRequestBody*`.
- URL ACL rules: one `SignVerify` rule and one `DataRsaCrypt` rule, both limited to `POST`.
- Traffic-control rule: one fixed-window sample rule, limited to `POST`, with a rule-level bucket.

These defaults are demo/sample configuration only. They must be created by `ModuleDataInitializer` rather than a separate Spring initializer, must not use `ClientAppAuthFilter`, must not require a login, and must be idempotent so repeated startup does not create duplicate rules. All initialized path matchers must point at Demo business controller endpoints rather than real business APIs, because the Demo module is intentionally not an operational business surface. The full-chain verification should use the Demo URL pattern rather than an unrelated simulated business path.
