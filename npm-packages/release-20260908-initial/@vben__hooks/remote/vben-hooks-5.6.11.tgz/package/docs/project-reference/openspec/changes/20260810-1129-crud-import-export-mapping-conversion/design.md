# Design

## Mapping model

Import mappings continue to bind a source file header to one writable CRUD field. A mapping records the target field, source header, converter, optional default value, and required flag.

Export mappings build on the existing selected field list. Each mapping retains the source CRUD field key, output header alias, order, selection, and an optional converter. The selected source field remains explicit in the shared field list; a header alias is the external column mapping.

Both mapping forms are stored in `ImportExportTemplate`; new optional properties are backwards-compatible so existing saved templates continue to work.

## Conversion boundary

Supported conversions are fixed values selected in the dialog, never user-provided code:

- `display` (export default): current table display value.
- `string` and `trim`: retain raw text or trim whitespace.
- `number`: require a finite number.
- `boolean`: accept the existing explicit boolean literals.
- `date`: parse an ISO-like or spreadsheet date and serialize `YYYY-MM-DD`.
- `datetime`: parse an ISO-like or spreadsheet date/time and serialize `YYYY-MM-DD HH:mm:ss`.
- `json`: parse valid JSON for imports and serialize values for exports.

Empty values remain empty. Conversion failures are reported during import preview and block batch submission. Export uses the selected conversion deterministically and falls back to existing display behavior when no conversion is configured.

## Spreadsheet parsing

The browser parser reads the first worksheet from a normal `.xlsx` ZIP archive using built-in browser primitives. It resolves shared strings, inline strings, numeric cells, and date serial values into the existing `ParsedImportSheet` shape. Unsupported or malformed workbooks show a concrete parse error. CSV, XML Spreadsheet, and HTML-table behavior is unchanged.

## Safety and compatibility

No backend import endpoint, external dependency, or script conversion is introduced. Permission and `batchCreate` gates remain unchanged. The import/export configuration modal remains non-dismissable by its mask.
