# c20260907-1545-fix-layout-content-scroll

Prevent common admin pages from showing a vertical scrollbar when their content fits.
