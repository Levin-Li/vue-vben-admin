# c20260902-1829-prevent-breadcrumb-wrapping

管理后台面包屑保持单行并在宽度不足时隐藏溢出内容。
