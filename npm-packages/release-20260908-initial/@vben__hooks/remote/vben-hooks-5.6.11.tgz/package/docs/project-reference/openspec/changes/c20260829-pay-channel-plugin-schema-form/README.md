# c20260829-pay-channel-plugin-schema-form

Use currency-scoped payment plugin providers to render PayChannel configuration schemas
