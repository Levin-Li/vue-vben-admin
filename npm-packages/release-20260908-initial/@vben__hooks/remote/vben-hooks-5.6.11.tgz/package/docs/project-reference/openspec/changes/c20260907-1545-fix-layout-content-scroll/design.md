# 设计

`VbenLayout` 的主内容区域是固定顶栏之后唯一应承担页面级滚动的 flex 子项。当前 `LayoutContent` 只有 `flex: 1`，未显式允许收缩，也未定义页面级 `overflow-y` 边界；页面根节点的 `min-height: 100%` 与内容外边距会参与高度计算，导致微小溢出落在不稳定的祖先元素上。

`LayoutContent` 将显式设置 `min-height: 0`、`overflow-y: auto` 和 `overflow-x: hidden`。这样 flex 布局能把它收缩到顶栏以下的实际可用高度，只有 `scrollHeight > clientHeight` 时才显示纵向滚动条。表格和弹窗继续管理各自的内部滚动区域。

该修复位于 `@vben-core/layout-ui` 的实现源中，并随 `@vben/layouts` 对外分发；不在每个 CRUD 页面增加局部补丁。
