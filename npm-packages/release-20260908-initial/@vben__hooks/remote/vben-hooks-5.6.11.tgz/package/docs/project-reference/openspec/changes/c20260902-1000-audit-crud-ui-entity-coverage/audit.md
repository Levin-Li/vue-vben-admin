# 管理 CRUD 页面审计清单

审计时间：2026-09-02。依据 `admin-crud.ts` 路由资源、各页面 `config.ts` 的 `apiBase`/服务类、对应服务类的 `controllerClass` 和 `Biz*Controller` 注解完成静态核对；浏览器验收只针对当前超级管理员实际出现 CRUD 入口的关键页面。

## 已绑定的标准 CRUD 页面（56）

`AccessLog`、`Address`、`ClientApp`、`Area`、`OpenArea`、`TenantCustomMenu`、`Article`、`ArticleChannel`、`Brand`、`Customer`、`Demo`、`Dict`、`Domain`、`EContract`、`EContractTemplate`、`EInvoice`、`EInvoiceProviderConnection`、`DomainSslCert`、`FileRes`、`FundAccount`、`FundAccountLog`、`FundExchangeRule`、`I18nRes`、`ImportExportTemplate`、`JobPost`、`Menu`、`Nation`、`Notice`、`NoticeProcessLog`、`OnlineCodeGen`、`Org`、`LegalSubject`、`PayChannel`、`PayOrder`、`Partner`、`RbacPermissionItem`、`Role`、`ScheduledLog`、`ScheduledTask`、`ServicePlugin`、`ServicePluginSetting`、`EmailRelayRoute`、`Setting`、`UiSetting`、`GlobalOrgSelectorSetting`、`SimpleApi`、`SimpleForm`、`SimplePage`、`SocialUser`、`Tenant`、`TenantApp`、`TenantSite`、`TrafficControlRule`、`UrlExAcl`、`User`、`UserSetting`。

- 标准页面的 `apiBase` 与相应服务类的 `controllerClass` 一致。
- `GlobalOrgSelectorSetting` 是唯一有意复用的例外：页面限定 `UiSetting` 的固定编码、编辑器和类型，仍由 `BizUiSettingController` 处理。
- `@DisableApiOperation` 禁用的操作不应由页面强行补出；按钮最终以当前账号运行时权限为准。

## 非标准 CRUD 配置页面（5）

`PaymentSimulationWorkbench`、`TenantPluginSetting`、`SettingForTenant`、`MySetting`、`OrgUser` 均为明确的自定义视图，没有独立的通用 `config.ts`。它们不因实体或路由存在而被当作缺失 CRUD 页面补造。

## 字段与动作结论

- `UiSetting` 与 `TenantCustomMenu` 都展示并提交 `orgCategory`、`orgType`、`userCategory`、`userType`；选项源分别对应 `Org.category`、`Org.Type`、`User.Category` 与 `User.type`。
- `GlobalOrgSelectorSetting` 同样保留上述覆盖范围字段，并固定提交 `code`、`editor`、`type`。
- `orgType` 使用 `Org.Type` 枚举常量名持久化；空值仍表示任意组织类型，运行时解析和菜单匹配按精确值优先、空值兜底处理。
- `OpenArea` 对齐 `tenantId`、`orgId`、`domain`、`areaCodeList`、`expiredTime`、`enable`、`exInfo` 等实体语义；JSON 字段使用 JSON 编辑入口。
- 浏览器中，`UiSetting`、`TenantCustomMenu`、`OpenArea` 均出现新增、编辑、删除动作并完成实际闭环。`GlobalOrgSelectorSetting` 对当前超级管理员返回“访问被拒绝”，因此不是本次可执行 CRUD 验收对象。

## 本次修复与测试

- 页面展示设置作用域从旧 `orgType` 收口为 `orgCategory`，并把用户类别和用户类型纳入作用域和缓存键。
- 为重点页面补充配置测试；相关 Vitest 42 项和 `build:admin-modules` 均通过。
