# c20260825-0843-limit-detail-tenant-context-to-platform-users

公共 CRUD 按平台身份控制新增和编辑的租户归属，并移除基于 ID 的详情、删除请求中的 tenantId
