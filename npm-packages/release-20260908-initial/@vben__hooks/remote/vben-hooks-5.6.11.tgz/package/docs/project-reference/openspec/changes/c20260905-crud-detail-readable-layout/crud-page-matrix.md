# 标准 CRUD 页面改造与验收矩阵

本矩阵用于第 36 节的并行改造、验收分工和收口。普通 CRUD 指查询、新增、编辑、详情、删除；专用扩展操作表单不改动。新增、编辑、删除是否可用以控制器权限与真实环境为准，不以当前静态配置默认值推定。

## 共享层

| 范围 | 负责人 | 验收 |
| --- | --- | --- |
| `admin-framework` 共享 `CrudPage`、展示设置、请求过滤、表单规则 | 主任务 | 全部标准页面继承规范；不修改页面专用扩展表单 |
| 真实后端、开发数据库、登录和浏览器验收脚本 | 主任务 | 固定可清理的测试数据和账号，逐页真实增改删 |

## 页面改造批次

| 批次 | 标准 CRUD 页面 | 特别处理 |
| --- | --- | --- |
| A：基础资料 | address、area、brand、customer、demo、nation、job-post、legal-subject、i18n-res、dict、article-channel、article | Dict 的条目管理属于字段槽，不改其专用扩展操作 |
| B：业务与交易 | email-relay-route、fund-account、fund-exchange-rule、import-export-template、notice、notice-process-log、partner、pay-channel、pay-order、traffic-control-rule、url-ex-acl、client-app | 保留各页字段槽；只改标准表单和请求链路 |
| C：平台与内容 | domain、domain-ssl-cert、electronic-contract-template、electronic-invoice-provider-connection、file-res、open-area、rbac-permission-item、scheduled-task、service-plugin、service-plugin-setting、social-user | 不改 DNS、签发、供应商、文件预览等专用操作表单 |
| D：身份与租户标准部分 | role、user、org、org-user 的嵌入用户 CRUD、tenant、tenant-app、tenant-site、global-org-selector-setting、setting、ui-setting、user-setting | 不改权限分配、角色分配、数据权限、MFA、设置值编辑、DNS 或租户扩展操作；tenant-plugin-setting 基本信息暂缓至最后单独验收 |

## 不纳入标准 C/U/D 成功要求的页面

| 页面 | 原因 |
| --- | --- |
| access-log、fund-account-log、scheduled-log、online-code-gen | 当前页面显式只读或不提供完整 C/U/D |
| menu | 自定义菜单与页面操作工作台；其专用表单不在此次范围 |
| simple-api、simple-form、simple-page | 内容/脚本专用工作台，不使用通用 CRUD 表单 |
| data-permission-preview、dev、home、my-messages、my-setting、payment-simulation-workbench、setting-for-tenant、tenant-custom-menu | 非标准实体 CRUD 或专用扩展工作台 |
| electronic-contract、electronic-invoice、pay-order | 控制器显式禁用通用新增、编辑、删除，采用申请、签发、红冲、对账、支付等状态机语义操作；不应解除业务保护来伪造普通 CRUD。 |

## 验收协议

每页使用运行批次唯一标识创建可清理记录；重新查询定位记录；编辑非主键业务字段并刷新回读；删除记录并确认查询不到。禁止删除既有业务或基准数据。外键、不可删除实体或后端明确禁用 C/U/D 的页面须记录为例外，不伪造成功。

## 已完成真实浏览器 C/U/D

| 页面 | 结果 | 备注 |
| --- | --- | --- |
| address、area、article、article-channel、brand、client-app、customer、demo、dict、domain、domain-ssl-cert、electronic-contract-template、email-relay-route、file-res、fund-account、fund-exchange-rule、i18n-res、import-export-template、job-post、legal-subject、nation、notice、notice-process-log、open-area、org、partner、pay-channel、rbac-permission-item、role、scheduled-task、service-plugin-setting、setting、social-user、tenant、tenant-app、tenant-site、traffic-control-rule、ui-setting、url-ex-acl、user、user-setting | 通过 | 共 41 页均使用唯一验收数据完成创建、编辑、删除和清理；notice、article、article-channel 和 fund-exchange-rule 为软删除，删除后确认操作入口消失。法律主体和合作伙伴同时验证了带租户、组织、个人范围 ID 请求的 CTE 兼容链路。 |

## 已完成视觉截图与 UI 设置入口验收

视觉脚本按资源单页运行，真实登录后生成 `page-display-settings.png`、`create.png`、`edit.png`、`detail.png`；长表单及长设置抽屉按滚动位置追加连续编号图片。最终截图根目录为 `frontend/admin/.codex-run/crud-visual-audit-20260906-final-complete-v2/<资源>/<run-id>/`。脚本只读打开页面展示设置，确认五个视图页签和新增页的展提、隐提、禁提、不提；不新增分组、不保存草稿、不修改任何运行时 UI 设置。分组可见角色、展示脚本的保存回显和请求过滤由共享层定向测试覆盖，实际配置只由用户在运行时设置。

| 页面 | 视觉截图 | UI 设置入口 | 结果 |
| --- | --- | --- | --- |
| address、area、article、article-channel、brand、client-app、customer、demo、dict、domain、domain-ssl-cert、electronic-contract-template、email-relay-route、file-res、fund-account、fund-exchange-rule、i18n-res、import-export-template、job-post、legal-subject、nation、notice、notice-process-log、open-area、org、partner、pay-channel、rbac-permission-item、role、scheduled-task、service-plugin-setting、setting、social-user、tenant、tenant-app、tenant-site、traffic-control-rule、ui-setting、url-ex-acl、user、user-setting | 每页页面设置、创建、编辑、详情，长内容有连续截图 | 五页签、创建页展提/隐提/禁提/不提 | 通过；新建测试记录均在截图后删除。 |

截图归档由两次真实运行组成：`frontend/admin/.codex-run/crud-visual-audit-20260906-complete-forms/` 覆盖首批 40 页的完整表单滚动截图；`frontend/admin/.codex-run/crud-visual-audit-20260906-final-complete-v2/` 补充合作伙伴以及页面设置抽屉滚动截图。两处均按 `<资源>/<run-id>/` 保存，包含 `page-display-settings.png`、`create.png`、`edit.png`、`detail.png`，长内容追加连续编号图片。

## 待完成真实 C/U/D 的标准页

| 页面 | 当前条件 | 后续验收前提 |
| --- | --- | --- |
| electronic-contract、electronic-invoice、electronic-invoice-provider-connection | 依赖已认证主体、模板或供应商连接 | 在本地模拟器及可清理依赖记录完整后执行；不调用正式供应商。 |
| pay-order | 涉及支付状态机与支付通道 | 使用本地模拟支付且不触发真实收款后执行。 |
| service-plugin、service-plugin-setting | 服务插件元数据和供应商配置 | 保持专用配置值编辑不改，只验证可清理的普通元数据 C/U/D。 |
| global-org-selector-setting | 固定编码的单例配置页，当前无新增入口 | 保留为受限单例配置；需先确认允许创建临时作用域实例后才能做 C/U/D。 |
| org-user、tenant-plugin-setting | 嵌入用户或专用工作台混合语义 | 在临时组织/租户作用域验证基础记录，保留扩展操作不动。 |

## 尚未纳入三表单视觉截图的页面边界

| 页面 | 当前视觉验收边界 | 原因 |
| --- | --- | --- |
| electronic-invoice-provider-connection、pay-order、electronic-contract、electronic-invoice | 流程例外，不能伪造普通三表单截图 | 新增、修改或删除分别映射激活、开票、签约、红冲、对账或支付状态机，控制器已禁用通用 C/U/D。 |
| service-plugin | 管理台工作台例外 | 常规记录操作和供应商配置编辑混合，不能以普通新增/删除替代插件生命周期。 |
| global-org-selector-setting | 单例设置页例外 | 固定编码作用域配置，没有独立新增记录语义。 |
| org-user、tenant-plugin-setting | 组合/专用工作台例外 | 前者是组织树与内嵌用户管理，后者绑定租户插件配置；须分开覆盖基础表单和专用操作。 |
