# c20260903-1030-document-fsm-enum-standard

固化以 SimpleFlowStatus 为基线的有限状态机枚举开发规范
