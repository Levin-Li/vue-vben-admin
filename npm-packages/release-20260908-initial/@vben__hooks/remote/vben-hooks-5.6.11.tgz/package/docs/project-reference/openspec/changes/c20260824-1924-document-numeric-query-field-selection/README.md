# c20260824-1924-document-numeric-query-field-selection

明确 CRUD 查询表单中数值字段的默认筛选策略
