# c20260824-1934-select-tenant-site-domain-for-custom-menu

让租户自定义菜单的域名字段从租户站点中可搜索选择
