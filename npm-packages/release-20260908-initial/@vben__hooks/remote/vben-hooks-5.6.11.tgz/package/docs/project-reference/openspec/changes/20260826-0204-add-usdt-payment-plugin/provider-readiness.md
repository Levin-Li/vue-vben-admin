# USDT 供应商准入清单

所有真实通道默认禁用。只有本清单对应项全部确认、凭据以运行时密钥引用配置且 Sandbox 验收通过后，才能启用该通道。

| 供应商 | 商户准入 | 支付方式与订单查询 | 回调策略 | 当前状态 |
| --- | --- | --- | --- | --- |
| NOWPayments | 完成商户开户/KYB，创建 API Key 和 IPN Secret | 确认该主体可用的 USDT 网络代码；创建 payment 后保存 payment ID、收款地址、实际应付金额与过期时间；用同一 API Key 查询 payment | IPN Secret 验签，随后按 payment ID 主动查询 | 待提供 Sandbox 凭据与网络清单 |
| CoinPayments | 创建 API integration，取得 client ID 与 client secret，并确定 API instance | 从 currencies API 取得 USDT 的网络、合约、精度与确认数；创建 merchant invoice/付款请求并保存 invoice/payment ID | 使用原始请求体和 `X-CoinPayments-*` 头做 HMAC-SHA256；确认事件可多次递增 | 待提供 Sandbox/生产 instance 与凭据 |
| BitPay | 完成商户账户配置，取得 POS 或 merchant facade token | 创建 invoice 时锁定允许的 USDT 资产与 transaction speed；保存 invoice ID 与 URL | Webhook 只作触发器；必须 `GET invoice` 回查终态，不能直接相信 body | 待确认商户账户支持的 USDT 网络与 Sandbox token |

## 运行时配置约束

- `PayChannel.detailInfo` 只能保存 endpoint、merchant ID、网络、资产标识、确认数和**密钥引用名**；不得保存 API key、client secret、私钥或助记词明文。
- 密钥引用由部署环境注入；开发、测试和生产环境使用不同的引用名。
- 一个通道只允许一个明确的 USDT 网络和资产标识。多网络必须创建独立通道，避免付款人误转链。
- 每次启用前执行：创建支付指令、查询 pending、签名回调、重复回调、确认数递增、过期和错误网络/金额测试。

## 必须交付给实施的材料

1. 公司注册地与商户账户允许服务的国家/地区。
2. 每家供应商的 Sandbox 商户凭据，以密钥管理系统的引用名提供，不发送明文到聊天或代码库。
3. 每家供应商允许的 USDT 网络、合约/资产 ID、decimals、最小确认数及付款过期时间。
4. 对外可访问的 HTTPS 回调基础地址和供应商允许配置的回调 URL。
