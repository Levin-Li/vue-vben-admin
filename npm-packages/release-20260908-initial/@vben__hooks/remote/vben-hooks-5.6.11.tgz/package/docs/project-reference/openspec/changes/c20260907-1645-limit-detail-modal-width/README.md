# c20260907-1645-limit-detail-modal-width

Cap the shared CRUD detail modal width so wide displays do not create excessive empty form space.
