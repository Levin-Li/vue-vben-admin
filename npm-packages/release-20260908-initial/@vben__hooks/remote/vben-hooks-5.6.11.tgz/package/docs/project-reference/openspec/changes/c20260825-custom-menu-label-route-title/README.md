# c20260825-custom-menu-label-route-title

Ensure tenant custom-menu item labels override local page mapping titles in generated navigation routes.
