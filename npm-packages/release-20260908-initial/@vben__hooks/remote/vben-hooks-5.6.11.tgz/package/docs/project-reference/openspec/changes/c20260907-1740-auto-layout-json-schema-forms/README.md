# c20260907-1740-auto-layout-json-schema-forms

Automatically produce compact readable layouts for shared JSON Schema configuration forms.
