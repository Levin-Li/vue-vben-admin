# 供应商协议与 SDK 版本清单

核对日期：2026-08-26。真实适配器只能按此表列出的官方资料实现；上线前必须再次核对文档的最后更新日期和商户账户可用能力。

| 供应商 | 官方协议/SDK | 当前版本或状态 | Java 策略 |
| --- | --- | --- | --- |
| NOWPayments | Payment API、IPN 文档 | Payment API；IPN 使用递归排序 JSON 的 `x-nowpayments-sig` / HMAC-SHA512 | 未发现官方 Java SDK；按官方 HTTP/IPN 规范实现并测试 |
| CoinPayments | NEW API v2、官方 SDK 文档 | 文档标明 API v2；官方 SDK 仅 JS/TS、Python、PHP | 无 Java SDK；按 v2 canonical request、HMAC-SHA256/Base64 和原始 body Webhook 规范实现 |
| BitPay | 官方 Java Unified SDK | `com.bitpay:bitpay_sdk:10.2.5`；官方发布线 10.2.5 | 强制使用 SDK 创建/查询 invoice；BitPay IPN 触发 SDK `getInvoice` 回查 |

## 核对规则

- 文档版本、Maven SDK 版本和依赖兼容性必须进入代码评审记录。
- 升级任一 SDK 前先在 Sandbox 回归创建、查询、签名、确认和过期流程。
- BitPay SDK 提供 Java 17+ 适用的统一客户端；本项目使用 10.2.5，不使用已废弃的分离 key-utils 包。
- CoinPayments/ NOWPayments 的验签输入不得重序列化原始 body，除非其官方规则明确要求排序后的 JSON（NOWPayments IPN 是该例外）。
