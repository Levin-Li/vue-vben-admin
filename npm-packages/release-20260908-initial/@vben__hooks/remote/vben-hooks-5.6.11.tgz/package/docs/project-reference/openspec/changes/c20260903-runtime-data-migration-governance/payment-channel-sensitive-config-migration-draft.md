# 支付通道敏感配置迁移草案

## 状态

这是当前 OpenSpec 的迁移前置记录，不是可执行 SQL，也不会由应用启动、接口访问或 CI 自动执行。待同一发布批次的需求、代码和验收全部收口后，统一并入正式迁移交付。

## 适用范围

检查支付通道 `detailInfo` 中仍直接保存的敏感值：

- 支付宝：`privateKey`、`keyPrivate`、`publicKey`、`keyPublic`、`merchantCert`、`aliPayCert`、`aliPayRootCert`、`appAuthToken`
- 微信支付：`apiKey`、`secretKey`、`v3ApiKey`、`apiClientKeyP12`、`keyPublic`、`privateKey`、`keyPrivate`

每项敏感值必须由对应的当前引用字段替代：`privateKeyRef`、`publicKeyRef`、`merchantCertRef`、`aliPayCertRef`、`aliPayRootCertRef`、`appAuthTokenRef`、`apiV2KeyRef`、`apiV3KeyRef`、`merchantApiCertificateRef`、`platformCertificateRef`、`merchantPrivateKeyRef`。引用所指的运行时值由部署环境或密钥系统管理，绝不写回数据库。

## 执行方式

1. 发布/运维人员先备份目标库，并导出受影响通道的 ID、租户、供应商和 `detailInfo` 的脱敏清单；不得把明文密钥、证书或令牌写入迁移日志、SQL 文件或工单。
2. 对每个被识别通道人工分配唯一的运行时引用名，并先在目标环境的密钥系统、环境变量或配置中心中创建对应值。
3. 使用受控的管理写入或专用迁移命令，只更新该通道的引用字段并删除同一敏感项的旧内嵌字段；禁止通过普通查询接口或应用启动自动执行。
4. 在隔离环境用引用名解析支付配置，确认能完成支付 SDK 配置构造；正式环境仅记录通道 ID 与引用名，不记录敏感值。

## 冲突与恢复

- 旧内嵌敏感值存在但无法确认其目标引用名时，停止该通道迁移并保持原记录，待人工确认；新版本会明确拒绝该通道，而不会静默回退使用旧值。
- 引用名存在但部署环境缺少对应运行时值时，停止切换并补齐密钥配置；不得将旧内嵌值作为临时兜底。
- 需要回退时，仅在受控维护窗口从备份恢复该通道记录，并同步回退相应应用版本；不得让普通业务请求执行反向写入。

## 验证

- 所有仍含旧敏感字段且缺少对应引用字段的通道必须出现在迁移清单中，并在发布前清零或被明确排除。
- 对每种支付渠道至少验证一个已迁移通道：仅通过引用解析成功，旧内嵌字段不会参与解析。
- 迁移完成后，对受影响记录运行脱敏核验，确认数据库 JSON 中不再包含已迁移的旧内嵌敏感字段。
