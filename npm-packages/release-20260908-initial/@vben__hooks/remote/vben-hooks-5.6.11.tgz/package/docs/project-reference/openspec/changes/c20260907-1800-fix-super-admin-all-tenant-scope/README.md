# c20260907-1800-fix-super-admin-all-tenant-scope

Initialize super administrator organization scope for all tenants and provide an explicit migration for existing data.
