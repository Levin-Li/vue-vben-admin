# c20260907-1700-correct-form-group-toggle-label

Make shared form group expansion controls report their actual state and use concise Chinese labels.
