# Detail Page Implementation Scope

## Must Change

These files are the central implementation points and should be changed after confirmation:

- `frontend/admin/packages/business/admin-framework/src/framework-commons/shared/crud-page.vue`
  - Built-in row "详情" uses `handleRetrieve()` and opens `showForm`.
  - Row actions with `successAction: ShowForm/showForm` also use the same `actionResultEntries` rendering.
  - This is the primary place to filter complex values, render option labels, and add the JSON "查看" action.
- `frontend/admin/packages/business/admin-framework/src/framework-commons/shared/types.ts`
  - Only if the shared renderer needs explicit field metadata such as `detail`, `detailType`, or `detailViewer`.
  - Prefer avoiding new config if existing `type`, `options`, `loadOptions`, `multiple`, and `valueType` are enough.
- `frontend/admin/packages/business/admin-framework/src/framework-commons/shared/__tests__/...`
  - Add or extend focused tests for detail display rules.

## Already Covered By The Shared CRUD Renderer

These pages use the Oak wrapper around the shared `CrudPage`. They should be covered by changing `crud-page.vue`, not by editing each page one by one:

- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/access-log/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/address/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/client-app/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/area/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/article-channel/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/article/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/bank-branch/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/brand/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/customer/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/demo/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/dict/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/domain-ssl-cert/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/domain/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/file-res/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/fund-account-log/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/fund-account/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/fund-exchange-rule/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/i18n-res/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/job-post/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/nation/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/notice-process-log/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/notice/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/online-code-gen/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/org/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/pay-channel/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/pay-order/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/rbac-permission-item/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/role/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/scheduled-log/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/scheduled-task/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/service-plugin/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/setting/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/simple-api/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/simple-form/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/simple-page/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/social-user/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/tenant-app/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/tenant-site/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/tenant/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/url-ex-acl/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/user-setting/index.vue`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/user/index.vue`

## Custom Detail Or Preview Entry Points To Review

These are not plain row "详情" renderers, but they contain detail-like modals, previews, or retrieved records. They may not all need changes, but they should be reviewed after the shared renderer is updated:

- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/setting-crud-page.vue`
  - "查看值/编辑值" already uses one shared value editor. Need verify JSON preview behavior matches the new rule.
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/setting-for-tenant/index.vue`
  - Tenant setting value preview/edit flow. Need verify same JSON preview behavior.
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/setting-value-content-field.vue`
  - Shared setting value field used by the two setting pages above.
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/setting-value-preview-modal.vue`
  - Existing value preview modal; likely candidate for Json Viewer integration.
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/my-messages/index.vue`
  - Custom "消息详情" modal. Mostly text/status tags, likely no complex-field filtering needed.
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/simple-content-resource-page.vue`
  - Custom content editor/preview page for simple API/form/page resources. It retrieves detail records and displays content fields.
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/domain-ssl-cert/index.vue`
  - Retrieves certificate detail for manual edit; this is edit flow, not normal detail page.
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/data-permission-preview/index.vue`
  - Permission preview demo/detail payload; not normal CRUD detail.
- `frontend/admin/packages/business/admin-framework/src/framework-commons/shared/data-permission-dialog.vue`
  - Permission assignment dialog loads a detail record for editing permissions; not normal read-only detail.
- `frontend/admin/packages/business/admin-framework/src/framework-commons/shared/resource-permission-dialog.vue`
  - Resource permission dialog loads a detail record for editing permissions; not normal read-only detail.
- `frontend/admin/packages/business/admin-framework/src/framework-commons/shared/server-action-page.vue`
  - Displays arbitrary server action result as text/pre; should be reviewed separately if treated as ShowForm-like output.

## Config Files With JSON / Enum / Dict / Fixed Options

These config files do not need page-by-page edits if `crud-page.vue` resolves labels and filters complex values correctly, but they are the main coverage surface for tests and manual smoke checks:

- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/customer/config.ts`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/notice/config.ts`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/file-res/config.ts`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/dict/config.ts`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/simple-api/config.ts`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/article/config.ts`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/pay-channel/config.ts`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/simple-page/config.ts`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/org/config.ts`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/fund-account-log/config.ts`
- `frontend/admin/packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/tenant-app/config.ts`
