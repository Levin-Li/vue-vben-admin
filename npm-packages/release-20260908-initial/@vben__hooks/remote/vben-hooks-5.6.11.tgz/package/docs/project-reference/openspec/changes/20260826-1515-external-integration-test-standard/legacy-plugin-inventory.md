# 存量外部接口插件补测清单

盘点日期：2026-08-26。此清单以 `services-impl` 中明确的供应商适配器/插件实现为准；“待补测”表示尚未按 `40-外部接口对接开发规则.md` 确认具备协议模拟服务、多路径逐节点查库验收，不表示该功能不可用。

| 分组 | 已发现插件/供应商 | 当前验收状态 | 补测最低目标 |
| --- | --- | --- | --- |
| 支付 | 支付宝、微信、NOWPayments、CoinPayments、BitPay | USDT 三家已具备模拟、逐节点 H2 验收；传统支付已完成支付宝 / 微信业务入口 H2 闭环：支付发起、处理中查询、支付成功/失败细状态、无效回调、重复回调、退款申请/查询，以及微信/支付宝退款回调控制器闭环。更细的 SDK 网关协议语义与真实 Sandbox 边界仍待补 | 支付发起、处理中查询、成功、失败/过期、重复回调；主单、附属单/审计与通知查库 |
| 电子合同 | Esign、法大大、腾讯电子签 | 已完成三家供应商协议模拟 + 业务入口组合验收：Esign、法大大、腾讯电子签的 provider-combo 业务链路与既有 H2 主链均已通过 | 创建、签署中、签署完成、取消、无效回调、重复回调、文件下载 |
| 电子发票 | 诺诺、慧灯、发票通、Mock | 已完成四家供应商协议模拟/业务入口组合验收：Mock、诺诺、慧灯、发票通的 provider-combo 业务链路与既有 H2 主链均已通过 | 开票创建、处理中、成功、失败、回调重放、查询/下载；发票与审计记录查库 |
| 域名/证书 | Cloudflare、Dynadot、DeSec、DNSHe、Spaceship、ACME/SSL | 已完成域名与证书主链验收：Cloudflare/Dynadot/Spaceship 协议 HTTP 模拟，DeSec/DNSHe 协议契约测试，域名 H2 主链与 SSL/站点 H2 主链均已通过；Cloudflare / Dynadot / Spaceship / DeSec / DNSHe 五家已补 DNS-01 provider-combo 业务 H2，另已补 `HTTP-01` 业务入口 H2 成功/失败链路；站点侧 `applyDomain/applyExistingDomain/renewDomain/syncStatus` 与 `applySslCert/configManualSslCert` 控制器入口也已补 H2；域名控制器 `applyDomain/syncStatus/dnsRecords CRUD` 入口也已补 H2；ACME/SSL 与域名供应商业务级联动仍待补 | 提交申请、DNS/验证中、签发/失败、撤销或重试、重复任务；申请与证书记录查库 |
| 组织同步 | 飞书、钉钉、企业微信 | 已完成三家协议 HTTP 模拟与业务 H2 路径，覆盖成功、更新、空结果、错误和重试 | 首次同步、增量同步、空结果、供应商错误、重试/重复事件；组织映射查库 |
| 消息/短信 | Sms4J、Wlwx、短信验证码、机器人消息 | `Sms4J`、`Wlwx` 与机器人消息已补 loopback HTTP 协议模拟；验证码生成与校验不再保留独立审计表 | 发送成功、供应商拒绝、超时/异常、重试、重复投递；补齐真正的 delivery receipt / retry 回执后再做更严格逐节点数据库验收 |
| 邮件 | Forward Email 入站转发、邮件验证码/发送 | Forward Email 入站中转已完成协议语义模拟 + 业务入口 H2：预检、DNS 预检、首次同步、已绑定 alias 重同步、删除、无 providerRouteId 删除、未受管 alias 冲突；邮件验证码已通过 `VerifyCodeAudit` 落库，默认邮件发送已补 loopback SMTP 协议模拟 | 投递、解析、转发、失败、重试/重复邮件；补齐真正的外发邮件 delivery receipt 后再做更严格链路验收 |
| 身份/登录 | OAuth/JustAuth、Google MFA 等外部身份能力 | OAuth 模拟微信登录已具备业务入口 H2 验收：自动注册、重复登录修复、账号绑定、冲突绑定、解绑；授权事务已补创建、完成、失败、浏览器密钥错误和重复兑换；JustAuth builder 委托、平台别名归一化和回调失败/成功分支已补单测。Google MFA 已补插件级、业务入口级测试，并通过 `VerifyCodeAudit` 具备可查库事实源；真实 OAuth 平台协议回调仍待补 | 授权开始、回调成功、拒绝/状态不匹配、重复回调、账号绑定；用户与授权状态查库 |
| AI/模型服务 | 默认 AI 对话插件及其供应商客户端 | 已完成 OpenAI 兼容协议模拟与审计 H2 主链：同步、流式、认证失败、限流、超时、无效请求均已覆盖；余额/配额副作用仍待补 | 请求创建、流式/非流式完成、供应商错误、限流/超时、重试；调用审计和余额/配额副作用查库 |

## 实施顺序

1. 资金、支付、签约、身份等高影响插件优先。
2. 每个供应商建立独立模拟服务与路径矩阵后，再开始实现测试；不得只增加一个 happy path。
3. 完成一个供应商就更新本清单的验收状态，并在该供应商的 OpenSpec 中记录测试命令和真实 Sandbox 边界。
4. 所有条目完成前，不得宣称“存量外部接口均已端到端验收”。

## 已记录证据

### 控制器级 H2 套件回归（2026-08-26）

- 为了验证近期补齐的真实入口链路没有互相回归，已使用窄编译 + JUnit Console 对以下控制器级 H2 测试做一轮集中回归：
  - `TraditionalPayOrderControllerH2SimulationTest`
  - `TraditionalPayCallbackControllerH2SimulationTest`
  - `TraditionalPayRefundControllerH2SimulationTest`
  - `CryptoPayOrderControllerH2SimulationTest`
  - `ElectronicContractCallbackControllerH2SimulationTest`
  - `ElectronicInvoiceCallbackControllerH2SimulationTest`
  - `ElectronicInvoiceProviderConnectionControllerH2SimulationTest`
  - `InboundEmailRelayControllerH2SimulationTest`
  - `DomainSslCertControllerH2SimulationTest`
  - `TenantSiteSslControllerH2SimulationTest`
  - `TenantSiteDomainControllerH2SimulationTest`
  - `DomainControllerH2SimulationTest`
  - `OrgSyncControllerH2SimulationTest`
  - `AiChatControllerH2SimulationTest`
  - `OAuthControllerTransactionAuditH2SimulationTest`
  - `OAuthControllerRealPlatformCallbackH2SimulationTest`
- 套件结果：`47 tests started / 47 tests successful / 0 tests failed`。
- 该套件覆盖资金、签约、发票、消息、域名/证书、组织同步、AI 与身份/登录这几组近期新增的真实入口链路，可作为当前阶段“控制器层外部集成回归无明显破坏”的集中证据。

### 支付（增量进展，2026-08-26）

- 已验证范围：
  - `services-impl/src/test/java/com/levin/oak/base/biz/BizPayOrderServiceImplUsdtTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/TraditionalPayH2SimulationChainDatabaseTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/TraditionalPayCallbackControllerH2SimulationTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/TraditionalPayRefundControllerH2SimulationTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/TraditionalPayOrderControllerH2SimulationTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/CryptoPayOrderControllerH2SimulationTest.java`
- 通过证据：
  - `TraditionalPayH2SimulationChainDatabaseTest` 现已扩展到支付发起、主动查询细状态、参数式回调、原始网关回调报文（微信 XML body / 支付宝 form body）、原始网关回调验签失败、支付回调重放、支付回调细状态、退款申请、退款查询、退款回调失败与退款回调幂等，最新窄编译 + JUnit Console 结果为 `18 tests started / 18 tests successful / 0 tests failed`。
  - `TraditionalPayCallbackControllerH2SimulationTest` 现已补 `BizPayOrderController.payCallback(...)` 的控制器级 H2 闭环：微信原始 XML 支付回调验证“验签失败 -> 成功 -> replay”，支付宝原始 form 支付回调验证“验签失败 -> 成功”；并新增退款回调闭环：微信原始 XML `req_info` 退款通知验证“成功 -> replay”、`CHANGE/REFUNDCLOSE/ABNORMAL -> Failed`、畸形 `req_info -> fail 且不改库`，支付宝原始 form `dback_status/out_request_no` 退款通知验证 `F -> Failed`、`S -> Succeed`。最新窄编译 + JUnit Console 结果为 `7 tests started / 7 tests successful / 0 tests failed`。
  - 针对本次退款回调细分终态与异常报文补齐，再次使用窄编译 + JUnit Console 联合回归 `TraditionalPayCallbackControllerH2SimulationTest` 与 `TraditionalPayH2SimulationChainDatabaseTest`，结果为 `25 tests started / 25 tests successful / 0 tests failed`。
  - `TraditionalPayRefundControllerH2SimulationTest` 现已补 `BizPayOrderController.applyRefund/refund/refundQuery` 的控制器级 H2 闭环：微信退款申请 -> 退款受理 -> 退款查询失败，以及支付宝退款查询成功，窄编译 + JUnit Console 结果为 `2 tests started / 2 tests successful / 0 tests failed`。
  - `TraditionalPayOrderControllerH2SimulationTest` 现已补 `BizPayOrderController.pay/payQuery` 的控制器级 H2 闭环：微信发起支付并查询成功、支付宝发起支付并查询成功，窄编译 + JUnit Console 结果为 `2 tests started / 2 tests successful / 0 tests failed`。
  - `CryptoPayOrderControllerH2SimulationTest` 现已补 `BizPayOrderController` 在数字货币通道下的控制器级 H2 闭环：`pay` 创建 USDT 支付指令、`payQuery` 按确认数推进 Processing -> Succeed 或过期 -> Canceled、`payCallback` 通过原始 JSON body + `X-USDT-Simulator-Signature` 应用链上结算事件，并拒绝无效签名回调，窄编译 + JUnit Console 结果为 `4 tests started / 4 tests successful / 0 tests failed`。
  - `BizPayOrderServiceImplUsdtTest` 继续用于数字货币桥接与订单字段承接回归。
- 已验证路径：
  - 数字货币桥接仍保持通过；
  - 数字货币控制器级 H2：`BizPayOrderController.pay(...)` 已覆盖 USDT 支付指令创建与 `crypto_pay_order`/`pay_order` 落库；`payQuery(...)` 已覆盖按确认数推进的 Processing -> Succeed 与过期 -> Canceled；`payCallback(...)` 已覆盖原始 JSON body + 签名头的结算回调，以及无效签名回调不改库；
  - 传统支付发起后 `prepayId`、`payTradeNo`、`payInfo` 会回写支付订单更新请求；
  - 传统支付控制器级 H2：`BizPayOrderController.pay(...)` 已覆盖微信 `prepayId` 与支付宝 `order_string` 的返回与落库；`payQuery(...)` 已覆盖两条查询成功链路并验证通知行为；
  - 传统支付主动查询成功仍只通知一次；
  - 微信业务入口 H2 已补查询细分状态：`NOTPAY` 保持处理中且不重复通知，`PAYERROR` 落失败状态；
  - 支付宝业务入口 H2 已补查询细分状态：`WAIT_BUYER_PAY` 落预处理中，`TRADE_CLOSED` 落已取消；
  - 微信退款业务入口 H2：`applyRefund -> refund(受理成功=Processing) -> refundQuery(FAIL=Failed)` 已逐节点验证退款单号、退款金额、退款备注、退款状态和错误信息落库；
  - 微信退款控制器级 H2：`BizPayOrderController.applyRefund -> refund -> refundQuery` 已逐步验证退款单号、退款金额、退款备注、退款状态、错误信息与通知次数；
  - 支付宝退款业务入口 H2：`refundQuery(REFUND_SUCCESS=Succeed)` 已逐节点验证退款状态落库和退款通知分支；
  - 支付宝退款控制器级 H2：`BizPayOrderController.refundQuery` 已逐步验证退款成功状态落库与通知分支；
  - 微信退款回调 H2：首次成功回调落退款成功，重复回调不再重复通知；
  - 微信退款回调 H2：失败回调 `Failed` 已直接落库；
  - 微信退款回调细状态控制器级 H2：`CHANGE -> Failed`、`REFUNDCLOSE -> Failed`、`ABNORMAL -> Failed` 已通过原始 XML `req_info` 退款通知逐步查库验证；
  - 微信退款回调异常报文控制器级 H2：畸形 `req_info` 会直接回 `fail`，且 `refund_status/pay_info/通知次数` 保持不变；
  - 微信退款控制器级 H2：`BizPayOrderController.payCallback(...)` 已通过原始 XML `req_info` 退款通知验证“成功 -> replay”，并逐步查库确认 `refund_status/refund_time/pay_info`；
  - 支付宝退款回调细状态控制器级 H2：`dback_status=F -> Failed`、`dback_status=S -> Succeed` 已通过原始 form `out_request_no/dback_status/bank_ack_time` 逐步查库验证；
  - 支付宝退款控制器级 H2：`BizPayOrderController.payCallback(...)` 已通过原始 form `dback_status/out_request_no/bank_ack_time` 退款通知验证失败落库，并逐步查库确认 `refund_status/pay_info`；
  - 微信业务入口 H2：支付发起、预下单号落库、主动查询成功、无效回调、成功回调、重复回调；
  - 微信网关协议语义 H2：原始 XML body 回调 `out_trade_no / transaction_id / return_code / result_code / trade_state / time_end / sign` 已通过 `getInputStream()` 解析并直接落支付订单；
  - 微信网关协议语义 H2：原始 XML body 验签失败会返回 `fail`，且支付订单保持处理中、不写 `payTradeNo`、不发通知；
  - 微信控制器级 H2：`BizPayOrderController.payCallback(...)` 已通过原始 XML 请求体验证“验签失败 -> 成功 -> replay”，并逐步查库确认订单状态、支付单号与通知次数；
  - 微信回调细状态 H2：`NOTPAY -> Canceled`；
  - 微信回调细状态 H2：`PAYERROR -> Failed`、`REVOKED -> Canceled`；
  - 支付宝业务入口 H2：支付发起、支付参数落库、主动查询成功、无效回调、成功回调、重复回调。
  - 支付宝网关协议语义 H2：原始 `application/x-www-form-urlencoded` body 回调 `out_trade_no / trade_no / trade_status / subject / sign` 已通过请求体解析并直接落支付订单；
  - 支付宝网关协议语义 H2：原始 form body 验签失败会返回 `fail`，且支付订单保持处理中、不写 `payTradeNo`、不发通知；
  - 支付宝控制器级 H2：`BizPayOrderController.payCallback(...)` 已通过原始 form 请求体验证“验签失败 -> 成功”，并逐步查库确认订单状态、支付单号与通知次数；
  - 支付宝回调细状态 H2：`TRADE_CLOSED -> Failed`。
- 剩余边界：当前支付宝 / 微信链路虽然已补服务层与控制器级的原始 XML / form 回调报文语义，也补到了微信 `req_info` 退款通知与支付宝 `dback_status` 退款通知的成功/失败关键终态，以及微信退款密文解析失败保护，但仍使用 SDK 子类测试模拟服务，不是独立 loopback HTTP 网关进程，也未补真实密钥验签、证书轮换、时间戳/重放窗口等更细验签语义；真实 Sandbox/生产凭据联调仍待补。退款回调侧仍未覆盖更细的供应商字段差异与更多支付宝银行卡冲退附加字段语义。

### 组织同步（2026-08-26）

- 供应商范围：飞书、钉钉、企业微信。
- 协议语义模拟：`services-impl/src/test/java/com/levin/oak/base/biz/plugin/orgsync/OrgSyncProviderHttpSimulationServerTest.java`
- 路径覆盖：成功创建、二次更新、空结果、供应商错误、失败后重试；验证组织、用户和外部账号的同步结果。
- Sandbox/生产边界：当前仅验证本地 loopback 协议模拟与 H2 数据落库；尚未接入飞书、钉钉、企业微信真实企业凭据或供应商 Sandbox/生产环境。

### 电子合同（2026-08-26）

- 已验证范围：
  - `services-impl/src/test/java/com/levin/oak/base/biz/ElectronicContractProviderSimulationChainDatabaseTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/ElectronicContractH2SimulationChainDatabaseTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/ElectronicContractCallbackControllerH2SimulationTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/econtract/EsignElectronicContractServicePluginTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/econtract/FadadaElectronicContractServicePluginTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/econtract/TencentEsignElectronicContractServicePluginTest.java`
- 通过证据：使用窄编译 + JUnit Console 运行上述 5 组测试，结果为 `8 tests started / 8 tests successful / 0 tests failed`。
  - 补充证据：扩展 `ElectronicContractCallbackControllerH2SimulationTest` 后，再用窄编译 + JUnit Console 定向执行 `BizElectronicContractController.saveDraft(...)`、`submitSigning(...)`、`providerCallback(...)`、`downloadSignedFile(...)`、`cancelSigning(...)` 与 `copyForResign(...)` 的控制器级 H2 闭环，结果为 `5 tests started / 5 tests successful / 0 tests failed`。
- 已验证路径：
  - Esign / 法大大 / 腾讯电子签三家供应商的协议模拟创建、回调、查询、取消、下载；
  - 三家供应商逐一组合到业务入口：草稿、提交签署、提交签署时供应商限流失败保持 Draft、签署完成、失败、重复回调、撤销、下载；
  - 通用 H2 主链：草稿、提交签署、成功回调、重复回调、撤销、无效回调。
  - 控制器级 H2：`BizElectronicContractController.saveDraft(...)`、`submitSigning(...)`、`providerCallback(...)`、`downloadSignedFile(...)`、`cancelSigning(...)`、`copyForResign(...)` 已覆盖草稿创建、提交签署、提交签署时供应商限流失败保持 Draft、不落半状态、签署完成回调成功、重复回调、签署拒绝回调、无效签名回调、已签文件下载、供应商下载失败不改库、供应商撤销签署、复制重签草稿，并逐步查 `electronic_contract` 的 `status/provider_flow_id/signing_log/submitted_time/completed_time/canceled_time/error_message/signed_file_url`。
- 剩余边界：当前仍未覆盖真实供应商 Sandbox/生产凭据联调，也未覆盖更丰富的供应商限流节流策略（例如重试窗口/恢复后重试）或更真实的远端文件介质异常（例如分块下载中断、下载链接过期）。

### 电子发票（2026-08-26）

- 已验证范围：
  - `services-impl/src/test/java/com/levin/oak/base/biz/ElectronicInvoiceProviderSimulationChainDatabaseTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/ElectronicInvoiceH2SimulationChainDatabaseTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/ElectronicInvoiceCallbackControllerH2SimulationTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/ElectronicInvoiceProviderConnectionControllerH2SimulationTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/einvoice/ExternalElectronicInvoiceServicePluginTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/einvoice/MockElectronicInvoiceServicePluginTest.java`
  - 通过证据：使用窄编译 + JUnit Console 运行上述 4 组测试，结果为 `18 tests started / 18 tests successful / 0 tests failed`。
  - 补充证据：继续扩展 `ElectronicInvoiceProviderSimulationChainDatabaseTest` 后，再用窄编译 + JUnit Console 定向回归 provider-simulation 业务入口，结果为 `14 tests started / 14 tests successful / 0 tests failed`。
  - 补充证据：扩展 `ElectronicInvoiceCallbackControllerH2SimulationTest` 后，再用窄编译 + JUnit Console 定向执行 `BizElectronicInvoiceController.issue(...)`、`redIssue(...)`、`providerCallback(...)` 与 `reconcile(...)` 的控制器级 H2 闭环，结果为 `5 tests started / 5 tests successful / 0 tests failed`。
- 补充证据：新增 `ElectronicInvoiceProviderConnectionControllerH2SimulationTest` 后，再用窄编译 + JUnit Console 定向执行 `BizElectronicInvoiceProviderConnectionController.activate(...)` 与 `completeAuthorization(...)` 的控制器级 H2 闭环，结果为 `2 tests started / 2 tests successful / 0 tests failed`。
- 已验证路径：
  - Mock / 诺诺 / 慧灯 / 发票通四家供应商的激活、开票、红冲、回调、对账、生产保护分支；
  - 供应商连接控制器级 H2：`BizElectronicInvoiceProviderConnectionController.activate(...)` 已覆盖“待授权连接”与“模拟模式即刻激活”两条链路；`completeAuthorization(...)` 已覆盖 PendingAuthorization -> Active 的确认授权链路，并逐步查 `connection` 记录的 `status/authorization_ref/terminal_ref/provider_ex_info/diagnostic_message`；
  - 四家供应商逐一组合到业务入口：激活建连、即刻成功开票、异步回调、重放、无效签名、红冲、定时对账，以及高灯 / 发票通 / 诺诺 provider-simulation 的 `reconcile -> Failed` 分支；
  - 通用 H2 主链：开票处理中、成功回调、重复回调、红冲处理中、红冲成功、无效签名。
  - 控制器级 H2：`BizElectronicInvoiceController.issue(...)` 已覆盖开票处理中落库；`redIssue(...)` 已覆盖红冲处理中落库；`providerCallback(...)` 已覆盖开票回调成功、重复回调、无效签名、开票回调失败且写入 `error_message`、红冲回调成功；`reconcile(...)` 已覆盖 Processing -> Issued、RedRequested -> RedIssued、Processing -> Failed、RedRequested -> Failed 的对账链路，并逐步查 `invoice` 记录的 `status/provider_invoice_id/invoice_no/red_invoice_id/action_count/error_message`。
- 剩余边界：当前未验证真实供应商 Sandbox/生产凭据、下载文件真实介质、额度/税控设备等供应商侧外部约束；`reconcile` 侧虽已补成功/失败状态落库，但仍未覆盖更多供应商专属错误码映射与文件下载介质链路。

### 身份/登录（2026-08-26）

- 已验证范围：`services-impl/src/test/java/com/levin/oak/base/biz/BizOauthH2SimulationChainDatabaseTest.java`、`services-impl/src/test/java/com/levin/oak/base/biz/BizOauthServiceImplTest.java`、`services-impl/src/test/java/com/levin/oak/base/biz/BizSocialLoginTransactionServiceImplTest.java`、`services-impl/src/test/java/com/levin/oak/base/biz/plugin/GoogleMfaVerifyServicePluginTest.java`、`services-impl/src/test/java/com/levin/oak/base/biz/rbac/DefaultRbacMiscServiceTest.java`、`services-impl/src/test/java/com/levin/oak/base/biz/VerifyCodeAuditH2SimulationChainDatabaseTest.java`
- 通过证据：
  - 既有身份/登录测试资产使用窄编译 + JUnit Console 运行前 6 组测试，结果为 `17 tests started / 17 tests successful / 0 tests failed`。
- 已验证路径：模拟微信 OAuth 自动注册、重复登录域名修复、账号绑定、冲突绑定、解绑；`state/browserSecret` 事务创建、完成、失败、浏览器密钥错误和重复兑换；并直接查询 `app_user`、`social_user` H2 表及内存化事务桶状态。
- 已补充路径：Google MFA 插件二维码生成、密钥缺失/禁用分支、模拟 TOTP 校验；`DefaultRbacMiscService.sendVerifyCode()` 的 MFA 业务入口账号选择路径；`BizOauthService.authorize()` 的 mock 微信授权链接生成与自动 state 生成；JustAuth builder 委托、OAuth 平台别名归一化、真实平台成功/失败回调分支的服务层单测；`VerifyCodeAudit` 对短信/邮件/MFA 的生成与校验动作落库；密码登录挑战和 OAuth 授权事务仅保留缓存状态机，不再持久化独立审计记录。
- 剩余边界：当前 provider 响应分支已经具备一段式与两段式本地 HTTP 协议语义，也补到了事务失效/平台不匹配、provider 畸形 JSON、纯文本错误体的控制器边界，但仍不是完整的第三方 OAuth “浏览器授权页 -> code 回跳 -> token -> refresh token -> userinfo”全流程多端点模拟；真实 OAuth 平台 Sandbox/生产凭据、刷新令牌、开放平台限流/风控和更多供应商专属错误码仍待补。
  代码级证据：
  - `BizSocialLoginTransactionServiceImpl` 仍只提供服务层的 `create/find/complete/fail/exchange`；虽然 `OAuthController` 已具备控制器闭环，但 `admin-api` / `client-api` 仍没有独立 API 面向前后端分层场景复用同一条事务闭环；
  - `GoogleMfaVerifyServicePlugin` 直接基于用户 `mfaSecretKey` 生成/校验 TOTP；插件本身仍没有独立的 MFA challenge session 领域实体。

### 域名/证书（2026-08-26）

- 已验证范围：
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/domain/DomainProviderHttpSimulationTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/domain/DomainProviderPluginContractTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/domain/DeSecDomainApplyServicePluginTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/domain/DNSHeDomainApplyServicePluginTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/DomainSslCertH2SimulationChainDatabaseTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/DomainH2SimulationChainDatabaseTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/DomainProviderBusinessH2SimulationChainDatabaseTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/DomainSslCertProviderBusinessH2SimulationChainDatabaseTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/BizDomainServiceImplTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/BizDomainSslCertServiceImplTest.java`
- 通过证据：
  - 既有域名/证书测试资产使用窄编译 + JUnit Console 运行上述原 8 组测试，结果为 `35 tests started / 35 tests successful / 0 tests failed`。
  - 新增 `DomainProviderBusinessH2SimulationChainDatabaseTest` 后，再用窄编译 + JUnit Console 定向执行 Cloudflare / Dynadot / Spaceship / DeSec / DNSHe 五家 provider-combo H2，结果为 `5 tests started / 5 tests successful / 0 tests failed`。
  - 新增 `DomainSslCertProviderBusinessH2SimulationChainDatabaseTest` 后，再用窄编译 + JUnit Console 定向执行 Cloudflare / Dynadot / Spaceship / DeSec / DNSHe 五家证书 DNS-01 provider-combo H2，结果为 `1 tests started / 1 tests successful / 0 tests failed`。
  - 新增 `BizSslCertApplyServiceImplTest` 的 ACME challenge 节点补测后，再用窄编译 + JUnit Console 回归 `BizSslCertApplyServiceImplTest`，结果为 `21 tests started / 21 tests successful / 0 tests failed`，其中已新增 `HTTP-01` challenge callback/trigger 与 `AUTO -> HTTP`、`DNS-01 rrName/digest` 语义校验。
  - 新增 `DomainSslCertHttp01H2SimulationChainDatabaseTest` 后，再用窄编译 + JUnit Console 定向执行 `applySslCert()` 的 `HTTP-01` 业务入口 H2，结果为 `3 tests started / 3 tests successful / 0 tests failed`。
  - 新增 `BizSslCertApplyServiceImplTokenStoreTest` 与 `AcmeFilterTest` 后，再用窄编译 + JUnit Console 回归 `HTTP-01` token 存取与 challenge 暴露边界，结果为 `5 tests started / 5 tests successful / 0 tests failed`。
  - 新增 `DomainSslCertControllerH2SimulationTest` 后，再用窄编译 + JUnit Console 定向执行 `BizDomainSslCertController.applySslCert(...)`、`applyForDnsRecord(...)`、`configManualSslCert(...)` 与 `downloadCert(...)` 的控制器级 H2 闭环，结果为 `4 tests started / 4 tests successful / 0 tests failed`。
  - 新增 `TenantSiteSslControllerH2SimulationTest` 后，再用窄编译 + JUnit Console 定向执行 `BizTenantSiteController.applySslCert(...)` 与 `configManualSslCert(...)` 的控制器级 H2 闭环，结果为 `2 tests started / 2 tests successful / 0 tests failed`。
  - 新增 `TenantSiteDomainControllerH2SimulationTest` 后，再用窄编译 + JUnit Console 定向执行 `BizTenantSiteController.applyDomain(...)`、`applyExistingDomain(...)`、`renewDomain(...)` 与 `syncStatus(...)` 的控制器级 H2 闭环，结果为 `2 tests started / 2 tests successful / 0 tests failed`。
  - 扩展 `DomainControllerH2SimulationTest` 后，再用窄编译 + JUnit Console 定向执行 `BizDomainController.canApply(...)`、`applyDomain(...)`、`renewDomain(...)`、`syncStatus(...)` 与 `dnsRecords list/create/update/delete/batchDelete` 的控制器级 H2 闭环，结果为 `3 tests started / 3 tests successful / 0 tests failed`。
- 已验证路径：
  - Cloudflare/Dynadot/Spaceship 的真实 HTTP 协议语义请求、鉴权/签名和关键请求体；
  - Cloudflare 业务入口 H2：状态同步、DNS 查询、新增、更新、删除；每一步均直接查询 `domain_record` 的 `provider_name`、`domain_apply_api`、`provider_domain_id` 与 `dns_records`；
  - Dynadot 业务入口 H2：状态同步、DNS 查询、新增、更新、删除；每一步均直接查询 `domain_record` 的 `provider_name`、`domain_apply_api`、`provider_domain_id` 与 `dns_records`；
  - Spaceship 业务入口 H2：状态同步、DNS 查询、新增、更新、删除；每一步均直接查询 `domain_record` 的 `provider_name`、`domain_apply_api`、`provider_domain_id` 与 `dns_records`；
  - DeSec 业务入口 H2：状态同步、DNS 查询、新增、更新、删除；每一步均直接查询 `domain_record` 的 `provider_name`、`domain_apply_api` 与 `dns_records`；
  - DNSHe 业务入口 H2：状态同步、DNS 查询、新增、更新、删除；每一步均直接查询 `domain_record` 的 `provider_name`、`domain_apply_api` 与 `dns_records`；
  - Cloudflare / Dynadot / Spaceship / DeSec / DNSHe 证书业务入口 H2：`applySslCert()` 通过真实 DNS 插件执行 DNS-01 TXT 新增/删除，并直接查询 `domain_ssl_cert` 的 `ssl_apply_status`、`ssl_apply_api`、`ssl_apply_token`、`ssl_cert_chain_pem`，同时校验各供应商协议端点确实被调用；
  - HTTP-01 证书业务入口 H2：当证书域名未匹配可用 DNS-01 供应商且公网解析指向本机时，`applySslCert()` 会以 `HTTP` challenge 提交到 `bizSslCertApplyService`，并逐步查 `domain_ssl_cert` 从 `Applying -> Approved/Failed` 的状态、`ssl_apply_api`、`ssl_apply_token`、`ssl_cert_chain_pem`、`ssl_private_key_pem` 和失败备注；当公网解析不指向本机时，会在调用 ACME 之前前置拒绝，证书记录保持 `UnCommit` 且不调用 `bizSslCertApplyService.apply(...)`；
  - 证书控制器级 H2：`BizDomainSslCertController.applySslCert(...)` 已覆盖成功与失败链路，以及 `HTTP-01` 公网解析不指向本机时的前置拒绝（记录保持 `UnCommit`、不调用 ACME apply）；`applyForDnsRecord(...)` 已覆盖 A 记录派生域名的成功申请与 TXT 记录直接拒绝；`configManualSslCert(...)` 已覆盖手动证书导入落库；`downloadCert(...)` 已覆盖证书 ZIP 下载头与 `.pem/.key` 内容，并逐步查 `domain_ssl_cert` 的 `Applying -> Approved/Failed/UnCommit` 状态、`ssl_apply_api`、`ssl_apply_token`、`ssl_cert_chain_pem`、`ssl_private_key_pem` 和失败备注；
  - 站点控制器级 H2：`BizTenantSiteController.applySslCert(...)` 已覆盖站点申请证书时创建/复用证书资产并委托外部证书申请；`configManualSslCert(...)` 已覆盖站点手动导入证书材料并落库到 `domain_ssl_cert`；
  - 域名站点控制器级 H2：`BizTenantSiteController.applyDomain(...)`、`applyExistingDomain(...)`、`renewDomain(...)`、`syncStatus(...)` 已覆盖站点域名新建、重申请、续期和状态同步入口，并逐步查 `tenant_site` 的域名持久化结果与外部域名服务委托行为；
  - 域名控制器级 H2：`BizDomainController.canApply(...)` 已覆盖供应商可注册性判断；`applyDomain(...)`、`renewDomain(...)`、`syncStatus(...)`、`dnsRecords/list/create/update/delete/batchDelete` 已覆盖域名申请、续期、远端状态同步与 DNS CRUD，并逐步查 `domain_record` 的 `domain_apply_status/provider_name/domain_apply_api/domain_expired_time/dns_records`；
  - ACME challenge 节点语义：`BizSslCertApplyServiceImpl.authorize()` 的 `HTTP-01` 路径现已校验 token/authorization callback 与 challenge trigger/wait；`dnsChallenge()` 现已校验 rrName/digest 回调；`AUTO` 模式在 callback 不支持 DNS 时会切换到 `HTTP`；
  - HTTP-01 暴露边界：`BizSslCertApplyServiceImpl.setToken/getToken` 已验证通过 Redisson bucket 存取 ACME token；`AcmeFilter` 已验证会在 `/.well-known/acme-challenge/{token}` 路径返回纯文本 challenge token，缺失 token 时返回 `Not Found`，非 challenge 请求继续透传；
  - DeSec/DNSHe 的 DNS 记录契约与错误归一化；
  - 域名业务入口 H2：供应商推断同步、远端 DNS 查询/新增/更新/删除、本地快照模式、localhost 拒绝；
  - 证书业务入口 H2：申请成功、重复申请重试、失败落库、租户站点证书材料保存与状态同步。
- 剩余边界：当前 `HTTP-01` 与 `DNS-01` 业务入口/H2 已补到状态落库与 challenge 节点语义，但证书 provider-combo 仍使用 `BizSslCertApplyService` 的测试替身驱动 CA 返回；仍不是完整的 ACME 目录 / order / authorization / challenge / finalize 协议模拟；真实 ACME CA Sandbox/生产验签与各域名供应商的业务级联动仍待补。

### AI/模型服务（2026-08-26）

- 已验证范围：
  - `services-impl/src/test/java/com/levin/oak/base/biz/ai/OpenAiCompatibleProviderMockTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/ai/AiChatH2SimulationChainDatabaseTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/ai/AiChatControllerH2SimulationTest.java`
  - `services/src/test/java/com/levin/oak/base/biz/ai/AiProviderConfigTest.java`
- 通过证据：在补充 usage/token 审计与 quota exceeded 分支后，继续使用窄编译 + JUnit Console 运行 `AiChatH2SimulationChainDatabaseTest`，结果为 `1 tests started / 1 tests successful / 0 tests failed`；既有 `OpenAiCompatibleProviderMockTest` 与 `AiProviderConfigTest` 仍作为协议兼容与配置约束证据保留。
- 补充证据：扩展 `AiChatControllerH2SimulationTest` 后，再用窄编译 + JUnit Console 定向执行 `BizAiChatAdminController.testConnection(...)`、`BizAiChatController.chat(...)` 与 `BizAiChatController.stream(...)` 的控制器级 H2，结果为 `5 tests started / 5 tests successful / 0 tests failed`。
- 补充证据：进一步补齐 OpenAI 兼容协议的畸形响应分支后，再用窄编译 + JUnit Console 联合回归 `OpenAiCompatibleProviderMockTest`、`AiChatH2SimulationChainDatabaseTest` 与 `AiChatControllerH2SimulationTest`，结果为 `10 tests started / 10 tests successful / 0 tests failed`。
- 已验证路径：
  - OpenAI / DeepSeek / Kimi / GLM 四家 OpenAI 兼容协议同步调用、SSE 流式输出、认证失败、限流错误；
  - AI 业务入口 H2 审计：同步成功、流式成功、认证失败、限流、quota exceeded、超时、无效请求；
  - AI 协议异常分支：OpenAI 兼容同步接口的畸形 JSON/不可解析响应、200 纯文本错误体、流式 SSE 的畸形 chunk，均已通过本地 HTTP/SSE mock 触发；
  - AI 业务入口 H2 用量副作用：同步响应 `usage.promptTokens/completionTokens/totalTokens` 与审计 `inputTokenCount/outputTokenCount` 已逐步查库验证；流式完成响应也已补 usage 回填与审计落库；
  - AI 业务入口 H2 异常归类：同步畸形 JSON 与流式畸形 SSE 已归类为 `InvalidUpstreamResponse`，并逐步查 `ai_audit.status/error_type/input_token_count/output_token_count`；
  - AI 控制器 H2：`BizAiChatAdminController.testConnection(...)` 已覆盖成功连通与 quota exceeded 失败；`BizAiChatController.chat(...)` 已覆盖客户端同步聊天成功返回 usage；`BizAiChatController.stream(...)` 已覆盖 SSE `Delta/Complete` 成功流、`Error` 失败流与完成响应 usage，并逐步查 `ai_audit` 的 `status/error_type/input_token_count/output_token_count`；
  - AI 控制器 H2：`BizAiChatAdminController.testConnection(...)` 现已额外覆盖同步畸形 JSON 返回 `InvalidUpstreamResponse`；`BizAiChatController.chat(...)` 现已额外覆盖 200 纯文本错误体返回 `InvalidUpstreamResponse`；`BizAiChatController.stream(...)` 现已额外覆盖畸形 SSE chunk 触发 `Error` 事件，并逐步查 `ai_audit`；
  - 提供商默认模型别名、禁用模型别名和未注册别名校验。
- 剩余边界：当前已补 token usage 审计、quota exceeded 错误分支，以及 OpenAI 兼容协议的畸形 JSON / 纯文本响应 / 畸形 SSE 响应边界，但仍未验证真实供应商凭据、真实余额/账户配额扣减副作用、供应商级重试策略、更多 SSE 中途断流/半包场景与生产/Sandbox 联调。

### 消息 / 短信 / 邮件（2026-08-26）

- 已验证范围：
  - `services-impl/src/test/java/com/levin/oak/base/biz/InboundEmailRelayH2SimulationChainDatabaseTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/InboundEmailRelayControllerH2SimulationTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/InboundEmailRelayServicePluginTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/DefaultEmailVerifyServicePluginTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/DefaultSmsVerifyServicePluginTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/Sms4JSmsSendServicePluginProtocolSimulationTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/DefaultEmailSendServicePluginProtocolSimulationTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/WlwxSmsSendServicePluginProtocolSimulationTest.java`
  - `services-impl/src/test/java/com/levin/oak/base/biz/plugin/robot/RobotTextMsgSendPluginTest.java`
- 通过证据：Sms4J、默认邮件和未来无线的 loopback 协议模拟分别覆盖成功、业务拒绝、网关失败、畸形响应和重复发送。
- 通过证据：
  - 既有消息/邮件测试资产使用窄编译 + JUnit Console 运行上述 5 组测试，结果为 `12 tests started / 12 tests successful / 0 tests failed`；
  - 新增 `InboundEmailRelayControllerH2SimulationTest` 后，再用窄编译 + JUnit Console 定向执行 `BizEmailRelayRouteController.preview/previewDns/sync/removeProviderResource` 的控制器级 H2 闭环，结果为 `1 tests started / 1 tests successful / 0 tests failed`；
  - 新增 `Sms4JSmsSendServicePluginProtocolSimulationTest` 后，Sms4J 插件已通过 loopback HTTP provider 覆盖成功、业务拒绝、HTTP 500 业务失败、畸形响应、重复发送，结果为 `5 tests started / 5 tests successful / 0 tests failed`；
  - 新增 `DefaultEmailSendServicePluginProtocolSimulationTest` 后，默认邮件发送已通过 loopback SMTP 协议模拟覆盖成功、重复成功、RCPT 拒绝、DATA 拒绝、写完报文后断连，结果为 `5 tests started / 5 tests successful / 0 tests failed`；
  - 新增 `WlwxSmsSendServicePluginProtocolSimulationTest` 后，未来无线短信已通过 loopback HTTP 协议模拟覆盖成功、业务失败、HTTP 500 业务失败、畸形响应、重复发送，结果为 `5 tests started / 5 tests successful / 0 tests failed`；
- 已验证路径：
  - Forward Email 入站中转业务入口 H2：预检、DNS 预检、首次同步、已绑定 alias 重同步、删除、无 providerRouteId 删除、未受管 alias 冲突；
  - Forward Email 控制器级 H2：`BizEmailRelayRouteController.preview/previewDns/sync/removeProviderResource` 已覆盖预检、DNS 预检、首次同步、重同步、删除提供商资源、同名未受管 alias 冲突与私网 webhook 预检失败，并逐步查 `email_relay_route`；
  - Forward Email 协议层：alias 预览、Webhook 目标校验、只更新受管 alias、避免覆盖未受管 alias；
  - 邮件验证码：发送成功、供应商拒绝、单次消费、重复校验失败，并通过 `VerifyCodeAudit` 落库生成/校验动作；
  - 短信验证码：发送成功、供应商拒绝、单次消费、重复校验失败，并通过 `VerifyCodeAudit` 落库生成/校验动作；
  - Sms4J 协议层：`newConfig -> providerFactory.createSms -> sendMessage` 已通过本地 loopback provider 验证成功、业务拒绝、HTTP 500 业务失败、畸形响应、重复发送，以及 supplier / configId / templateId / signName / phone / code 负载；
  - 默认邮件发送协议层：真实 `JavaMailSenderImpl` 已通过本地 SMTP 回环协议验证成功、重复成功、RCPT 拒绝、DATA 拒绝、写完 DATA 后断连；
  - 未来无线协议层：真实 HTTP POST JSON 已通过本地回环网关验证成功、业务失败、HTTP 500 业务失败、畸形响应、重复发送，以及模板/手机号/变量负载；
  - 机器人消息：幂等去重、发送成功、发送失败错误返回。
- 剩余边界：消息通道尚未接入真正的异步 delivery receipt、重试回执或终态送达明细；这些边界需要供应商回执能力后再单独设计持久化模型。
  代码级证据：
  - `DefaultEmailVerifyServicePlugin` / `DefaultSmsVerifyServicePlugin` 通过 `RMapCache` 写入和一次性消费验证码，现已额外落 `VerifyCodeAudit`；
  - `RobotTextMsgSendPlugin` 的通用 `sendMsg()` 入口现已真正复用通知发送链路并补充投递明细；
  - 这些路径仍未接入真正的供应商 delivery receipt / retry 回执实体，也没有复用到 `NoticeProcessLog`。
