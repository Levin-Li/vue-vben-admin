# Design: Custom Traffic Control

## Architecture

The feature adds a new rule model and runtime enforcement path:

```
request
  -> TenantFilter sets current tenant
  -> existing URL access control handles access decisions
  -> TrafficControlInterceptor evaluates traffic-control rules
  -> existing controller authorization/resource authorization continue
  -> business controller executes
```

The exact registration order should keep traffic control before business controller execution and after tenant context is available. If implementation evidence shows URL ACL must stay later for compatibility, the traffic-control interceptor may be placed after tenant setup and before controller authorization, but it must not replace any existing access-control interceptor.

## Entity Model

Add a new entity, tentatively named `TrafficControlRule`, extending the same tenant/public entity family used by configurable platform rules where appropriate.

Core fields:

- `id`
- `name`
- `urlPathList`
- `urlPathExcludeList`
- `methodList`
- `domainList`
- `regionList`
- `ipList`
- `ipExcludeList`
- `userTypeList`
- `userRoleList`
- `requestParamRuleList`
- `headerRuleList`
- `limitDimension`
- `algorithm`
- `limitCount`
- `windowSeconds`
- `burstCount`
- `rejectStatus`
- `rejectMessage`
- `exInfo`
- common enable, editable, order, remark, tenant, creator, timestamp, and optimistic-lock fields

`limitDimension` should be an enum or enum-set style configuration with stable constants:

- `Rule`
- `Tenant`
- `User`
- `Ip`
- `Path`
- `Method`
- `Header`
- `Param`

First-version key composition should always include `ruleId`, and then append configured dimensions. `Rule` means all traffic matching that rule shares one bucket. Other dimensions refine the bucket.

`algorithm` should be an enum with a conservative first implementation:

- `FixedWindow`
- `RedissonRateLimiter` or `TokenBucket` when supported by the current Redisson version

The first implementation may ship only one enabled algorithm if it is clearly modeled for extension.

Entity enum declarations must use `@GenNameConstant`, and generated default service/controller files must be created through `simple-dao-codegen`.

## Matching Semantics

Traffic-control matching should follow the current URL ACL mental model:

- Disabled or self-audit-failed rules are ignored.
- URL exclude match bypasses that rule.
- IP exclude match bypasses that rule.
- URL path include/exclude rules support `*` and `?` wildcard matching.
- IP include/exclude rules support `*` and `?` wildcard matching.
- User type and role conditions require a logged-in user; if no logged-in user is available, those rule conditions do not match.
- Request parameter and header conditions are matched from structured rule definitions. If present, every required parameter/header condition must match.
- Include conditions are ANDed: if URL, method, domain, IP, region, user, parameter, and header conditions are all present, every present condition must match.
- A rule with no include condition should not match every request by accident. The traffic-control implementation should reject saving such a rule or ignore it at runtime with a warning.

The implementation should directly reference the matching style and helper behavior used by `UrlAclInterceptor` where it satisfies the traffic-control requirements:

- Reuse `UrlAclUtils.parseItem(...)` for `List<String>` normalization and blank-item filtering.
- Reuse `UrlAclUtils.getUrlPathWithoutContextPath(...)` for path normalization.
- Reference the existing include/exclude and AND-style matching flow from `UrlAclUtils.canPass(...)`.

`UrlAclUtils.getMatcher(...)` must not be used as the only wildcard matcher for traffic control, because it delegates to Spring `PatternMatchUtils.simpleMatch(...)`, which supports `*` matching but does not satisfy the new requirement for `?` single-character matching. Traffic control should add a small dedicated wildcard helper, or a new non-breaking helper method, that supports both `*` and `?` for path, IP, parameter names, parameter values, header names, and header values.

Do not change existing URL ACL behavior unless explicitly required; existing URL ACL rules may rely on the current `PatternMatchUtils.simpleMatch(...)` semantics. The first implementation should keep the new `*` and `?` matcher scoped to traffic-control matching.

## Parameter and Header Rules

Parameter and header matching should be structured data, not dynamic scripts or expression strings.

Suggested shape for each rule item:

- `namePatterns`: parameter or header name patterns, supporting `*` and `?`.
- `valuePatterns`: parameter or header value patterns, supporting `*` and `?`.
- `required`: default `true`.

Rules:

- Parameter/header names and values only need wildcard matching with `*` and `?`.
- A rule item matches when at least one request parameter/header name matches `namePatterns` and at least one value for that name matches `valuePatterns`.
- Empty `valuePatterns` means the parameter/header only needs to exist.
- Header names are case-insensitive and should be normalized before matching.
- Request parameters include query-string parameters and normal form parameters available through `request.getParameter`.
- First version should not read raw JSON request bodies for matching, because consuming request bodies in interceptors can affect downstream business handling and increase memory cost.
- If JSON body matching is required later, it should be a separate extension using a cached request-body wrapper and explicit JSON-path rules.
- Matching must not evaluate Groovy, SpringEL, JavaScript, SQL fragments, templates, or other executable expressions.

## Runtime Evaluation

For each request:

1. Resolve current tenant from tenant context or domain.
2. Resolve current user from `AuthService` if logged in.
3. Load enabled traffic-control rules for the current tenant plus public rules from cache.
4. Filter rules by request match.
5. For each matched rule, build a stable limit key.
6. Evaluate the configured limiter.
7. If any matched rule rejects, return `429 Too Many Requests` and do not execute the business controller.

When multiple rules match, the strictest effective behavior is used because all matched rules must allow the request.

## Limit Key

Key format:

```
traffic-control:{ruleId}:{tenantPart}:{userPart}:{ipPart}:{methodPart}:{pathPart}
```

Rules:

- Always include `ruleId`.
- Only append dimensions selected by `limitDimension`.
- Use safe placeholder values such as `public`, `anonymous`, `no-ip`, or `any` when a selected dimension is unavailable.
- Normalize method to uppercase.
- Normalize path after removing context path.
- Prefer a matched URL pattern for `Path` when available; otherwise use the normalized request path.
- If `Header` or `Param` is selected as a limit dimension, append only configured, normalized header/parameter names and matched values. Do not append all request headers or all request parameters.
- Avoid storing raw unbounded query strings in keys.

## Redis/Redisson Strategy

First-version recommended strategy:

- Formally define the runtime as a distributed rate-limit engine. The interceptor must depend on a `DistributedRateLimitEngine`-style interface rather than directly coupling to Redisson operations.
- Use Redisson as the first default engine implementation because the project already depends on `RedissonClient`.
- Prefer a fixed-window counter for predictable implementation and tests:
  - `RAtomicLong.incrementAndGet()`
  - set expiry to `windowSeconds` when the counter is first created
  - reject when count exceeds `limitCount`
- If Redisson `RRateLimiter` is compatible and easier to verify in the current dependency version, it may be used for token-bucket behavior, but the implementation must include deterministic tests.

Engine replacement rules:

- The interceptor owns request matching, limit-key composition, and HTTP rejection response writing.
- The engine owns distributed quota acquisition only.
- A replacement engine must implement algorithm support detection and return an allow/reject result with the current counter/window TTL needed by the interceptor.
- Unsupported algorithms may fall back to the fixed-window engine in the first version, but the fallback must be logged.

Redis failures should default to fail-open for normal business traffic and log a warning, unless a future security requirement explicitly asks for fail-closed.

## Response

Rejected requests should return:

- HTTP status `429`
- A clear JSON body using the project standard API response shape if available at interceptor time
- `Retry-After` when the remaining window can be calculated
- Optional diagnostic headers:
  - `X-RateLimit-Rule`
  - `X-RateLimit-Limit`
  - `X-RateLimit-Window`

The response must not reveal sensitive rule internals beyond what is useful for operators and clients.

## Admin UI

Add a menu/page named `流量控制` or `接口限流规则`, separate from `URL 访问控制`.

The CRUD page should expose:

- tenant ownership
- rule name
- URL/method/domain/IP/region/user conditions
- limit dimensions
- algorithm
- threshold and window
- enable/order/remark

The UI should make key dimensions visible so operators can tell whether a rule limits per tenant, per user, per IP, per API, or a combination.

## Tests

Backend tests should cover:

- URL/method/IP/user/tenant matching.
- Request parameter and header matching.
- URL and IP exclude behavior.
- Logged-in and anonymous requests.
- Key composition for every supported dimension.
- First request allowed and request over threshold rejected.
- Multiple matching rules where any rejection blocks the request.
- Disabled rule bypass.
- Redis error fail-open behavior if practical to isolate.

## Migration and Code Generation

Implementation must follow repository code-generation rules:

- Add the entity first.
- Compile the `entities` module.
- Run `simple-dao-codegen` from the entity module.
- Do not hand-edit generated default service/controller files.
- Put business behavior into `Biz...Service` and runtime web behavior into the appropriate web module.
