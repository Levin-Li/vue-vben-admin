# c20260825-0012-guard-published-workspace-dependencies

防止前端公共包发布物保留 workspace 或 catalog 依赖协议
