# c20260907-1725-limit-domain-form-columns

Keep domain and certificate create/edit forms within a compact two-column layout.
