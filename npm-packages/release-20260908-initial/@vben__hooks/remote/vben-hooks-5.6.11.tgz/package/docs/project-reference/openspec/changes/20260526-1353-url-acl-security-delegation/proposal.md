# Proposal: URL ACL Security Delegation

## Summary

Keep `SignVerify` and `DataRsaCrypt` as `UrlExAcl` policy types, but move their runtime behavior behind an independent service contract. `UrlExAcl` continues to decide which URL rules match; the security-specific execution is delegated so signature verification and data crypto can evolve outside the ACL matching entity and interceptor branching.

## Scope

- Add an independent URL ACL security handler service contract.
- Delegate `SignVerify` and `DataRsaCrypt` actions from `UrlAclInterceptor` to that service.
- Provide a default implementation that preserves current pass-through behavior when no concrete signature or crypto protocol has been configured.
- Add focused tests proving the interceptor delegates both action types.

## Non-Goals

- No entity field changes.
- No new signature algorithm or encryption protocol in this change.
- No database code generation.
- No dependency on `ClientAppAuthFilter`; URL ACL signature/crypto is an independent request-protection mechanism, not client-app login.

## Risks

- A default pass-through handler preserves compatibility, but does not enforce security by itself. Concrete protocol enforcement must be implemented in the delegated service before relying on these ACL types as hard controls.
