## ADDED Requirements

### Requirement: Shared CRUD import mappings convert values before submission

The shared CRUD import flow SHALL let an operator map each file column to a writable target field and choose a fixed, supported converter for that mapping. It SHALL preview converted values and surface row-level conversion errors before it calls `batchCreate`.

#### Scenario: Convert text columns to a number and a date

- **WHEN** an operator maps a text column to a numeric field and another text column to a date field
- **THEN** the preview and submitted records contain a finite number and a normalized `YYYY-MM-DD` date
- **AND** an invalid value identifies its source row and target field and prevents import submission.

### Requirement: Shared CRUD export mappings support headers and conversion

The shared CRUD export flow SHALL let an operator select a source field, set its output header alias, order it, and choose a fixed supported output conversion. It SHALL store these choices in export templates.

#### Scenario: Export a custom numeric column

- **WHEN** an operator sets an output header alias and selects the number conversion for a source field
- **THEN** the generated spreadsheet uses the custom header and deterministic numeric text for that column
- **AND** reapplying the saved template restores the header, order, selection, and conversion.

### Requirement: Shared CRUD import accepts standard XLSX workbooks

The shared CRUD import flow SHALL accept a normal `.xlsx` workbook and read the first worksheet into the same header-and-row shape used by CSV and legacy Excel XML imports.

#### Scenario: Import a first-sheet XLSX file

- **WHEN** an operator selects a valid `.xlsx` workbook containing headers and data in its first worksheet
- **THEN** the mapping dialog shows its headers and rows
- **AND** the operator can use the same mapping, preview, validation, and batch-submit flow as CSV.
