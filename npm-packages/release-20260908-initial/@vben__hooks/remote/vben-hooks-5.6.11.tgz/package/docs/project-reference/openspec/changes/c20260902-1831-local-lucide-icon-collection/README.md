# c20260902-1831-local-lucide-icon-collection

Bundle and register Lucide icons locally so runtime rendering does not request external Iconify APIs.
