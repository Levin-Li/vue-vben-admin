<script setup lang="ts">
import type { SelectOption } from '@vben/types';

import { computed } from 'vue';

import { $t } from '@vben/locales';

import NumberFieldItem from '../number-field-item.vue';
import SelectItem from '../select-item.vue';
import SwitchItem from '../switch-item.vue';
import ShellStyle from './shell-style.vue';

defineOptions({
  name: 'PreferenceTabsConfig',
});

defineProps<{ disabled?: boolean }>();

const tabbarEnable = defineModel<boolean>('tabbarEnable');
const tabbarHeight = defineModel<number>('tabbarHeight');
const tabbarMarginTop = defineModel<number>('tabbarMarginTop');
const tabbarMarginRight = defineModel<number>('tabbarMarginRight');
const tabbarMarginBottom = defineModel<number>('tabbarMarginBottom');
const tabbarMarginLeft = defineModel<number>('tabbarMarginLeft');
const tabbarRadiusTopLeft = defineModel<number>('tabbarRadiusTopLeft');
const tabbarRadiusTopRight = defineModel<number>('tabbarRadiusTopRight');
const tabbarRadiusBottomRight = defineModel<number>('tabbarRadiusBottomRight');
const tabbarRadiusBottomLeft = defineModel<number>('tabbarRadiusBottomLeft');
const tabbarBorderTopWidth = defineModel<number>('tabbarBorderTopWidth');
const tabbarBorderRightWidth = defineModel<number>('tabbarBorderRightWidth');
const tabbarBorderBottomWidth = defineModel<number>('tabbarBorderBottomWidth');
const tabbarBorderLeftWidth = defineModel<number>('tabbarBorderLeftWidth');
const tabbarShowIcon = defineModel<boolean>('tabbarShowIcon');
const tabbarPersist = defineModel<boolean>('tabbarPersist');
const tabbarVisitHistory = defineModel<boolean>('tabbarVisitHistory');
const tabbarDraggable = defineModel<boolean>('tabbarDraggable');
const tabbarWheelable = defineModel<boolean>('tabbarWheelable');
const tabbarStyleType = defineModel<string>('tabbarStyleType');
const tabbarShowMore = defineModel<boolean>('tabbarShowMore');
const tabbarShowMaximize = defineModel<boolean>('tabbarShowMaximize');
const tabbarMaxCount = defineModel<number>('tabbarMaxCount');
const tabbarMiddleClickToClose = defineModel<boolean>(
  'tabbarMiddleClickToClose',
);

const styleItems = computed((): SelectOption[] => [
  {
    label: $t('preferences.tabbar.styleType.chrome'),
    value: 'chrome',
  },
  {
    label: $t('preferences.tabbar.styleType.plain'),
    value: 'plain',
  },
  {
    label: $t('preferences.tabbar.styleType.card'),
    value: 'card',
  },

  {
    label: $t('preferences.tabbar.styleType.brisk'),
    value: 'brisk',
  },
]);
</script>

<template>
  <SwitchItem v-model="tabbarEnable" :disabled="disabled">
    {{ $t('preferences.tabbar.enable') }}
  </SwitchItem>
  <NumberFieldItem
    v-model="tabbarHeight"
    :disabled="!tabbarEnable || disabled"
    :max="120"
    :min="28"
    :step="2"
  >
    {{ $t('preferences.tabbar.height') }}
  </NumberFieldItem>
  <SwitchItem v-model="tabbarPersist" :disabled="!tabbarEnable">
    {{ $t('preferences.tabbar.persist') }}
  </SwitchItem>
  <SwitchItem
    v-model="tabbarVisitHistory"
    :disabled="!tabbarEnable"
    :tip="$t('preferences.tabbar.visitHistoryTip')"
  >
    {{ $t('preferences.tabbar.visitHistory') }}
  </SwitchItem>
  <NumberFieldItem
    v-model="tabbarMaxCount"
    :disabled="!tabbarEnable"
    :max="30"
    :min="0"
    :step="5"
    :tip="$t('preferences.tabbar.maxCountTip')"
  >
    {{ $t('preferences.tabbar.maxCount') }}
  </NumberFieldItem>
  <SwitchItem v-model="tabbarDraggable" :disabled="!tabbarEnable">
    {{ $t('preferences.tabbar.draggable') }}
  </SwitchItem>
  <SwitchItem
    v-model="tabbarWheelable"
    :disabled="!tabbarEnable"
    :tip="$t('preferences.tabbar.wheelableTip')"
  >
    {{ $t('preferences.tabbar.wheelable') }}
  </SwitchItem>
  <SwitchItem v-model="tabbarMiddleClickToClose" :disabled="!tabbarEnable">
    {{ $t('preferences.tabbar.middleClickClose') }}
  </SwitchItem>
  <SwitchItem v-model="tabbarShowIcon" :disabled="!tabbarEnable">
    {{ $t('preferences.tabbar.icon') }}
  </SwitchItem>
  <SwitchItem v-model="tabbarShowMore" :disabled="!tabbarEnable">
    {{ $t('preferences.tabbar.showMore') }}
  </SwitchItem>
  <SwitchItem v-model="tabbarShowMaximize" :disabled="!tabbarEnable">
    {{ $t('preferences.tabbar.showMaximize') }}
  </SwitchItem>
  <SelectItem v-model="tabbarStyleType" :items="styleItems">
    {{ $t('preferences.tabbar.styleType.title') }}
  </SelectItem>
  <ShellStyle
    v-model:border-bottom-width="tabbarBorderBottomWidth"
    v-model:border-left-width="tabbarBorderLeftWidth"
    v-model:border-right-width="tabbarBorderRightWidth"
    v-model:border-top-width="tabbarBorderTopWidth"
    v-model:margin-bottom="tabbarMarginBottom"
    v-model:margin-left="tabbarMarginLeft"
    v-model:margin-right="tabbarMarginRight"
    v-model:margin-top="tabbarMarginTop"
    v-model:radius-top-left="tabbarRadiusTopLeft"
    v-model:radius-top-right="tabbarRadiusTopRight"
    v-model:radius-bottom-right="tabbarRadiusBottomRight"
    v-model:radius-bottom-left="tabbarRadiusBottomLeft"
    :disabled="!tabbarEnable || disabled"
  />
</template>
