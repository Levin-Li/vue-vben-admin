<script setup lang="ts">
import type { CSSProperties } from 'vue';

import type { VbenLayoutProps } from './vben-layout';

import { computed, ref, watch } from 'vue';

import {
  SCROLL_FIXED_CLASS,
  useLayoutFooterStyle,
  useLayoutHeaderStyle,
} from '@vben-core/composables';
import { IconifyIcon } from '@vben-core/icons';
import { VbenIconButton } from '@vben-core/shadcn-ui';
import { ELEMENT_ID_MAIN_CONTENT } from '@vben-core/shared/constants';

import { useMouse, useScroll, useThrottleFn } from '@vueuse/core';

import {
  LayoutContent,
  LayoutFooter,
  LayoutHeader,
  LayoutSidebar,
  LayoutTabbar,
} from './components';
import { useLayout } from './hooks/use-layout';

interface Props extends VbenLayoutProps {}

defineOptions({
  name: 'VbenLayout',
});

const props = withDefaults(defineProps<Props>(), {
  baseBackgroundColor: 'hsl(var(--background-deep))',
  contentCompact: 'wide',
  contentCompactWidth: 1200,
  contentBackgroundColor: 'transparent',
  contentPadding: 0,
  contentMarginBottom: 0,
  contentMarginLeft: 0,
  contentMarginRight: 0,
  contentMarginTop: 0,
  contentRadiusTopLeft: 0,
  contentRadiusTopRight: 0,
  contentRadiusBottomRight: 0,
  contentRadiusBottomLeft: 0,
  contentBorderTopWidth: 0,
  contentBorderRightWidth: 0,
  contentBorderBottomWidth: 0,
  contentBorderLeftWidth: 0,
  footerEnable: false,
  footerFixed: true,
  footerHeight: 32,
  headerHeight: 50,
  headerMarginTop: 0,
  headerMarginRight: 0,
  headerMarginBottom: 0,
  headerMarginLeft: 0,
  headerRadiusTopLeft: 0,
  headerRadiusTopRight: 0,
  headerRadiusBottomRight: 0,
  headerRadiusBottomLeft: 0,
  headerBorderTopWidth: 0,
  headerBorderRightWidth: 0,
  headerBorderBottomWidth: 0,
  headerBorderLeftWidth: 0,
  headerHidden: false,
  headerMode: 'fixed',
  headerToggleSidebarButton: true,
  headerVisible: true,
  isMobile: false,
  layout: 'sidebar-nav',
  sidebarCollapsedButton: true,
  sidebarCollapseShowTitle: false,
  sidebarExtraCollapsedWidth: 60,
  sidebarExtraMenuVisible: true,
  sidebarFixedButton: true,
  sidebarHidden: false,
  sidebarMixedWidth: 80,
  sidebarMixedMenuGap: 6,
  sidebarMenuItemGap: 4,
  sidebarTheme: 'dark',
  sidebarThemeSub: 'dark',
  sidebarWidth: 180,
  sidebarMarginTop: 0,
  sidebarMarginRight: 0,
  sidebarMarginBottom: 0,
  sidebarMarginLeft: 0,
  sidebarRadiusTopLeft: 0,
  sidebarRadiusTopRight: 0,
  sidebarRadiusBottomRight: 0,
  sidebarRadiusBottomLeft: 0,
  sidebarBorderTopWidth: 0,
  sidebarBorderRightWidth: 0,
  sidebarBorderBottomWidth: 0,
  sidebarBorderLeftWidth: 0,
  sideCollapseWidth: 60,
  tabbarEnable: true,
  tabbarHeight: 40,
  tabbarBackgroundColor: 'hsl(var(--background))',
  tabbarMarginTop: 0,
  tabbarMarginRight: 0,
  tabbarMarginBottom: 0,
  tabbarMarginLeft: 0,
  tabbarRadiusTopLeft: 0,
  tabbarRadiusTopRight: 0,
  tabbarRadiusBottomRight: 0,
  tabbarRadiusBottomLeft: 0,
  tabbarBorderTopWidth: 0,
  tabbarBorderRightWidth: 0,
  tabbarBorderBottomWidth: 1,
  tabbarBorderLeftWidth: 0,
  zIndex: 200,
});

const emit = defineEmits<{ sideMouseLeave: []; toggleSidebar: [] }>();
const sidebarCollapse = defineModel<boolean>('sidebarCollapse', {
  default: false,
});
const sidebarExtraVisible = defineModel<boolean>('sidebarExtraVisible');
const sidebarExtraCollapse = defineModel<boolean>('sidebarExtraCollapse', {
  default: false,
});
const sidebarExpandOnHover = defineModel<boolean>('sidebarExpandOnHover', {
  default: false,
});
const sidebarEnable = defineModel<boolean>('sidebarEnable', { default: true });

// side是否处于hover状态展开菜单中
const sidebarExpandOnHovering = ref(false);
const headerIsHidden = ref(false);
const contentRef = ref();

const {
  arrivedState,
  directions,
  isScrolling,
  y: scrollY,
} = useScroll(document);

const { setLayoutHeaderHeight } = useLayoutHeaderStyle();
const { setLayoutFooterHeight } = useLayoutFooterStyle();

const { y: mouseY } = useMouse({ target: contentRef, type: 'client' });

const {
  currentLayout,
  isFullContent,
  isHeaderMixedNav,
  isHeaderNav,
  isMixedNav,
  isSidebarMixedNav,
} = useLayout(props);

/**
 * 顶栏是否自动隐藏
 */
const isHeaderAutoMode = computed(() => props.headerMode === 'auto');

const headerOuterHeight = computed(() => {
  return props.headerHeight + props.headerMarginTop + props.headerMarginBottom;
});

const headerWrapperHeight = computed(() => {
  let height = 0;
  if (props.headerVisible && !props.headerHidden) {
    height += headerOuterHeight.value;
  }
  if (props.tabbarEnable) {
    height +=
      props.tabbarHeight + props.tabbarMarginTop + props.tabbarMarginBottom;
  }
  return height;
});

const getSideCollapseWidth = computed(() => {
  const { sidebarCollapseShowTitle, sidebarMixedWidth, sideCollapseWidth } =
    props;

  return sidebarCollapseShowTitle ||
    isSidebarMixedNav.value ||
    isHeaderMixedNav.value
    ? sidebarMixedWidth
    : sideCollapseWidth;
});

/**
 * 动态获取侧边区域是否可见
 */
const sidebarEnableState = computed(() => {
  return !isHeaderNav.value && sidebarEnable.value;
});

/**
 * 侧边区域离顶部高度
 */
const sidebarOffsetTop = computed(() => {
  const { isMobile } = props;
  return isMixedNav.value && !isMobile ? headerOuterHeight.value : 0;
});

/**
 * 动态获取侧边宽度
 */
const getSidebarWidth = computed(() => {
  const { isMobile, sidebarHidden, sidebarMixedWidth, sidebarWidth } = props;
  let width = 0;

  if (sidebarHidden) {
    return width;
  }

  if (
    !sidebarEnableState.value ||
    (sidebarHidden &&
      !isSidebarMixedNav.value &&
      !isMixedNav.value &&
      !isHeaderMixedNav.value)
  ) {
    return width;
  }

  if ((isHeaderMixedNav.value || isSidebarMixedNav.value) && !isMobile) {
    width = sidebarMixedWidth;
  } else if (sidebarCollapse.value) {
    width = isMobile ? 0 : getSideCollapseWidth.value;
  } else {
    width = sidebarWidth;
  }
  return width;
});

/**
 * 获取扩展区域宽度
 */
const sidebarExtraWidth = computed(() => {
  const { sidebarExtraCollapsedWidth, sidebarWidth } = props;

  return sidebarExtraCollapse.value ? sidebarExtraCollapsedWidth : sidebarWidth;
});

/**
 * 是否侧边栏模式，包含混合侧边
 */
const isSideMode = computed(
  () =>
    currentLayout.value === 'mixed-nav' ||
    currentLayout.value === 'sidebar-mixed-nav' ||
    currentLayout.value === 'sidebar-nav' ||
    currentLayout.value === 'header-mixed-nav' ||
    currentLayout.value === 'header-sidebar-nav',
);

/**
 * header fixed值
 */
const headerFixed = computed(() => {
  const { headerMode } = props;
  return (
    isMixedNav.value ||
    headerMode === 'fixed' ||
    headerMode === 'auto-scroll' ||
    headerMode === 'auto'
  );
});

const showSidebar = computed(() => {
  return isSideMode.value && sidebarEnable.value && !props.sidebarHidden;
});

const sidebarHorizontalMargins = computed(() => {
  if (!showSidebar.value || props.isMobile) {
    return 0;
  }
  return props.sidebarMarginLeft + props.sidebarMarginRight;
});

/**
 * 遮罩可见性
 */
const maskVisible = computed(() => !sidebarCollapse.value && props.isMobile);

const mainStyle = computed(() => {
  let width = '100%';
  let sidebarAndExtraWidth = 'unset';
  if (
    headerFixed.value &&
    currentLayout.value !== 'header-nav' &&
    currentLayout.value !== 'mixed-nav' &&
    currentLayout.value !== 'header-sidebar-nav' &&
    showSidebar.value &&
    !props.isMobile
  ) {
    // fixed模式下生效
    const isSideNavEffective =
      (isSidebarMixedNav.value || isHeaderMixedNav.value) &&
      sidebarExtraVisible.value &&
      props.sidebarExtraMenuVisible;

    if (isSideNavEffective) {
      const sideCollapseWidth = sidebarCollapse.value
        ? getSideCollapseWidth.value
        : props.sidebarMixedWidth;
      const sideWidth = sidebarExtraCollapse.value
        ? props.sidebarExtraCollapsedWidth
        : props.sidebarWidth;

      // 100% - 侧边菜单混合宽度 - 菜单宽度
      sidebarAndExtraWidth = `${
        sideCollapseWidth + sideWidth + sidebarHorizontalMargins.value * 2
      }px`;
      width = `calc(100% - ${sidebarAndExtraWidth})`;
    } else {
      sidebarAndExtraWidth =
        sidebarExpandOnHovering.value && !sidebarExpandOnHover.value
          ? `${getSideCollapseWidth.value + sidebarHorizontalMargins.value}px`
          : `${getSidebarWidth.value + sidebarHorizontalMargins.value}px`;
      width = `calc(100% - ${sidebarAndExtraWidth})`;
    }
  }
  return {
    sidebarAndExtraWidth,
    width,
  };
});

// 计算 tabbar 的结构定位偏移
const tabbarLayout = computed(() => {
  let marginLeft = 0;
  let widthOffset = 0;

  if (isMixedNav.value && !props.sidebarHidden && sidebarEnable.value) {
    // 鼠标在侧边栏上时，且侧边栏展开时的宽度
    const onHoveringWidth = sidebarExpandOnHover.value
      ? props.sidebarWidth
      : getSideCollapseWidth.value;

    // 设置 marginLeft，根据侧边栏是否折叠来决定
    marginLeft = sidebarCollapse.value
      ? getSideCollapseWidth.value
      : onHoveringWidth;

    widthOffset = sidebarCollapse.value
      ? getSidebarWidth.value
      : onHoveringWidth;
  }

  return {
    marginLeft,
    widthOffset,
  };
});

const contentStyle = computed((): CSSProperties => {
  const { footerEnable, footerFixed, footerHeight } = props;
  return {
    paddingBottom: `${footerEnable && footerFixed ? footerHeight : 0}px`,
  };
});

const contentOffsetTop = computed(() => {
  const fixed = headerFixed.value;

  return fixed &&
    !isFullContent.value &&
    !headerIsHidden.value &&
    (!isHeaderAutoMode.value || scrollY.value < headerWrapperHeight.value)
    ? headerWrapperHeight.value
    : 0;
});

const headerZIndex = computed(() => {
  const { zIndex } = props;
  const offset = isMixedNav.value ? 1 : 0;
  return zIndex + offset;
});

const headerWrapperStyle = computed((): CSSProperties => {
  const fixed = headerFixed.value;
  return {
    backgroundColor: props.baseBackgroundColor,
    height: isFullContent.value ? '0' : `${headerWrapperHeight.value}px`,
    left: isMixedNav.value ? 0 : mainStyle.value.sidebarAndExtraWidth,
    position: fixed ? 'fixed' : 'static',
    top:
      headerIsHidden.value || isFullContent.value
        ? `-${headerWrapperHeight.value}px`
        : 0,
    width: mainStyle.value.width,
    'z-index': headerZIndex.value,
  };
});

/**
 * 侧边栏z-index
 */
const sidebarZIndex = computed(() => {
  const { isMobile, zIndex } = props;
  let offset = isMobile || isSideMode.value ? 1 : -1;

  if (isMixedNav.value) {
    offset += 1;
  }

  return zIndex + offset;
});

const footerWidth = computed(() => {
  if (!props.footerFixed) {
    return '100%';
  }

  return mainStyle.value.width;
});

const maskStyle = computed((): CSSProperties => {
  return { zIndex: props.zIndex };
});

const showHeaderToggleButton = computed(() => {
  return (
    props.isMobile ||
    (props.headerToggleSidebarButton &&
      isSideMode.value &&
      !isSidebarMixedNav.value &&
      !isMixedNav.value &&
      !props.isMobile)
  );
});

const showHeaderLogo = computed(() => {
  return !isSideMode.value || isMixedNav.value || props.isMobile;
});

watch(
  () => props.isMobile,
  (val) => {
    if (val) {
      sidebarCollapse.value = true;
    }
  },
  {
    immediate: true,
  },
);

watch(
  [() => headerWrapperHeight.value, () => isFullContent.value],
  ([height]) => {
    setLayoutHeaderHeight(isFullContent.value ? 0 : height);
  },
  {
    immediate: true,
  },
);

watch(
  () => props.footerHeight,
  (height: number) => {
    setLayoutFooterHeight(height);
  },
  {
    immediate: true,
  },
);

{
  const HEADER_TRIGGER_DISTANCE = 12;

  watch(
    [() => props.headerMode, () => mouseY.value, () => headerIsHidden.value],
    () => {
      if (!isHeaderAutoMode.value || isMixedNav.value || isFullContent.value) {
        if (props.headerMode !== 'auto-scroll') {
          headerIsHidden.value = false;
        }
        return;
      }

      const isInTriggerZone = mouseY.value <= HEADER_TRIGGER_DISTANCE;
      const isInHeaderZone =
        !headerIsHidden.value && mouseY.value <= headerWrapperHeight.value;

      headerIsHidden.value = !(isInTriggerZone || isInHeaderZone);
    },
    {
      immediate: true,
    },
  );
}

{
  const checkHeaderIsHidden = useThrottleFn((top, bottom, topArrived) => {
    if (scrollY.value < headerWrapperHeight.value) {
      headerIsHidden.value = false;
      return;
    }
    if (topArrived) {
      headerIsHidden.value = false;
      return;
    }

    if (top) {
      headerIsHidden.value = false;
    } else if (bottom) {
      headerIsHidden.value = true;
    }
  }, 300);

  watch(
    () => scrollY.value,
    () => {
      if (
        props.headerMode !== 'auto-scroll' ||
        isMixedNav.value ||
        isFullContent.value
      ) {
        return;
      }
      if (isScrolling.value) {
        checkHeaderIsHidden(
          directions.top,
          directions.bottom,
          arrivedState.top,
        );
      }
    },
  );
}

function handleClickMask() {
  sidebarCollapse.value = true;
}

function handleHeaderToggle() {
  if (props.isMobile) {
    sidebarCollapse.value = false;
  } else {
    emit('toggleSidebar');
  }
}

const idMainContent = ELEMENT_ID_MAIN_CONTENT;
</script>

<template>
  <div
    :class="[
      'relative flex w-full',
      isMobile ? 'min-h-full' : 'h-full min-h-0',
    ]"
  >
    <LayoutSidebar
      v-if="sidebarEnableState"
      v-model:collapse="sidebarCollapse"
      v-model:expand-on-hover="sidebarExpandOnHover"
      v-model:expand-on-hovering="sidebarExpandOnHovering"
      v-model:extra-collapse="sidebarExtraCollapse"
      v-model:extra-visible="sidebarExtraVisible"
      :show-collapse-button="sidebarCollapsedButton"
      :show-fixed-button="sidebarFixedButton"
      :collapse-width="getSideCollapseWidth"
      :dom-visible="!isMobile"
      :extra-width="sidebarExtraWidth"
      :extra-menu-visible="sidebarExtraMenuVisible"
      :fixed-extra="sidebarExpandOnHover"
      :header-height="isMixedNav ? 0 : headerHeight"
      :is-sidebar-mixed="isSidebarMixedNav || isHeaderMixedNav"
      :offset-top="sidebarOffsetTop"
      :menu-background-color="sidebarMenuBackgroundColor"
      :menu-hover-background-color="sidebarMenuHoverBackgroundColor"
      :menu-use-primary-active-color="sidebarMenuUsePrimaryActiveColor"
      :mixed-width="sidebarMixedWidth"
      :extra-gap="sidebarMixedMenuGap"
      :menu-item-gap="sidebarMenuItemGap"
      :margin-bottom="sidebarMarginBottom"
      :margin-left="sidebarMarginLeft"
      :margin-right="sidebarMarginRight"
      :margin-top="sidebarMarginTop"
      :radius-top-left="sidebarRadiusTopLeft"
      :radius-top-right="sidebarRadiusTopRight"
      :radius-bottom-right="sidebarRadiusBottomRight"
      :radius-bottom-left="sidebarRadiusBottomLeft"
      :border-top-width="sidebarBorderTopWidth"
      :border-right-width="sidebarBorderRightWidth"
      :border-bottom-width="sidebarBorderBottomWidth"
      :border-left-width="sidebarBorderLeftWidth"
      :show="showSidebar"
      :theme="sidebarTheme"
      :theme-color="sidebarThemeColor"
      :theme-sub="sidebarThemeSub"
      :theme-sub-color="sidebarThemeSubColor"
      :width="getSidebarWidth"
      :z-index="sidebarZIndex"
      @leave="() => emit('sideMouseLeave')"
    >
      <template v-if="isSideMode && !isMixedNav" #logo>
        <slot name="logo"></slot>
      </template>

      <template v-if="isSidebarMixedNav || isHeaderMixedNav">
        <slot name="mixed-menu"></slot>
      </template>
      <template v-else>
        <slot name="menu"></slot>
      </template>

      <template #extra>
        <slot name="side-extra"></slot>
      </template>
      <template #extra-title>
        <slot name="side-extra-title"></slot>
      </template>
    </LayoutSidebar>

    <div
      ref="contentRef"
      :class="[
        'flex flex-1 flex-col transition-all duration-300 ease-in',
        isMobile ? 'overflow-visible' : 'min-h-0 overflow-hidden',
      ]"
    >
      <div
        :class="[
          {
            'shadow-[0_16px_24px_hsl(var(--background))]': scrollY > 20,
          },
          SCROLL_FIXED_CLASS,
        ]"
        :style="headerWrapperStyle"
        class="overflow-visible transition-all duration-200"
      >
        <LayoutHeader
          v-if="headerVisible"
          :full-width="!isSideMode"
          :height="headerHeight"
          :margin-top="headerMarginTop"
          :margin-right="headerMarginRight"
          :margin-bottom="headerMarginBottom"
          :margin-left="headerMarginLeft"
          :radius-top-left="headerRadiusTopLeft"
          :radius-top-right="headerRadiusTopRight"
          :radius-bottom-right="headerRadiusBottomRight"
          :radius-bottom-left="headerRadiusBottomLeft"
          :border-top-width="headerBorderTopWidth"
          :border-right-width="headerBorderRightWidth"
          :border-bottom-width="headerBorderBottomWidth"
          :border-left-width="headerBorderLeftWidth"
          :is-mobile="isMobile"
          :show="!isFullContent && !headerHidden"
          :sidebar-width="sidebarWidth"
          :theme="headerTheme"
          :theme-color="headerThemeColor"
          :width="mainStyle.width"
          :z-index="headerZIndex"
        >
          <template v-if="showHeaderLogo" #logo>
            <slot name="logo"></slot>
          </template>

          <template #toggle-button>
            <VbenIconButton
              v-if="showHeaderToggleButton"
              class="header-theme-control my-0 mr-1 rounded-md"
              @click="handleHeaderToggle"
            >
              <IconifyIcon v-if="showSidebar" icon="ep:fold" />
              <IconifyIcon v-else icon="ep:expand" />
            </VbenIconButton>
          </template>
          <slot name="header"></slot>
        </LayoutHeader>

        <LayoutTabbar
          v-if="tabbarEnable"
          :background-color="tabbarBackgroundColor"
          :border-bottom-width="tabbarBorderBottomWidth"
          :border-left-width="tabbarBorderLeftWidth"
          :border-right-width="tabbarBorderRightWidth"
          :border-top-width="tabbarBorderTopWidth"
          :height="tabbarHeight"
          :layout-margin-left="tabbarLayout.marginLeft"
          :layout-width-offset="tabbarLayout.widthOffset"
          :margin-bottom="tabbarMarginBottom"
          :margin-left="tabbarMarginLeft"
          :margin-right="tabbarMarginRight"
          :margin-top="tabbarMarginTop"
          :radius-bottom-left="tabbarRadiusBottomLeft"
          :radius-bottom-right="tabbarRadiusBottomRight"
          :radius-top-left="tabbarRadiusTopLeft"
          :radius-top-right="tabbarRadiusTopRight"
        >
          <slot name="tabbar"></slot>
        </LayoutTabbar>
      </div>

      <!-- </div> -->
      <LayoutContent
        :id="idMainContent"
        :content-compact="contentCompact"
        :content-compact-width="contentCompactWidth"
        :background-color="contentBackgroundColor"
        :offset-top="contentOffsetTop"
        :padding="contentPadding"
        :margin-bottom="contentMarginBottom"
        :margin-left="contentMarginLeft"
        :margin-right="contentMarginRight"
        :margin-top="contentMarginTop"
        :radius-top-left="contentRadiusTopLeft"
        :radius-top-right="contentRadiusTopRight"
        :radius-bottom-right="contentRadiusBottomRight"
        :radius-bottom-left="contentRadiusBottomLeft"
        :border-top-width="contentBorderTopWidth"
        :border-right-width="contentBorderRightWidth"
        :border-bottom-width="contentBorderBottomWidth"
        :border-left-width="contentBorderLeftWidth"
        :style="contentStyle"
        :class="[
          'transition-[margin-top] duration-200',
          isMobile ? 'min-h-full' : 'min-h-0',
        ]"
      >
        <slot name="content"></slot>

        <template #overlay>
          <slot name="content-overlay"></slot>
        </template>
      </LayoutContent>

      <LayoutFooter
        v-if="footerEnable"
        :fixed="footerFixed"
        :height="footerHeight"
        :border-top-width="footerBorderTopWidth"
        :border-right-width="footerBorderRightWidth"
        :border-bottom-width="footerBorderBottomWidth"
        :border-left-width="footerBorderLeftWidth"
        :show="!isFullContent"
        :width="footerWidth"
        :z-index="zIndex"
      >
        <slot name="footer"></slot>
      </LayoutFooter>
    </div>
    <slot name="extra"></slot>
    <div
      v-if="maskVisible"
      :style="maskStyle"
      class="fixed left-0 top-0 h-full w-full bg-overlay transition-[background-color] duration-200"
      @click="handleClickMask"
    ></div>
  </div>
</template>

<style lang="scss">
.header-theme-control {
  background-color: var(--header-control-background, transparent) !important;
  color: var(--header-control-foreground, inherit);

  &:hover {
    background-color: var(
      --header-control-background-hover,
      hsl(var(--accent))
    ) !important;
  }

  svg {
    color: currentColor;
  }
}
</style>
