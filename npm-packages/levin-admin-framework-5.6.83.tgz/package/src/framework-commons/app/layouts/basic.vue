<script lang="ts" setup>
import type { NotificationItem } from '@vben/layouts';

import type { FrameworkEventListenerInfo } from '../../event-bus';
import type { AdminUiBaseSettingUploadTarget } from '../tenant-site-admin-ui-base-setting';

import {
  computed,
  defineAsyncComponent,
  onMounted,
  ref,
  useSlots,
  watch,
} from 'vue';
import { useRouter } from 'vue-router';

import { AuthenticationLoginExpiredModal } from '@vben/common-ui';
import { useWatermark } from '@vben/hooks';
import {
  BasicLayout,
  LockScreen,
  Notification,
  UserDropdown,
} from '@vben/layouts';
import { preferences } from '@vben/preferences';
import { useAccessStore, useUserStore } from '@vben/stores';

import {
  getAdminMenuSyncService,
  getAdminNoticeService,
  getAdminRequestClient,
} from '@levin/admin-framework';
import { rbacService } from '@levin/admin-framework/framework-commons/app/api';
import { $t } from '@levin/admin-framework/framework-commons/app/locales';
import { resolveAdminPage } from '@levin/admin-framework/framework-commons/app/pages';
import { useAuthStore } from '@levin/admin-framework/framework-commons/app/store';
import { useAuthBrand } from '@levin/admin-framework/framework-commons/app/views/_core/authentication/auth-brand';
import {
  Button,
  Checkbox,
  Empty,
  message,
  Modal,
  Popconfirm,
  Radio,
  Tag,
} from 'ant-design-vue';

import {
  getFrameworkEventListeners,
  removeFrameworkEventListener,
  setFrameworkEventListenerEnabled,
} from '../../event-bus';
import { getAdminI18nLabelSyncService } from '../../runtime';
import { getAdministrativeAreaOptions } from '../../shared/administrative-area-data';
import { getUserDropdownMenuItems } from '../../shared/user-dropdown-menu-service';
import { getFrontendBuildInfo } from '../frontend-build-versions';
import {
  buildAdminUiBaseSettingPayload,
  DEFAULT_ADMIN_UI_BASE_SETTING_UPLOAD_TARGET,
} from '../tenant-site-admin-ui-base-setting';
import SyncI18nLabelsModal from './sync-i18n-labels-modal.vue';
import SyncMenuRoutesModal from './sync-menu-routes-modal.vue';

type NoticeProcessStatus = 'Finished' | 'Processing' | 'Rejected';

interface NoticeRecord {
  category?: string;
  content?: string;
  createTime?: string;
  expiredTime?: string;
  id?: number | string;
  lastUpdateTime?: string;
  level?: string;
  name?: string;
  noticeId?: number | string;
  processLogId?: number | string;
  processRemark?: string;
  processStatus?: NoticeProcessStatus;
  processTime?: string;
  publishTime?: string;
  subtitle?: string;
  title?: string;
}

interface NoticeProcessLogRecord {
  createTime?: string;
  id?: number | string;
  noticeId?: number | string;
  remark?: string;
  status?: NoticeProcessStatus;
}

interface NoticeNotificationState extends Record<string, any> {
  logId?: string;
  logStatus?: NoticeProcessStatus;
  noticeId: string;
}

const notifications = ref<NotificationItem[]>([]);
const notificationUnreadItems = ref<NotificationItem[]>([]);
const noticeUnreadCount = ref(0);
const noticeProcessLogMap = ref(new Map<string, NoticeProcessLogRecord>());
const NOTIFICATION_PREVIEW_LIMIT = 7;
const NOTIFICATION_QUERY_LIMIT = 200;
const noticeLevelLabelMap: Record<string, string> = {
  Important: '重要',
  Normal: '普通',
  Urgent: '紧急',
  VeryUrgent: '非常紧急',
  VeryVeryUrgent: '非常非常紧急',
};

const userStore = useUserStore();
const authStore = useAuthStore();
const slots = useSlots();
const headerTopSlots = computed(() => {
  return ['header-top-center', 'header-top-right'].filter((name) =>
    Boolean(slots[name]),
  );
});
const accessStore = useAccessStore();
const router = useRouter();
const { appName, copyright, loadAuthBrand, logo } = useAuthBrand();
const LoginForm = defineAsyncComponent(
  resolveAdminPage('/_core/authentication/login.vue'),
);
const ProfileCenter = defineAsyncComponent(
  resolveAdminPage('/_core/profile/index.vue'),
);
const profileModalOpen = ref(false);
const syncMenuRoutesModalOpen = ref(false);
const syncI18nLabelsModalOpen = ref(false);
const saveAdminUiBaseSettingModalOpen = ref(false);
const saveAdminUiBaseSettingLoading = ref(false);
const syncNationalAdministrativeAreasModalOpen = ref(false);
const syncNationalAdministrativeAreasLoading = ref(false);
const eventListenerManagerOpen = ref(false);
const frontendVersionModalOpen = ref(false);
const eventListeners = ref<FrameworkEventListenerInfo[]>([]);
const preferServerAdminUiBaseSetting = ref(true);
const adminUiBaseSettingUploadTarget = ref<AdminUiBaseSettingUploadTarget>(
  DEFAULT_ADMIN_UI_BASE_SETTING_UPLOAD_TARGET,
);
const SAVE_ADMIN_UI_BASE_SETTING_TIMEOUT_MS = 15_000;
const adminUiBaseSettingUploadTargetOptions: Array<{
  label: string;
  value: AdminUiBaseSettingUploadTarget;
}> = [
  { label: '平台', value: 'Platform' },
  { label: '租户站点', value: 'TenantSite' },
  { label: '租户', value: 'Tenant' },
];
const eventListenerManagerModalMaxWidth = 'min(80vw, 960px)';
const eventListenerManagerModalStyle = {
  maxWidth: eventListenerManagerModalMaxWidth,
};
const { destroyWatermark, updateWatermark } = useWatermark();
const showDot = computed(() => noticeUnreadCount.value > 0);
const extensionUserDropdownMenus = getUserDropdownMenuItems();

const canUploadPageRoutes = computed(() => {
  const userInfo = (userStore.userInfo || {}) as Record<string, any>;
  return userInfo.superAdmin === true && Boolean(getAdminMenuSyncService());
});

const canViewFrontendVersions = computed(() => {
  const userInfo = (userStore.userInfo || {}) as Record<string, any>;
  return userInfo.superAdmin === true;
});

const frontendBuildInfo = computed(() =>
  getFrontendBuildInfo(
    import.meta.env.VITE_APP_TITLE || appName.value,
    import.meta.env.VITE_APP_VERSION,
  ),
);

const canUploadI18nLabels = computed(() => {
  const userInfo = (userStore.userInfo || {}) as Record<string, any>;
  return (
    userInfo.superAdmin === true &&
    Boolean(getAdminI18nLabelSyncService()?.uploadModuleLabels)
  );
});

const fixedProfileUserDropdownMenu = computed(() => ({
  handler: () => {
    profileModalOpen.value = true;
  },
  icon: 'lucide:user',
  id: 'profile',
  text: $t('page.auth.profile'),
}));

const builtInUserDropdownExtensionMenus = computed(() =>
  [
    {
      handler: () => {
        return router.push('/clob/V1/MySetting');
      },
      icon: 'lucide:user-cog',
      id: 'my-setting',
      order: 100,
      text: '我的设置',
    },
    ...(canUploadPageRoutes.value
      ? [
          {
            handler: () => {
              syncMenuRoutesModalOpen.value = true;
            },
            icon: 'lucide:cloud-upload',
            id: 'sync-menu-routes',
            order: 200,
            text: '上传页面路由',
          },
          {
            handler: () => {
              preferServerAdminUiBaseSetting.value = true;
              adminUiBaseSettingUploadTarget.value =
                DEFAULT_ADMIN_UI_BASE_SETTING_UPLOAD_TARGET;
              saveAdminUiBaseSettingModalOpen.value = true;
            },
            icon: 'lucide:settings',
            id: 'save-admin-ui-base-setting',
            order: 300,
            text: '上传界面设置',
          },
          {
            handler: () => {
              syncNationalAdministrativeAreasModalOpen.value = true;
            },
            icon: 'lucide:map-pin',
            id: 'sync-national-administrative-areas',
            order: 350,
            text: '上传默认国家行政编码',
          },
          {
            handler: () => {
              openEventListenerManager();
            },
            icon: 'lucide:list-tree',
            id: 'event-listener-manager',
            order: 400,
            text: '监听器管理',
          },
        ]
      : []),
    ...(canUploadI18nLabels.value
      ? [
          {
            handler: () => {
              syncI18nLabelsModalOpen.value = true;
            },
            icon: 'lucide:languages',
            id: 'sync-i18n-labels',
            order: 250,
            text: '上传国际化资源',
          },
        ]
      : []),
    ...(canViewFrontendVersions.value
      ? [
          {
            handler: () => {
              frontendVersionModalOpen.value = true;
            },
            icon: 'lucide:component',
            id: 'frontend-build-versions',
            order: 450,
            text: '前端组件版本',
          },
        ]
      : []),
  ].toSorted((left, right) => left.order - right.order),
);

const systemMenus = computed(() => builtInUserDropdownExtensionMenus.value);

const menus = computed(() => {
  return extensionUserDropdownMenus.value
    .map((item) => ({
      ...item,
      order: item.order ?? 1000,
    }))
    .toSorted((left, right) => left.order - right.order);
});

const avatar = computed(() => {
  return userStore.userInfo?.avatar || preferences.app.defaultAvatar;
});

const userDropdownDescription = computed(() => {
  const userInfo = (userStore.userInfo || {}) as Record<string, any>;
  return (
    userInfo.telephone ||
    userInfo.mobile ||
    userInfo.phone ||
    userInfo.email ||
    userInfo.loginName ||
    userInfo.username ||
    ''
  );
});

async function handleLogout() {
  await authStore.logout(false);
}

function clonePreferences() {
  return JSON.parse(JSON.stringify(preferences)) as Record<string, any>;
}

async function handleSaveAdminUiBaseSetting() {
  if (saveAdminUiBaseSettingLoading.value) {
    return;
  }

  saveAdminUiBaseSettingLoading.value = true;

  try {
    await rbacService.adjustSiteUiSetting(
      buildAdminUiBaseSettingPayload(
        clonePreferences(),
        preferServerAdminUiBaseSetting.value,
        adminUiBaseSettingUploadTarget.value,
      ),
      {
        timeout: SAVE_ADMIN_UI_BASE_SETTING_TIMEOUT_MS,
      },
    );
    message.success('界面设置上传成功');
    saveAdminUiBaseSettingModalOpen.value = false;
  } catch {
    message.error('界面设置上传失败');
  } finally {
    saveAdminUiBaseSettingLoading.value = false;
  }
}

async function syncNationalAdministrativeAreas() {
  if (syncNationalAdministrativeAreasLoading.value) {
    return;
  }
  syncNationalAdministrativeAreasLoading.value = true;
  try {
    const result = await getAdminRequestClient().post<any>(
      '/Area/syncNationalAdministrativeAreas',
      { areas: getAdministrativeAreaOptions() },
    );
    message.success(
      `国家行政编码全量上传完成：新增 ${result?.createdCount || 0} 条，跳过 ${result?.skippedCount || 0} 条`,
    );
    syncNationalAdministrativeAreasModalOpen.value = false;
  } catch {
    message.error('国家行政编码上传失败');
  } finally {
    syncNationalAdministrativeAreasLoading.value = false;
  }
}

function resetSaveAdminUiBaseSettingLoading() {
  saveAdminUiBaseSettingLoading.value = false;
}

function refreshEventListeners() {
  eventListeners.value = getFrameworkEventListeners();
}

function openEventListenerManager() {
  refreshEventListeners();
  eventListenerManagerOpen.value = true;
}

function handleRemoveEventListener(id: string) {
  if (removeFrameworkEventListener(id)) {
    message.success('监听器已移除');
  } else {
    message.warning('监听器不存在或已被移除');
  }
  refreshEventListeners();
}

function handleSetEventListenerEnabled(id: string, enabled: boolean) {
  if (setFrameworkEventListenerEnabled(id, enabled)) {
    message.success(enabled ? '监听器已启用' : '监听器已禁用');
  } else {
    message.warning('监听器不存在或已被移除');
  }
  refreshEventListeners();
}

function normalizeListItems<T>(data: any): T[] {
  if (Array.isArray(data)) {
    return data;
  }

  return data?.items || data?.records || data?.list || [];
}

function getNoticeState(item: NotificationItem) {
  return item.state as NoticeNotificationState | undefined;
}

function stripContent(content?: string) {
  return String(content || '')
    .replaceAll(/<[^>]*>/g, ' ')
    .replaceAll(/\s+/g, ' ')
    .trim();
}

function formatNoticeDate(value?: string) {
  if (!value) {
    return '';
  }

  const time = new Date(value).getTime();
  if (!Number.isFinite(time)) {
    return value;
  }

  const diffSeconds = Math.max(0, Math.floor((Date.now() - time) / 1000));
  if (diffSeconds < 60) {
    return '刚刚';
  }

  const diffMinutes = Math.floor(diffSeconds / 60);
  if (diffMinutes < 60) {
    return `${diffMinutes}分钟前`;
  }

  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 24) {
    return `${diffHours}小时前`;
  }

  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 7) {
    return `${diffDays}天前`;
  }

  return value.slice(0, 10);
}

function getNoticeTitle(notice: NoticeRecord) {
  return String(notice.title || notice.name || '通知').trim();
}

function getNoticeMessage(notice: NoticeRecord) {
  const message = String(
    notice.subtitle || stripContent(notice.content) || notice.category || '',
  ).trim();

  return message || '请查看通知详情';
}

function getNoticeLevelLabel(notice: NoticeRecord) {
  const level = String(notice.level || '').trim();
  return noticeLevelLabelMap[level] || level;
}

function getNoticeAvatar(notice: NoticeRecord) {
  const title = getNoticeTitle(notice);
  const text = encodeURIComponent(title.slice(0, 2) || '通知');
  const seed = encodeURIComponent(String(notice.id || title));
  return `https://avatar.vercel.sh/${seed}.svg?text=${text}`;
}

function isNoticeExpired(notice: NoticeRecord) {
  if (!notice.expiredTime) {
    return false;
  }

  const expiredAt = new Date(notice.expiredTime).getTime();
  return Number.isFinite(expiredAt) && expiredAt < Date.now();
}

function toNotificationItem(
  notice: NoticeRecord,
  log?: NoticeProcessLogRecord,
): NotificationItem | undefined {
  const noticeId = String(notice.id || '').trim();
  const processStatus = log?.status || notice.processStatus;
  if (!noticeId || isNoticeExpired(notice) || processStatus === 'Rejected') {
    return undefined;
  }

  return {
    id: noticeId,
    avatar: getNoticeAvatar(notice),
    date: formatNoticeDate(
      notice.publishTime || notice.createTime || notice.lastUpdateTime,
    ),
    isRead: processStatus === 'Finished',
    level: getNoticeLevelLabel(notice),
    link: '/clob/V1/MyMessages',
    message: getNoticeMessage(notice),
    state: {
      logId: log?.id ? String(log.id) : undefined,
      logStatus: processStatus,
      noticeId,
    },
    title: getNoticeTitle(notice),
  };
}

function buildNoticeProcessLogMap(logs: NoticeProcessLogRecord[]) {
  const logMap = new Map<string, NoticeProcessLogRecord>();

  logs.forEach((log) => {
    const noticeId = String(log.noticeId || '').trim();
    if (!noticeId) {
      return;
    }

    const current = logMap.get(noticeId);
    if (
      !current ||
      String(log.createTime || '') > String(current.createTime || '')
    ) {
      logMap.set(noticeId, log);
    }
  });

  return logMap;
}

async function loadNotifications() {
  const noticeService = getAdminNoticeService();
  if (!accessStore.accessToken || !noticeService) {
    notifications.value = [];
    notificationUnreadItems.value = [];
    noticeUnreadCount.value = 0;
    noticeProcessLogMap.value = new Map();
    return;
  }

  const noticeData = await noticeService.myMessages({
    pageIndex: 1,
    pageSize: NOTIFICATION_QUERY_LIMIT,
  });

  const notices = normalizeListItems<NoticeRecord>(noticeData);
  const logs = notices.map((notice) => ({
    createTime: notice.processTime,
    id: notice.processLogId,
    noticeId: notice.noticeId || notice.id,
    remark: notice.processRemark,
    status: notice.processStatus,
  }));

  const logMap = buildNoticeProcessLogMap(logs);
  noticeProcessLogMap.value = logMap;

  const visibleItems = notices
    .map((notice) =>
      toNotificationItem(notice, logMap.get(String(notice.id || ''))),
    )
    .filter(Boolean);
  const unreadItems = visibleItems.filter((item) => !item.isRead);

  notificationUnreadItems.value = unreadItems;
  noticeUnreadCount.value = unreadItems.length;
  notifications.value = unreadItems.slice(0, NOTIFICATION_PREVIEW_LIMIT);
}

async function saveNoticeProcessLog(
  item: NotificationItem,
  status: NoticeProcessStatus,
  remark: string,
) {
  const noticeService = getAdminNoticeService();
  const state = getNoticeState(item);
  const noticeId = state?.noticeId;
  if (!noticeId || !noticeService) {
    return;
  }

  const result = (await noticeService.processMyMessage({
    noticeId,
    remark,
    status,
  })) as NoticeRecord | undefined;

  noticeProcessLogMap.value.set(noticeId, {
    id: result?.processLogId || state?.logId,
    noticeId,
    remark,
    status,
  });

  if (status === 'Finished' || status === 'Rejected') {
    noticeUnreadCount.value = Math.max(0, noticeUnreadCount.value - 1);
  }
}

function removeNotificationItems(ids: Set<string>) {
  notificationUnreadItems.value = notificationUnreadItems.value.filter(
    (item) => !ids.has(String(item.id || '')),
  );
  notifications.value = notificationUnreadItems.value.slice(
    0,
    NOTIFICATION_PREVIEW_LIMIT,
  );
  noticeUnreadCount.value = notificationUnreadItems.value.length;
}

async function markNotificationItemsRead(
  items: NotificationItem[],
  remark: string,
) {
  const unreadItems = items.filter((item) => !item.isRead);
  if (unreadItems.length === 0) {
    return;
  }

  for (const item of unreadItems) {
    await saveNoticeProcessLog(item, 'Finished', remark);
  }
  removeNotificationItems(
    new Set(unreadItems.map((item) => String(item.id || ''))),
  );
}

async function handleNoticeClear() {
  await markNotificationItemsRead(
    [...notificationUnreadItems.value],
    '用户清空通知并标记已读',
  );
}

async function markRead(id: number | string) {
  const item = notificationUnreadItems.value.find((item) => item.id === id);
  if (!item || item.isRead) {
    return;
  }

  await markNotificationItemsRead([item], '用户已读通知');
}

async function remove(id: number | string) {
  const item = notificationUnreadItems.value.find((item) => item.id === id);
  if (!item) {
    return;
  }

  await saveNoticeProcessLog(item, 'Rejected', '用户清除通知');
  removeNotificationItems(new Set([String(item.id || '')]));
}

async function handleMakeAll() {
  await markNotificationItemsRead(
    [...notificationUnreadItems.value],
    '用户全部已读通知',
  );
}

function handleViewAllNotifications() {
  router.push('/clob/V1/MyMessages');
}

function handleClickLogo() {
  return router.push(
    userStore.userInfo?.homePath || preferences.app.defaultHomePath,
  );
}

onMounted(() => {
  loadAuthBrand().catch((error) => {
    console.warn('加载租户站点品牌信息失败', error);
  });
  loadNotifications().catch((error) => {
    console.warn('加载通知失败', error);
  });
});

watch(
  logo,
  (siteLogo) => {
    if (siteLogo) {
      preferences.logo.source = siteLogo;
    }
  },
  { immediate: true },
);

watch(
  () => [accessStore.accessToken, userStore.userInfo?.id],
  () => {
    loadNotifications().catch((error) => {
      console.warn('加载通知失败', error);
    });
  },
);

watch(
  () => ({
    enable: preferences.app.watermark,
    color: preferences.app.watermarkColorCustom
      ? preferences.app.watermarkColor || 'gray'
      : 'gray',
    content: preferences.app.watermarkContent,
    transparency: preferences.app.watermarkTransparency ?? 85,
  }),
  async ({ color, enable, content, transparency }) => {
    if (enable) {
      await updateWatermark({
        advancedStyle: {
          colorStops: [
            { color, offset: 0 },
            { color, offset: 1 },
          ],
          type: 'linear',
        },
        content:
          content ||
          `${userStore.userInfo?.username} - ${userStore.userInfo?.realName}`,
        globalAlpha: Math.min(1, Math.max(0, 1 - Number(transparency) / 100)),
      });
    } else {
      destroyWatermark();
    }
  },
  {
    immediate: true,
  },
);
</script>

<template>
  <BasicLayout @click-logo="handleClickLogo">
    <template #logo-text>
      {{ appName }}
    </template>
    <template v-if="copyright" #footer>
      <div class="text-muted-foreground text-center text-xs">
        {{ copyright }}
      </div>
    </template>
    <template #user-dropdown>
      <Modal
        v-model:open="profileModalOpen"
        :footer="null"
        :mask-closable="false"
        :title="$t('page.auth.profile')"
        :width="960"
        destroy-on-close
      >
        <ProfileCenter class="max-h-[72vh] overflow-y-auto" />
      </Modal>
      <SyncMenuRoutesModal v-model:open="syncMenuRoutesModalOpen" />
      <SyncI18nLabelsModal v-model:open="syncI18nLabelsModalOpen" />
      <Modal
        v-model:open="frontendVersionModalOpen"
        :footer="null"
        :mask-closable="false"
        title="前端组件版本"
      >
        <div class="text-muted-foreground mb-3 text-sm">
          构建时间：{{ frontendBuildInfo.buildTime }}
        </div>
        <div class="border-border max-h-[56vh] overflow-y-auto rounded border">
          <div
            v-for="item in frontendBuildInfo.versions"
            :key="`${item.category}:${item.id}`"
            class="border-border flex items-center justify-between gap-4 border-b px-4 py-3 last:border-b-0"
          >
            <div class="min-w-0">
              <div class="flex items-center gap-2">
                <span class="truncate font-medium">{{ item.name }}</span>
                <Tag class="shrink-0">{{ item.category }}</Tag>
              </div>
              <div
                class="text-muted-foreground mt-1 truncate font-mono text-xs"
              >
                {{ item.id }}
              </div>
            </div>
            <Tag class="shrink-0">{{ item.version }}</Tag>
          </div>
        </div>
      </Modal>
      <Modal
        v-model:open="saveAdminUiBaseSettingModalOpen"
        :confirm-loading="saveAdminUiBaseSettingLoading"
        :mask-closable="false"
        title="上传界面设置"
        @after-close="resetSaveAdminUiBaseSettingLoading"
        @cancel="resetSaveAdminUiBaseSettingLoading"
        @ok="handleSaveAdminUiBaseSetting"
      >
        <div class="flex flex-col gap-4">
          <label class="block space-y-2 text-sm">
            <span class="text-muted-foreground block">上传目标</span>
            <Radio.Group
              v-model:value="adminUiBaseSettingUploadTarget"
              :options="adminUiBaseSettingUploadTargetOptions"
              option-type="button"
            />
          </label>
          <Checkbox v-model:checked="preferServerAdminUiBaseSetting">
            优先使用服务端设置参数
          </Checkbox>
        </div>
      </Modal>
      <Modal
        v-model:open="syncNationalAdministrativeAreasModalOpen"
        :confirm-loading="syncNationalAdministrativeAreasLoading"
        :mask-closable="false"
        title="上传默认国家行政编码"
        @ok="syncNationalAdministrativeAreas"
      >
        <p class="text-muted-foreground m-0 text-sm leading-6">
          将当前有效的全部国家行政编码一次性上传到后端区域镜像。已有编码会跳过，不会修改或删除现有区域数据。
        </p>
      </Modal>
      <Modal
        v-model:open="eventListenerManagerOpen"
        :footer="null"
        :mask-closable="false"
        :style="eventListenerManagerModalStyle"
        :width="eventListenerManagerModalMaxWidth"
        title="监听器管理"
      >
        <div class="mb-3 flex items-center justify-between gap-3">
          <div class="text-muted-foreground text-sm">
            当前全局事件总线监听器
          </div>
          <Button size="small" @click="refreshEventListeners">刷新</Button>
        </div>
        <Empty v-if="eventListeners.length === 0" description="暂无监听器" />
        <div
          v-else
          class="border-border max-h-[56vh] w-full max-w-full overflow-y-auto rounded border"
        >
          <div
            class="border-border bg-muted/40 text-muted-foreground grid grid-cols-[minmax(0,1.2fr)_120px_minmax(0,1fr)_72px_116px] gap-3 border-b px-4 py-2 text-xs font-medium"
          >
            <div>描述</div>
            <div>事件类型</div>
            <div>主题匹配</div>
            <div>状态</div>
            <div class="text-right">操作</div>
          </div>
          <div
            v-for="listener in eventListeners"
            :key="listener.id"
            class="border-border grid grid-cols-[minmax(0,1.2fr)_120px_minmax(0,1fr)_72px_116px] items-center gap-3 border-b px-4 py-3 last:border-b-0"
          >
            <div class="min-w-0 flex-1">
              <div class="text-muted-foreground truncate text-xs">
                {{ listener.remark || '未填写备注' }}
              </div>
              <div class="text-muted-foreground mt-1 truncate text-xs">
                {{ listener.id }}
              </div>
            </div>
            <div class="min-w-0">
              <Tag class="max-w-full truncate">{{ listener.type }}</Tag>
            </div>
            <div class="truncate font-medium">
              {{ listener.topicPattern }}
            </div>
            <div>
              <Tag :color="listener.enabled ? 'success' : 'default'">
                {{ listener.enabled ? '启用' : '禁用' }}
              </Tag>
            </div>
            <div class="flex justify-end gap-2">
              <Button
                size="small"
                @click="
                  handleSetEventListenerEnabled(listener.id, !listener.enabled)
                "
              >
                {{ listener.enabled ? '禁用' : '启用' }}
              </Button>
              <Popconfirm
                cancel-text="取消"
                ok-text="移除"
                title="确定移除这个监听器？"
                @confirm="handleRemoveEventListener(listener.id)"
              >
                <Button danger size="small">移除</Button>
              </Popconfirm>
            </div>
          </div>
        </div>
      </Modal>

      <UserDropdown
        :avatar
        :menus
        :profile-menu="fixedProfileUserDropdownMenu"
        :system-menus="systemMenus"
        :text="userStore.userInfo?.realName"
        :description="userDropdownDescription"
        tag-text="Pro"
        @logout="handleLogout"
      />
    </template>
    <template #notification>
      <Notification
        :dot="showDot"
        :count="noticeUnreadCount"
        :notifications="notifications"
        @clear="handleNoticeClear"
        @read="(item) => item.id && markRead(item.id)"
        @remove="(item) => item.id && remove(item.id)"
        @make-all="handleMakeAll"
        @view-all="handleViewAllNotifications"
      />
    </template>
    <template v-for="item in headerTopSlots" #[item]>
      <slot :name="item"></slot>
    </template>
    <template #extra>
      <AuthenticationLoginExpiredModal
        v-model:open="accessStore.loginExpired"
        :avatar
      >
        <LoginForm />
      </AuthenticationLoginExpiredModal>
    </template>
    <template #lock-screen>
      <LockScreen :avatar @to-login="handleLogout" />
    </template>
  </BasicLayout>
</template>
