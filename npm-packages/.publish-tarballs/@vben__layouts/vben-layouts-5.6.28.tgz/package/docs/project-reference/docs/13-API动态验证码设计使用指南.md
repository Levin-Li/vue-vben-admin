# API 动态验证码设计使用指南

本文说明 URL 访问控制中的 API 动态验证码设计、适用场景、前后端完整流程、实现类位置、配置方法、业务接入方式和排查方法。

## 1. 目的和用途

API 动态验证码用于给已经通过登录和 RBAC 校验的接口再增加一层动态确认。它不是登录验证码的替代，也不是权限系统的替代；它解决的是“用户已经有权限，但当前操作仍然需要再次确认”的问题。

这个能力的核心目标：

- 对高风险接口按规则临时或长期加固。
- 让业务页面和业务控制器不需要重复写验证码逻辑。
- 由后端 URL 访问控制统一判断是否需要验证。
- 由前端公共请求客户端统一弹窗、申请验证码、提交验证码并重放原请求。
- 用验证 ID 绑定原请求，避免验证码被挪用到其他接口、其他请求体或其他用户。

典型用途：

- 支付、提现、退款、资金账户变更等资金类接口。
- 修改手机号、邮箱、密码、MFA 密钥、API 密钥等账号安全接口。
- 删除、批量删除、批量导出、批量审批等高影响操作。
- 修改租户配置、系统设置、URL 访问控制规则、第三方通道配置等管理类接口。
- 临时风险控制：平时允许访问的接口，在活动、审计、故障或安全加固期间临时要求验证码。

不建议使用的场景：

- 普通查询、普通列表和低风险读接口。
- 长流程业务审批。审批应建模为业务状态流，不应只靠验证码替代。
- 外部系统直接调用且无法处理动态验证码协议的接口。

## 2. 支持范围

当前通用前端弹窗和测试覆盖以下四种验证方式：

| URL ACL 拦截动作 | 验证类型 | 用户交互 |
| --- | --- | --- |
| `SmsVerify` | `Sms` | 弹窗输入短信验证码，点击“获取验证码”后由短信通道发送。 |
| `EmailVerify` | `Email` | 弹窗输入邮箱验证码，点击“获取验证码”后由邮箱通道发送。 |
| `MfaVerify` | `Mfa` | 弹窗输入 MFA 应用中的动态码，不显示“获取验证码”按钮。 |
| `CaptchaVerify` | `Captcha` | 弹窗右侧展示图片验证码，点击图片刷新。 |

`HmiVerify` 和 `BioVerify` 需要更复杂的前端交互组件或设备能力配合，当前不属于通用动态验证码弹窗的默认测试和接入范围。

## 3. 核心设计

动态验证码协议围绕三个概念：

| 概念 | 说明 |
| --- | --- |
| 动态参数名 | 后端按当前登录 token 返回验证码参数名，例如 `DVC-<login-token>`，最终重放原请求时用它提交验证码。 |
| 验证 ID | 后端根据当前请求上下文计算出的验证 ID，最终提交验证码时必须带回。 |
| `RequestHash` | 前端基于原请求 body 生成的摘要。申请验证码和最终提交必须使用同一个摘要。 |

验证 ID 不落本机缓存，也不落 Redis。它由以下字段按字符串相加后计算 SHA-256 得到：

- 用户 ID。
- 租户 ID。
- 应用 ID。
- 验证类型。
- HTTP method。
- URL path。
- 原请求体摘要。

因此，验证码只能用于“同一个用户、同一个租户、同一个应用、同一种验证类型、同一个方法、同一个路径、同一个请求体”的原操作。缺失、篡改、复用到其他接口或换请求体都会被拒绝。验证码本身仍由验证码服务负责过期和一次性校验。

## 4. 前后端完整流程

前端必须使用公共请求客户端，例如 `requestClient` 或 `baseRequestClient`。公共响应拦截器会识别动态验证码响应头，并自动完成后续流程。

### 4.1 流程表

| 步骤 | 发起方 | 请求或响应 | 后端行为 | 前端行为 |
| --- | --- | --- | --- | --- |
| 1 | 前端 | 正常调用原业务接口。 | 按 URL ACL 规则判断是否需要动态验证码。 | 用户按原来的方式点击按钮或提交表单。 |
| 2 | 后端 | 如果命中验证规则，响应头返回 `-DynamicVerifyCode-: Apply`、`-DynamicVerifyCode-Type`、`-DynamicVerifyCode-Prompt`，并拦截业务接口。 | 不执行业务动作，只提示需要验证。 | 公共请求拦截器识别响应头。 |
| 3 | 前端 | 打开居中的模态弹窗。 | 无。 | 标题显示 `该操作需要xx验证`，用户知道当前需要哪类验证码。 |
| 4 | 前端 | 申请验证码。短信/邮箱由用户点“获取验证码”；MFA 和图片验证码自动申请。申请请求重放同一个原业务请求，并带 `-DynamicVerifyCode-: Apply` 和 `-DynamicVerifyCode-RequestHash`。 | 生成验证码，并根据原请求上下文计算验证 ID。 | 保持原请求 pending，不让业务调用失败退出。 |
| 5 | 后端 | 返回 `-DynamicVerifyCode-ParamName`、`-DynamicVerifyCode-VerifyId`、`-DynamicVerifyCode-Type`，以及 `Prompt` 或 `InteractionData`。 | 发送短信/邮件，或返回图片验证码/MFA 交互数据。 | 保存 `ParamName` 和验证 ID，展示服务端提示或图片。 |
| 6 | 前端 | 用户输入验证码。 | 无。 | 短信/邮箱展示服务端发送提示；图片验证码展示图片；MFA 只保留输入框。 |
| 7 | 前端 | 用户点击“确定”，再次重放原业务请求，带上动态验证码参数、`-DynamicVerifyCode-VerifyId` 和同一个 `-DynamicVerifyCode-RequestHash`。 | 校验验证 ID 和验证码。 | 原请求继续等待最终结果。 |
| 8 | 后端 | 重新计算验证 ID 并和前端提交值比对；通过后再校验验证码并放行业务接口。 | 验证码由验证码服务控制过期和一次性使用。 | 业务接口成功时按普通请求返回；失败时按普通错误处理。 |

### 4.2 时序图

```mermaid
sequenceDiagram
    participant U as 用户
    participant FE as 前端公共请求客户端
    participant ACL as UrlAclInterceptor
    participant VC as BizVerifyCodeService
    participant API as 原业务接口

    U->>FE: 触发原业务操作
    FE->>ACL: 原业务请求
    ACL-->>FE: -DynamicVerifyCode-: Apply<br/>-DynamicVerifyCode-Type<br/>-DynamicVerifyCode-Prompt
    FE-->>U: 打开验证弹窗
    U->>FE: 获取验证码或等待自动申请
    FE->>ACL: 同一个原请求 + Apply + RequestHash
    ACL->>VC: genCode(type, tenantId, appId, account)
    VC-->>ACL: 验证码结果/图片/提示
    ACL-->>FE: ParamName + 验证ID + Prompt/InteractionData
    FE-->>U: 展示输入框、提示或图片
    U->>FE: 输入验证码并确认
    FE->>ACL: 同一个原请求 + ParamName=code + 验证ID + RequestHash
    ACL->>ACL: 校验验证ID是否匹配原请求
    ACL->>VC: verify(type, tenantId, appId, account, code)
    VC-->>ACL: 验证结果
    ACL->>API: 验证通过后继续原业务接口
    API-->>FE: 原业务响应
    FE-->>U: 显示业务结果
```

## 5. 协议头说明

### 5.1 首次命中 ACL

后端响应：

```http
-DynamicVerifyCode-: Apply
-DynamicVerifyCode-Type: Sms | Email | Mfa | Captcha
-DynamicVerifyCode-Prompt: <url-encoded prompt>
```

含义：当前接口需要动态验证码。前端不要把这次响应当成业务成功结果，而应打开验证弹窗。

### 5.2 申请验证码

前端用同一个原业务请求再次请求后端，并附加：

```http
-DynamicVerifyCode-: Apply
-DynamicVerifyCode-RequestHash: <original request body hash>
```

短信和邮箱由用户点击“获取验证码”触发。MFA 和图片验证码在弹窗打开后自动触发。图片验证码点击图片时会再次申请，用于刷新图片。

后端响应：

```http
-DynamicVerifyCode-ParamName: DVC-<login-token>
-DynamicVerifyCode-VerifyId: <verification id>
-DynamicVerifyCode-Type: Sms | Email | Mfa | Captcha
-DynamicVerifyCode-Prompt: <url-encoded server prompt>
-DynamicVerifyCode--InteractionData: <url-encoded interaction data>
```

`Prompt` 常用于展示“验证码已发送到 138****0000”或邮箱地址提示。`InteractionData` 用于图片验证码、MFA 链接或其他交互数据。

### 5.3 提交验证码并重放原请求

前端再次重放原业务请求，并附加：

```http
DVC-<login-token>: <user-input-code>
-DynamicVerifyCode-VerifyId: <verification id>
-DynamicVerifyCode-RequestHash: <original request body hash>
```

后端通过后继续执行原业务接口。失败时拒绝，不执行业务动作。

## 6. 前端弹窗设计

通用弹窗由前端公共请求拦截器创建，业务页面通常不需要自己写弹窗。

- 弹窗宽度为 `400px`，居中显示。
- 弹窗是模态的，不能点遮罩关闭，不能按 Esc 关闭，也不显示右上角关闭按钮。
- 用户只能点击“取消”或“确定”。
- 标题格式为 `该操作需要短信验证`、`该操作需要邮箱验证`、`该操作需要MFA验证` 或 `该操作需要图片验证`。
- 标题字号为 `16px`。
- 输入框用于输入验证码。
- 短信和邮箱：输入框右侧显示“获取验证码”按钮。
- MFA：不显示“获取验证码”按钮，用户直接输入 MFA 应用中的动态码。
- 图片验证码：输入框右侧显示验证码图片，点击图片刷新。
- 服务端返回的发送提示显示在输入框下方，使用前端框架危险色小字展示。

## 7. 如何配置

在管理后台进入“URL 访问控制”，新增或编辑规则：

1. 启用规则。
2. 选择拦截类型：`SmsVerify`、`EmailVerify`、`MfaVerify` 或 `CaptchaVerify`。
3. 配置 URL 匹配范围，例如 `/api/secure/pay` 或某个高风险接口路径。
4. 按需配置 HTTP 方法、域名、IP、操作系统、用户类型、角色等条件。
5. 对健康检查、回调接口或不应验证的接口配置排除 URL。
6. 保存后，用具有匹配角色和租户上下文的用户访问目标接口验证效果。

验证码服务前置条件：

- `LoginCfg.enableApiDynamicVerifyCode` 应允许 API 动态验证码。
- `LoginCfg.disableVerifyCodeTypeList` 不应禁用当前验证类型。
- 短信验证需要短信发送通道配置可用。
- 邮箱验证需要邮箱发送通道配置可用。
- MFA 验证需要用户已绑定 MFA 密钥。
- 图片验证码需要图片验证码插件可用。

## 8. 业务开发如何使用

后台业务页面如果使用框架内公共请求客户端，通常不需要额外接入。业务代码只需要正常调用接口：

```ts
await requestClient.post('/api/secure/pay', { amount: 100 });
```

如果后端 URL 访问控制命中验证规则，公共拦截器会自动弹窗、申请验证码并重放原请求。原请求的 method、URL、query、body 和自定义 header 会被保留。

如果业务代码绕过公共请求客户端，例如直接使用 `fetch`、`axios.create()` 或第三方 SDK，则不会自动弹窗。此时需要改用公共请求客户端，或按本协议自行实现：

1. 识别 `-DynamicVerifyCode-: Apply`。
2. 用同一个原请求加 `-DynamicVerifyCode-: Apply` 和 `RequestHash` 申请验证码。
3. 保存后端返回的 `ParamName` 和验证 ID。
4. 收集用户输入验证码。
5. 用同一个原请求带验证码、验证 ID 和 `RequestHash` 重放。

## 9. 实现类和代码位置

### 9.1 后端核心实现

| 文件 | 作用 |
| --- | --- |
| `web-commons/src/main/java/com/levin/oak/base/web/interceptor/UrlAclInterceptor.java` | URL ACL 拦截器。负责识别 `SmsVerify`、`EmailVerify`、`MfaVerify`、`CaptchaVerify` 等动作，返回动态验证码协议头，根据请求上下文计算并校验验证 ID。 |
| `web-commons/src/main/java/com/levin/oak/base/web/interceptor/UrlAclUtils.java` | URL ACL 条件匹配和请求参数读取工具。动态验证码参数支持从请求参数或请求头读取。 |
| `web-commons/src/main/java/com/levin/oak/base/web/config/ModuleWebMvcConfigurer.java` | 注册 `UrlAclInterceptor`。 |
| `entities/src/main/java/com/levin/oak/base/entities/UrlExAcl.java` | URL 访问控制实体，定义 `InterceptType` 枚举，包括 `SmsVerify`、`EmailVerify`、`MfaVerify`、`CaptchaVerify`、`HmiVerify`、`BioVerify`。 |
| `services/src/main/java/com/levin/oak/base/services/urlexacl/info/UrlExAclInfo.java` | URL ACL 规则信息对象，运行时用于匹配请求。 |
| `services/src/main/java/com/levin/oak/base/biz/BizVerifyCodeService.java` | 验证码统一服务接口，提供 `genCode` 和 `verify`。 |
| `services-impl/src/main/java/com/levin/oak/base/biz/BizVerifyCodeServiceImpl.java` | 验证码统一服务实现，按 `VerifyCodeType` 选择验证码插件。 |

### 9.2 后端验证码插件

| 文件 | 作用 |
| --- | --- |
| `services-impl/src/main/java/com/levin/oak/base/biz/plugin/DefaultSmsVerifyServicePlugin.java` | 默认短信验证码插件。 |
| `services-impl/src/main/java/com/levin/oak/base/biz/plugin/DefaultEmailVerifyServicePlugin.java` | 默认邮箱验证码插件。 |
| `services-impl/src/main/java/com/levin/oak/base/biz/plugin/DefaultCaptchaVerifyServicePlugin.java` | 默认图片验证码插件。 |
| `services-impl/src/main/java/com/levin/oak/base/biz/plugin/HappyCaptchaVerifyServicePlugin.java` | Happy Captcha 图片验证码插件。 |
| `services-impl/src/main/java/com/levin/oak/base/biz/plugin/GoogleMfaVerifyServicePlugin.java` | Google Authenticator MFA 插件。 |
| `services-impl/src/main/java/com/levin/oak/base/biz/plugin/DefaultHmiVerifyServicePlugin.java` | HMI 人机交互验证码插件。当前不在通用弹窗默认范围内。 |
| `services-impl/src/main/java/com/levin/oak/base/biz/AbstractCaptchaVerifyServicePlugin.java` | 图片验证码插件抽象基类。 |

### 9.3 前端核心实现

| 文件 | 作用 |
| --- | --- |
| `frontend/admin/packages/business/admin-framework/src/framework-commons/app/api/request.ts` | 公共请求客户端创建和响应拦截器注册位置。这里注册 `createDynamicVerifyCodeInterceptor(client)`。 |
| `frontend/admin/packages/business/admin-framework/src/framework-commons/app/api/dynamic-verify-code.ts` | 动态验证码前端核心实现。负责识别响应头、弹出模态框、申请验证码、展示图片或提示、收集验证码、携带验证 ID 和 `RequestHash` 重放原请求。 |
| `frontend/admin/packages/business/admin-framework/src/framework-commons/app/api/service-resp.ts` | 统一业务响应解包。动态验证码拦截器必须先于普通响应解包执行。 |

### 9.4 测试和协议文档

| 文件 | 作用 |
| --- | --- |
| `web-commons/src/test/java/com/levin/oak/base/web/interceptor/UrlAclInterceptorTest.java` | 后端 URL ACL 和动态验证码测试。覆盖 ACL 条件、拦截动作、四种验证码、验证 ID 缺失/请求不匹配拒绝。 |
| `frontend/admin/packages/business/admin-framework/src/framework-commons/app/api/__tests__/dynamic-verify-code.test.ts` | 前端公共请求拦截器测试。覆盖四种验证方式、弹窗、验证码申请、验证 ID 和 `RequestHash` 重放。 |
| `frontend/admin/packages/business/admin-framework/docs/dynamic-verify-code-flow.md` | 前端包内的动态验证码流程说明。 |
| `openspec/changes/20260525-1616-test-url-acl-interceptor/test-plan.md` | 本次 URL ACL 和动态验证码测试计划。 |

## 10. 排查方法

目标接口没有弹出验证窗口时，按顺序检查：

1. URL 访问控制规则是否启用。
2. URL、HTTP 方法、域名、IP、用户类型、角色等条件是否命中。
3. 当前用户是否已登录；未登录会优先返回登录要求。
4. 前端是否使用公共请求客户端。
5. 浏览器响应头是否包含 `-DynamicVerifyCode-: Apply`。

弹窗出现但验证码申请失败时，按顺序检查：

1. 当前验证类型是否被禁用。
2. 短信或邮箱发送通道是否配置完整。
3. MFA 用户是否已绑定密钥。
4. 图片验证码插件是否正常。
5. 后端是否返回 `-DynamicVerifyCode-ParamName` 和 `-DynamicVerifyCode-VerifyId`。

输入正确验证码后仍被拒绝时，按顺序检查：

1. 最终请求是否带回同一个 `-DynamicVerifyCode-VerifyId`。
2. 最终请求是否带回同一个 `-DynamicVerifyCode-RequestHash`。
3. 申请验证码和最终提交是否是同一个 method、URL 和请求体。
4. 验证码本身是否已经过期或被使用过。
5. 前端是否对同一个原请求生成并提交了同一个 `RequestHash`。

## 11. 部署注意事项

验证 ID 是由请求上下文字段计算出来的确定性 hash，不需要本机缓存，也不需要 Redis 或 Redisson。多节点部署时，只要前后两次请求携带的用户、租户、应用、验证类型、method、path 和请求体摘要一致，不会因为落到不同节点而失败。

请求体绑定依赖前端提交的 `-DynamicVerifyCode-RequestHash`，后端在可以读取缓存请求体时会优先使用服务端请求体摘要。若请求包含 body 但后端无法读取缓存请求体，前端必须提交 `-DynamicVerifyCode-RequestHash`；缺失时后端会拒绝生成或校验验证 ID，避免仅凭请求类型和长度绑定请求。若未来需要对所有请求强制服务端计算 body hash，应在 Web 入口增加请求体缓存过滤器，避免拦截器直接读取 servlet 输入流影响业务控制器。
