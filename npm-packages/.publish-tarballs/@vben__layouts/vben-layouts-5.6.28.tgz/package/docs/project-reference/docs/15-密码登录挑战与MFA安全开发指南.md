# 密码登录挑战与 MFA 安全开发指南

本文说明管理后台当前的密码登录挑战、MFA 选择、安全复核和前端接入约定。它面向后端接口消费者、前端实现者和运维人员；验证码插件的安装和通道配置继续参见 `docs/12-域名与验证码插件设计使用指南.md`。

本指南描述当前密码登录流程。账号恢复、MFA 绑定／重置／关闭、会话撤销和敏感操作的开发与验收还必须遵循 [安全开发规则](../20-安全开发规则.md) 的“身份、入口与可信上下文”，使用 [API安全审计模板](API安全审计模板.md) 分别记录证据；登录挑战通过不代表这些独立链路已完成验证。

## 1. 适用范围和边界

本流程只适用于**密码登录**。短信验证码登录和邮箱验证码登录仍沿用既有直接登录流程，不应为了 MFA 增加账号预查询接口，也不应在账号输入框失焦时探测账户是否已启用 MFA。

这样可以避免通过“账号支持哪些验证码方式”的响应泄露账号是否存在或是否启用 MFA。验证码方式只在账号密码已经通过服务端审计后返回。

## 2. 密码登录接口

RBAC 控制器提供两个 JSON 接口：

| 阶段     | 方法与路径                                 | 请求                                                                                                        | 成功响应 `data`                                     |
| -------- | ------------------------------------------ | ----------------------------------------------------------------------------------------------------------- | --------------------------------------------------- |
| 创建挑战 | `POST /rbac/loginVerifyChallenge`          | `LoginReq`，至少包含 `account`、`password`                                                                  | `challengeId`、`verifyCodeType`                     |
| 完成挑战 | `POST /rbac/loginVerifyChallenge/complete` | `LoginReq`，包含原始 `account`、`loginVerifyChallengeId`；需要验证码时还包含 `verifyCode`、`verifyCodeType` | 正常 `LoginInfo`，包括 `accessToken` 与当前用户信息 |

接口对应：

- 控制器：`web-commons/.../RbacController`
- 服务契约：`services/.../biz/rbac/AuthService`
- 实现：`web-commons/.../biz/rbac/AuthServiceImpl`
- 请求与响应：`LoginReq`、`LoginVerifyChallengeInfo`

`verifyCodeType` 的枚举值使用首字母大写的服务端名称，例如 `Captcha`、`Mfa`、`Sms`、`Email`。前端不得根据页面状态猜测类型，必须使用创建挑战接口返回的值原样完成请求。

## 3. 服务端决策和安全约束

创建挑战前，服务端会先完成一次常规密码登录审计，包括账号密码、当前域名、租户、账号状态、登录域名白名单、IP 和 User-Agent 等策略。

随后按以下优先级决定本次密码登录验证码：

1. 用户已绑定 `mfaSecretKey`：必须返回 `Mfa`；图片验证码不能作为替代方式。
2. 未绑定 MFA，且用户是超级管理员或当前租户 `LoginCfg.enableLoginVerifyCode = true`：返回 `Captcha`。
3. 其它情况：返回空类型；前端可直接调用完成挑战接口创建会话。

挑战是 Redis 中的短期、一次性记录。完成接口使用 `getAndDelete` 消费挑战，因此不能重放。完成时，服务端会重新审计而不是信任第一阶段缓存：

- 重新解析当前登录域名和当前域名租户；域名、租户、账号、应用 ID、IP、User-Agent 必须与挑战绑定上下文一致。
- 重新加载用户，复核账号状态、租户限制、登录域名限制和其它登录策略。
- 重新计算当前应要求的验证码类型；MFA 绑定、验证码策略或租户配置在两步之间发生变化时，旧挑战失效。
- 需要验证码时，提交类型必须和挑战类型完全一致，再调用验证码服务校验。

平台/超级管理员可从不同域名登录并模拟租户场景时，仍以当前服务端解析的域名、租户和实际账号策略为准；前端传入的域名或租户字段不是可信授权依据。

## 4. 前端实现约定

前端 API 封装位于 `@levin/admin-framework`：

```ts
import {
  completePasswordLoginApi,
  startPasswordLoginApi,
} from "@levin/admin-framework/framework-commons/app/api/core/auth";

const challenge = await startPasswordLoginApi({ account, password });

if (challenge.verifyCodeType) {
  // 打开验证码弹窗；Mfa 显示 Google 验证器引导。
  await completePasswordLoginApi({
    account,
    loginVerifyChallengeId: challenge.challengeId,
    verifyCode,
    verifyCodeType: challenge.verifyCodeType,
  });
} else {
  await completePasswordLoginApi({
    account,
    loginVerifyChallengeId: challenge.challengeId,
  });
}
```

交互规则：

- 用户点击“登录”后才创建挑战；账号输入框失焦时不请求 MFA 能力。
- `Mfa` 使用独立弹窗，标题和提示明确写为“Google 验证器验证”，要求输入当前六位 TOTP；不展示图片验证码或“下一步”按钮。
- `Captcha` 弹窗请求图片验证码。若识别结果可自动填入，显示 5 秒倒计时并自动完成挑战；用户修改验证码、刷新验证码或关闭弹窗时必须取消倒计时。
- 短信和邮箱验证码登录不进入挑战弹窗，也不受该倒计时影响。
- 验证码错误时，前端保留验证码弹窗、清空输入并创建新的 `challengeId`；旧挑战和临时验证码必须立即丢弃，不得复用。取消、账号变化或账号/域名/策略复核失败时，关闭弹窗并要求重新输入账号和密码。

具体参考实现：`frontend/admin/packages/business/admin-framework/src/framework-commons/app/views/_core/authentication/login.vue`。

## 5. MFA 运维配置

MFA 由 `MfaVerifyServicePlugin` 提供，默认插件为 Google Authenticator TOTP。启用服务插件后，用户可以在个人安全设置中查看/重置 MFA 二维码；重置会立即使旧密钥失效。

运维检查顺序：

1. 确认 MFA 服务插件已启用且未过期。
2. 确认目标用户已经绑定 MFA 密钥。
3. 确认服务端时间同步；TOTP 对时间偏差敏感。
4. 通过密码登录挑战接口验证返回类型是否为 `Mfa`，不要以独立账号探测接口判断。

## 6. 验收清单

- 已绑定 MFA 的账号无法用 `Captcha` 完成密码登录。
- 同一账号可继续使用短信或邮件验证码的既有非密码登录方式。
- 挑战完成后若账号被禁用、域名/租户上下文变化或 MFA 策略变化，登录被拒绝。
- 挑战不能重复使用，且错误验证码不会创建会话。
- MFA 弹窗清晰提示 Google Authenticator；图片验证码自动登录仅等待 5 秒。
