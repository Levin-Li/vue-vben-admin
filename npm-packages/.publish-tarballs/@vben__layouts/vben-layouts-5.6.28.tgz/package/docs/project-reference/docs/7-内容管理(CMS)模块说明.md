
#### 一、模块说明


#### 二、数据模型

##### 1、文章频道  ArticleChannel
##### 2、文章  Article


#### 三、主要的功能类
    服务类：ArticleChannelService，ArticleService
    控制器类：BizArticleChannelController，BizArticleController