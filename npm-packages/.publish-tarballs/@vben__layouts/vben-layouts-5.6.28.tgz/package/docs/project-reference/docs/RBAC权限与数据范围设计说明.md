# RBAC 权限与数据范围设计说明

## 1. 目的与边界

本说明定义本项目 RBAC 的资源权限、组织数据范围和机密数据访问等级如何共同决定一次请求是否允许执行或读取某条数据。

本说明中的“必须”均要求后端实现和验证；前端只能辅助展示、禁用选项和减少误操作，不能作为授权边界。

## 2. 核心对象

| 对象 | 负责内容 | 说明 |
| --- | --- | --- |
| 角色 `Role` | `permissionList`、`orgScopeList`、`confidentialDataAccessLevel` | 资源权限的唯一授予主体；角色可提供默认数据范围 |
| 用户 `User` | `roleList`、`orgScopeList`、`confidentialDataAccessLevel` | 通过角色获得资源权限；可对数据范围作个人化收紧或扩展（受操作者权限约束） |
| 组织范围 `SimpleOrgScope` | 租户表达式、组织根、allow/deny、表达式类型、范围表达式 | 描述可访问或排除的组织集合 |
| 业务数据 | `tenantId`、`orgId`、`confidentialLevel`、操作资源 | 同时具备这些归属时，必须参加完整数据访问判定 |

## 3. 三个独立授权维度

### 3.1 资源权限

资源权限只来自用户的生效角色：

```text
effectivePermissions(user)
  = distinct(union(permissionList(role) for role in effectiveRoles(user)))
```

- 用户不提供资源权限覆盖、补充或 deny 配置。
- 多个生效角色的资源权限取去重并集。
- 禁用、过期或失效角色不得贡献资源权限。
- 用户需要例外资源权限时，应调整角色组合或建立专用角色；不得为用户直接附加资源权限。

### 3.2 组织数据范围

```text
effectiveOrgScopes(user)
  = normalize(user.orgScopeList)                 if normalize(user.orgScopeList) is non-empty
  = merge(normalize(role.orgScopeList) ...)      otherwise
```

- 用户有效组织范围非空时，完全替换角色组织范围；不与角色范围合并。
- 用户范围为空、被清空或全部无效时，继承所有生效角色的组织范围合并结果。
- 无效规则包括缺少 `orgId` 或 `orgScopeExpression` 的规则。
- 同一有效范围内，先计算所有 allow 覆盖集合，再移除所有 deny 覆盖集合；deny 优先。

### 3.3 可访问机密等级

```text
effectiveConfidentialAccessLevel(user)
  = user.confidentialDataAccessLevel             if non-null
  = max(role.confidentialDataAccessLevel)        otherwise
```

- 参与取最大值的只能是生效角色。
- 用户值非空时精确覆盖角色最大值，即使该值更低。
- 用户值为空时才回退角色最大值。
- `confidentialLevel` 是数据对象自身的机密等级；`confidentialDataAccessLevel` 是主体可访问的最高机密等级，两者不得混淆。

## 4. 单条数据访问判定

对同一租户、具备组织归属和机密等级的数据 `D`，用户 `U` 对操作 `A` 的访问必须满足：

```text
canAccess(U, D, A)
  = tenantMatched(U, D)
  AND hasOperationPermission(U, A)
  AND orgInScope(U, D.orgId)
  AND effectiveConfidentialAccessLevel(U) >= D.confidentialLevel
```

任何一项为 false，详情、更新、删除、状态迁移等按 ID 操作必须拒绝；列表、统计、导出必须在返回前过滤该数据。

| 条件 | 后端责任 |
| --- | --- |
| 租户匹配 | 不允许请求参数或组织范围突破当前主体可访问租户 |
| 操作资源权限 | 根据控制器/资源操作的权限表达式检查 `effectivePermissions` |
| 组织范围 | 通过请求对象的数据范围条件或等价服务校验限制 `orgId` |
| 机密等级 | 数据对象的 `confidentialLevel` 不得高于主体有效可访问等级 |

若实体不具备其中某个归属字段，仅可省略不适用的维度；不得因开发便利而让应受组织或机密过滤的实体绕过对应请求对象/服务校验。

## 5. SimpleOrgScope 语义

### 5.1 字段

| 字段 | 含义 |
| --- | --- |
| `tenantMatchingExpression` | 规则适用租户：默认租户、精确租户、路径模式、所有租户、无租户或 `#!groovy:` |
| `orgId` | 规则根：具体组织、`_USER_ORG_` 或 `/*`（所有根组织） |
| `isAllow` | `true` 加入范围；`false` 从允许集合排除 |
| `orgScopeExpressionType` | `IdPath`、`NamePath`、`Groovy`、`SpringEL` |
| `orgScopeExpression` | 从规则根到候选组织的相对路径或动态表达式 |

### 5.2 标准路径模式

| 表达式 | 匹配结果 |
| --- | --- |
| `/` | 仅规则根 |
| `/*/` | 仅规则根的直接子组织 |
| `/*` | 规则根及直接子组织 |
| `/**` | 规则根及全部后代 |

### 5.3 自定义表达式

- `IdPath` 对相对组织 ID 路径匹配。
- `NamePath` 对相对组织名称路径匹配。
- `Groovy` 与 `SpringEL` 以 `_org`、`_user`、`_rootOrg`、`_scope`、相对路径为上下文求值；结果为 `true` 才匹配。
- 自定义表达式只能在规则根子树中评估，不能越过根组织。

## 6. 组织范围配置的授权规则

设操作者为 `O`，`authorizedOrgs(O)` 为后端计算出的操作者有效组织集合；规则 `S` 实际会涉及的组织集合为 `coveredOrgs(S)`。

保存任何用户或角色组织范围规则的必要条件：

```text
coveredOrgs(S) ⊆ authorizedOrgs(O)
```

这对 allow 和 deny 都生效。后端必须自行基于认证操作者、持久化组织树和租户关系计算，不能相信客户端提交的组织树、组织 ID 列表或“全组织权限”标志。

### 6.1 直接推导

- “所有组织”只允许操作者实际可访问该租户全部组织时提交。
- “所有租户”只允许操作者对规则可涉及的每个租户和组织都有权限时提交；普通租户用户不能通过 `*`、路径或脚本表达式扩大范围。
- 具体组织的 `/**` 规则必须检查所有可覆盖后代，而不是仅检查根组织。
- 组织范围覆盖到的组织机密等级不得高于操作者有效可访问机密等级。
- 超级管理员例外必须由后端身份判定；请求字段不能伪造。

## 7. 机密等级向上授权防护

操作者不能向任何主体授予高于自身的机密能力：

```text
new.confidentialLevel <= operator.effectiveConfidentialAccessLevel
new.confidentialDataAccessLevel <= operator.effectiveConfidentialAccessLevel
max(confidentialLevel(org) for org in coveredOrgs(scope))
  <= operator.effectiveConfidentialAccessLevel
```

校验对象包括用户、角色、组织范围及其实际覆盖的所有组织。校验失败时整个保存操作必须失败，不能部分写入。

## 8. 动态表达式安全

以下输入是高风险可执行配置：

- `ExpressionType.Groovy`
- `ExpressionType.SpringEL`
- `tenantMatchingExpression` 以 `#!groovy:` 开头

规则：

1. 只有后端认证为超级管理员的操作者可以创建或更新这些输入。
2. 普通管理员、租户管理员和平台普通用户直接调用 HTTP/RPC 接口提交时，后端必须拒绝且不得落库。
3. 超级管理员仍必须通过组织范围子集、租户边界和机密等级校验；脚本可保存不代表可越权授权。
4. 前端隐藏、禁用或提示只用于交互，不能替代后端服务入口校验。

## 9. 保存链路与缓存

用户或角色的创建、更新、角色分配、组织范围变更和机密等级变更后，必须使用标准缓存失效/重新登录边界验证：

- 新增权限立即生效；撤销权限不得被旧缓存长期保留。
- 用户组织范围变更后，组织树、详情和列表结果必须同步变化。
- 用户机密等级变更后，受限数据集合必须同步变化。
- 切换用户后，不得复用前一用户的权限、组织范围或机密等级。

## 10. 当前实现状态

| 能力 | 状态 |
| --- | --- |
| 角色资源权限并集 | 已实现并已回归验证 |
| 用户非空组织范围覆盖角色范围 | 已实现并已回归验证 |
| 用户机密访问等级覆盖角色最大值 | 已实现并已回归验证；禁用角色已被上游修复为不参与计算 |
| 标准组织路径、根选择器、deny、租户边界、Groovy、SpringEL | 已有自动化分支测试 |
| 自定义 `IdPath` / `NamePath` 的 `/*/*` 精确深度匹配 | 当前失败：错误放行整个子树，修复前不得用于生产授权 |
| 组织范围保存时的子集、全租户和机密等级校验 | 目标规则，尚需在用户/角色保存后端入口补齐 |
| 动态表达式仅超管保存 | 既有脚本类型后端限制存在；需补齐完整用户/角色创建更新与不落库回归测试 |

## 11. 测试与变更要求

每次修改本设计相关逻辑必须至少覆盖：

1. 资源权限：单角色、多角色、禁用角色、撤销后缓存刷新。
2. 组织范围：所有根选择器、标准路径、自定义 Id/Name/脚本、allow/deny、租户表达式、清空回退和无效规则。
3. 数据访问：资源权限、组织范围、机密等级、租户四项各自单独失败及全部满足。
4. 配置安全：无权组织、所有组织、所有租户、向上机密授权、Groovy/SpringEL/租户 Groovy 的绕过接口请求；所有拒绝用例均断言数据未落库。

详细测试数据、用例编号、当前执行结果和失败证据见《RBAC授权继承与用户数据范围覆盖测试方案》。
