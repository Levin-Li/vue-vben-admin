## Context

The generated update requests reuse the personal data model, but its owner query predicate deliberately applies only outside update mode. A business-layer authorization step is required to distinguish ordinary users from authorized administrators.

## Decisions

Each business controller copies its already injected update request into the entity's generated ID request, preserving tenant, organization, and owner scope. It loads the original target before mutation. If `isAdmin()` is false, it rejects a target whose persisted owner differs from the caller's injected owner. The original update request is then passed to the default service exactly once.

This is explicit ownership authorization, not a request-field restriction: a client cannot make an update valid by supplying a different owner ID. Administrators are still bounded by their existing ID request range and can retain their present management behavior.

## Verification

Controller tests cover owner mismatch rejection, matching-owner success, administrator success, and preservation of tenant/organization/owner fields on preloads for all three entities.
