# Design

后端 DTO 是字段原始类型的权威来源，页面配置在生成或维护阶段读取 DTO 后将该类型写入 `CrudFieldConfig.valueType`。共享 CRUD 表单只依据这一显式契约序列化值，因此不会将展示组件类型 `select` 与提交类型混为一谈。

现有 `number` 和 `boolean` 序列化路径保留。补充 `string` 分支，使下拉组件即使返回数值型 option value，仍能向字符串 DTO 提交字符串。数组字段逐项使用同一标量转换。

本次只补齐已审计到的 `ConfidentialLevel` 整数字段：用户的 `confidentialLevel`、`confidentialDataAccessLevel`，角色的对应两字段，以及机构的 `confidentialLevel`。这些字段均由服务端请求 DTO 声明为 `Integer`；不会修改后端接口或枚举选项接口。
