## ADDED Requirements

### Requirement: 枚举选择值按显式类型提交

系统 SHALL 按 `CrudFieldConfig.valueType` 序列化 CRUD 选择字段的提交值，不得根据字段名、选项文案或运行时值猜测后端 DTO 类型。

#### Scenario: 整数枚举提交

- **WHEN** 页面字段声明 `valueType: 'number'` 并提交选择值
- **THEN** 系统 SHALL 将该值转换为有限 JSON 数字

#### Scenario: 无效数字选择值

- **WHEN** 页面字段声明 `valueType: 'number'` 但选择值无法转换为有限数字
- **THEN** 系统 SHALL 在发起请求前报告明确错误

#### Scenario: 字符串枚举提交

- **WHEN** 页面字段声明 `valueType: 'string'` 并提交选择值
- **THEN** 系统 SHALL 将该值作为字符串提交
