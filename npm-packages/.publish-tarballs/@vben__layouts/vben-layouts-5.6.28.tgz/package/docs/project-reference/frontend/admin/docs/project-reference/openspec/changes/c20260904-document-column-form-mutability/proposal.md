## Why

实体字段的 JPA 可插入、可更新约束未被统一转化为前端表单行为，容易导致不可变字段在不恰当的表单场景展示或提交。

## What Changes

- 记录 `@Column(updatable = false)` 对编辑表单的默认展示、禁用与提交规则。
- 记录 `@Column(insertable = false)` 对新增表单的默认展示与提交规则。
- 明确该规则应在代码生成或静态页面配置阶段落地，公共运行时不按字段名猜测。
- 为公共 CRUD 字段配置补充“编辑态不提交”的显式开关，并将已审计到的角色编码、资金账户货币类型和货币代码落地为静态配置。

## Capabilities

### New Capabilities

- `column-form-mutability-guidance`: JPA 列可写性到 CRUD 表单行为的规范。

### Modified Capabilities

- 无。

## Impact

- 影响实体开发、代码生成、前端页面开发、代码审查规范及公共 CRUD 的载荷构建。
- 不修改数据库模型或接口契约；公共 CRUD 只执行页面显式声明的提交边界，不读取实体注解或按字段名推断。
