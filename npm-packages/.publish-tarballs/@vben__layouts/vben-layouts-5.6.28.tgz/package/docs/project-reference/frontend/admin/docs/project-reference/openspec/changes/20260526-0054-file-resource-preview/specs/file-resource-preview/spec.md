# File Resource Preview Specification

## ADDED Requirements

### Requirement: Preview File Resources

The file resource page SHALL provide a preview-oriented view named `资源预览` alongside the existing `列表` view.

#### Scenario: Switch To Preview View

- **WHEN** an operator opens the file resource library page
- **THEN** the page SHALL expose both `列表` and `资源预览` views
- **AND** selecting `资源预览` SHALL render file resources as preview cards

#### Scenario: Preview Media Resources

- **WHEN** a resource is an image, video, audio, PDF document, zip, or other file
- **THEN** the preview view SHALL render an appropriate preview or fallback for that resource type
- **AND** image resources SHALL support opening a large preview
- **AND** video and audio resources SHALL support playback from the preview modal

### Requirement: Download Preview Resources

The preview view SHALL support individual downloads and browser-side batch archive downloads for selected resources.

#### Scenario: Download Single Resource

- **WHEN** an operator clicks download on a resource card or preview modal
- **THEN** the browser SHALL download the selected resource URL when available

#### Scenario: Batch Download Selected Resources

- **WHEN** an operator selects multiple resource cards and starts batch download
- **THEN** the frontend SHALL fetch selected resource URLs and package them into a zip archive
- **AND** the archive SHALL include a `manifest.json` describing success and failure details
- **AND** individual fetch failures SHALL NOT block other selected files from being included

### Requirement: Maintain Resources In Preview View

The preview view SHALL allow operators to create, delete, and re-upload/edit file resources.

#### Scenario: Reupload Existing Resource

- **WHEN** an operator re-uploads an existing resource
- **THEN** the frontend SHALL upload the new file first
- **AND** only after upload succeeds SHALL it update the existing file resource record

#### Scenario: Image Upload Control

- **WHEN** an operator creates or edits a file resource with file type `Image`
- **THEN** the file path uploader SHALL use an image picture-card control
- **AND** non-image file types SHALL keep the existing file upload control

### Requirement: Seed Default Image Resources

Module data initialization SHALL create default image `FileRes` records for the preview view.

#### Scenario: Initialize Default Images

- **WHEN** module data initialization runs and the default image resources do not exist
- **THEN** the module SHALL create several public image `FileRes` records
- **AND** the image records SHALL use stable `bizObjId` values for idempotency
- **AND** the image records SHALL use image paths that render without external network access

#### Scenario: Skip Existing Default Images

- **WHEN** module data initialization runs and a default image resource already exists
- **THEN** the module SHALL NOT create a duplicate image resource for the same stable `bizObjId`
