## Why

公共 CRUD 页面目前不能区分“实体具有 `editable` 字段”与“查询表单实际提供 `editable` 控件”。非平台用户的默认查询条件必须只在用户可见、可操作该筛选项时生效，避免向没有此查询条件的接口附加参数。

## What Changes

- 公共 CRUD 仅在查询表单实际渲染 `editable` 筛选控件时，为非平台用户默认填写 `editable=true`。
- 查询控件隐藏、未配置为查询项或不存在时，不向查询状态和请求参数写入 `editable`。
- 内置编辑、删除和快捷布尔更新的可编辑性限制仅在当前 CRUD 元数据包含 `editable` 字段时生效；详情操作保持不受影响。
- 补充页面操作与查询表单开发规则，明确前端以实际可渲染的字段元数据作为 `EditableObject` 能力边界。

## Capabilities

### New Capabilities

- `crud-editable-query-default`: 根据公共 CRUD 查询表单实际渲染的 `editable` 控件，为非平台用户施加默认可编辑筛选。

### Modified Capabilities

无。

## Impact

- 前端：影响 `@levin/admin-framework` 的公共 CRUD 查询状态、内置操作显隐与回归测试。
- 接口：仅在界面已提供 `editable` 查询控件时，非平台用户的列表请求携带 `editable=true`。
- 后端：不新增接口或改变 `EditableObject` 约定；前端仅消费已下发的字段元数据。
