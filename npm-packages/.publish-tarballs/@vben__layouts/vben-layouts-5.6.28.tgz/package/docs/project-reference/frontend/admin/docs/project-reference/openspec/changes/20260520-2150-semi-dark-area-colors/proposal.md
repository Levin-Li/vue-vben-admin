# Semi Dark Area Colors

## Why

The preferences drawer currently lets users enable a semi-dark sidebar and semi-dark header, but it does not let them choose the colors for those two dark areas. Users need color controls beside the existing semi-dark switches so the sidebar and header can be customized independently.

## What Changes

- Add a color setting for the semi-dark sidebar row.
- Add a color setting for the semi-dark header row.
- Keep sidebar width adjustment in the existing layout sidebar section, using the current persisted sidebar width as its initial value.
- Add a header height adjustment in the layout header section, using the current persisted header height as its initial value.
- Keep the selected colors in preferences so copy/reset/cache behavior continues to work.
- Apply the configured sidebar color to the sidebar and sidebar-deep variables when the semi-dark sidebar is active.
- Apply sidebar width changes through the existing sidebar width preference so the menu layout and collapse calculations stay consistent.
- Apply the configured header color to the header variable when the semi-dark header is active.
- Apply header height changes through the existing header height preference so the layout, tabbar offset, and sidebar calculations stay consistent.
- Clamp manual sidebar width input to 160-480px and header height input to 40-160px.
- Use the existing 10px step for sidebar width changes, and use 2px steps for header height changes.
- Preserve existing disabled behavior for the semi-dark switches; color values can be configured but only affect the layout when the corresponding semi-dark option is active.

## Impact

- Affects the preferences drawer appearance tab.
- Affects the preferences drawer layout tab.
- Affects theme preferences defaults, types, and persisted preference payloads.
- Affects layout color rendering for semi-dark sidebar/header mode.
- Affects the existing header height preference from the layout header section.
- Affects the existing sidebar width preference from the layout sidebar section.
