# Limit CRUD export fields to data columns

## Why

The shared CRUD export dialog currently appends every visible field from a page config after the table fields. Query-only fields such as `containsTitle`, `tenantId`, or date range parameters can therefore appear in the export dialog next to their real table columns with the same label. This makes export choices look duplicated and may export empty query-parameter columns.

## What Changes

- Make shared CRUD export candidates default to table columns only.
- Allow page configs to opt a non-table field into export with `export: true`.
- Allow page configs to opt any field out of export with `export: false`.
- Keep the current table-column order behavior, including hidden table columns being available for export.
- Add an export-column alias input in the export dialog. The alias only changes the exported Excel header and does not change the list field key, query conditions, or table display.
- Export cell values should match the list display text by default, including existing boolean, dictionary, enum, tag, tenant, and numeric formatting behavior. No user-selectable conversion column is added.
- Refresh the current list after a successful export so the visible pagination total is based on the same latest query state as the exported data.
- Built-in query panel controls should support clearing a single condition without using the full reset action.
- Export should check the current query result count when the toolbar export button is clicked. If the result exceeds 50,000 rows, show a warning and do not open the export-field dialog.

## Impact

- Affects all pages using the shared CRUD page export dialog.
- Does not change list querying, table rendering, column settings, or row actions.
- Successful export now triggers one follow-up list refresh.
- Built-in query fields show per-field clear affordances where the underlying UI control supports them. Custom search slots remain owned by the slot implementation.
- Exports with more than 50,000 matching rows do not open the field-selection dialog, do not download a file, and do not page through the full result set.
