# Design: Redisson Default Scheduler

## Entity Model

`ScheduledTask` gains these fields:

- `schedulerType`: enum `Redis`, `PowerJob`, `XxlJob`; default `Redis`.
- `schedulerJobId`: external scheduler job id or Redis runtime job key.
- `schedulerAppName`: external scheduler application/executor name, used by PowerJob and later XXL-JOB.
- `handlerName`: logical execution handler name.
- `schedulerConfig`: JSON object for scheduler-specific settings.
- `runParams`: JSON object passed to handlers.
- `bizType`, `bizId`, `bizName`, `bizKey`: optional business object binding.
- `misfirePolicy`: enum `Ignore`, `FireOnce`, `FireAll`; default `FireOnce`.
- `timeoutSeconds`: execution timeout hint.
- `triggerTimeoutSeconds`: grace window for overdue trigger time. If the task is scanned within this many seconds after its planned fire time, it can still be triggered. If the overdue age is greater than this value, the task follows `misfirePolicy`.
- `retryCount`: max retry attempts.
- `retryIntervalSeconds`: delay between retries.
- `taskVersion`: monotonic version used to discard stale Redis messages.

`ScheduledLog` keeps the existing task id, cycle, snapshot, error flag, and result fields. Runtime code should use `taskId + executionCycle` as the idempotency boundary even before a database unique constraint is added.

All new entity enums must use `@GenNameConstant` and be stored as enum constant names.

## Runtime Architecture

```
ScheduledTask DB
  -> RedisSchedulerAdapter.rebuildDueIndex()
  -> Redisson RScoredSortedSet due index
  -> scan due tasks from every node
  -> RLock claim and RMapCache cycle idempotency
  -> RBlockingQueue execution queue
  -> worker consumes and invokes BizScheduledTaskService.execute(...)
  -> ScheduledLog + ScheduledTask metadata updates
```

All application nodes may run the scanner and worker. There is no leader election. A node wins a task cycle by acquiring a Redisson claim lock and writing a cycle idempotency marker.

PowerJob tasks use the same `ScheduledTask` fact source and execution service. The PowerJob adapter only mirrors task schedule metadata into PowerJob. When PowerJob fires, its processor bridge loads the local `ScheduledTask` by id and calls the same business execution method used by Redis.

## Redis Keys

Use a module-scoped prefix:

- `ScheduledTask:redis:due`: `RScoredSortedSet<String>`, score is next execution epoch millis.
- `ScheduledTask:redis:queue`: `RBlockingQueue<RedisScheduledTaskMessage>`.
- `ScheduledTask:redis:claim:{taskId}:{fireTime}`: `RLock`, claim current fire time.
- `ScheduledTask:redis:running:{taskId}`: `RLock`, used when `parallelExecution=false`.
- `ScheduledTask:redis:cycle`: `RMapCache<String, String>`, key is `{taskId}:{fireTime}`.

## Scheduling Flow

1. Every node scans the due sorted set at a fixed interval.
2. For each due task id, the node loads the current DB task.
3. The node verifies `enable=true`, `schedulerType=Redis`, and `nextExecutionTime <= now`.
4. The node acquires `claim:{taskId}:{fireTime}`.
5. The node writes a cycle marker through `RMapCache.fastPutIfAbsent`.
6. The node removes the task id from the due sorted set and enqueues a message.
7. The next execution time is computed from cron and written back after execution or skip handling.

The first implementation may use Redisson primitives instead of a Lua script. The required idempotency boundary is claim lock plus cycle marker plus DB log lookup. A later hardening pass may collapse claim/remove/enqueue into a Lua script if production evidence shows a failure gap.

## Execution Flow

1. Worker consumes `RedisScheduledTaskMessage`.
2. Worker reloads the current DB task and rejects stale disabled or non-Redis tasks.
3. If `parallelExecution=false`, acquire `running:{taskId}`.
4. Call `BizScheduledTaskService.execute(task, executor)` with the loaded task.
5. The execution service writes `ScheduledLog`, invokes the configured handler, captures result/error, and updates task metadata.
6. Worker computes the next fire time and re-adds the task to the due sorted set if it is still enabled.

## Handler Semantics

First-version execution supports existing `ExecutionContentType` values:

- `SpringBeanName`
- `SpringBeanClassName`
- `GroovyScript`
- `BeanShellScript`

Spring bean targets may implement `Runnable`, `Callable`, `Consumer`, or `Function`. The input object includes the task, cycle id, fire time, and run parameters.

## Admin Cron Editor

Scheduled-task create and edit forms should not expose the cron expression as a directly typed text field. The CRUD form framework provides a reusable `cron` field type backed by a shared Cron expression editor component. The field renders a read-only preview plus an edit action; editing happens in a modal with common presets and per-segment controls for the six-part cron format used by the scheduler. Numeric choices should prefer selectors over typed inputs so operators can build expressions by choosing presets, fixed values, intervals, ranges, or specific value sets.

## PowerJob Integration

Add a dependency on `tech.powerjob:powerjob-client` for OpenAPI operations and `tech.powerjob:powerjob-worker` for the processor bridge. PowerJob upstream documents CRON, fixed rate, fixed delay, and OpenAPI timing strategies, and its Java client exposes `saveJob`, `enableJob`, `disableJob`, and `deleteJob`. This change uses CRON jobs and standalone execution mode.

Adapter behavior:

1. Build `SaveJobInfoRequest` from `ScheduledTask`.
2. Use system settings for PowerJob server address list, password, default app name, and default processor info. Task fields may override the app name and handler where the business object needs a specific executor, but PowerJob infrastructure configuration is sourced from system settings rather than application properties.
3. Set `timeExpressionType=CRON`, `timeExpression=cron`, `executeType=STANDALONE`, and `processorType=BUILT_IN`.
4. Set `processorInfo` to the local processor bridge bean/class configured by `handlerName` or default module setting.
5. If `schedulerJobId` is not present, query PowerJob by job name and embedded `taskId` before creating, so a retry after a failed local id write reuses the existing external job instead of creating duplicates.
6. Store the returned PowerJob job id in `schedulerJobId`.
7. On disable/delete, call the matching PowerJob client API when `schedulerJobId` is present.

System setting:

- `PowerJobSchedulerSetting`: class-editor JSON setting loaded through `BizSettingService`, containing address list, default app name, password, app id, default processor info, worker enable flag, worker port, protocol, and lazy server connection flag.

PowerJob processor behavior:

1. Parse `jobParams` as a scheduled-task id or JSON object containing `taskId`.
2. Load the task from DB.
3. Build a cycle id from PowerJob job id, instance id, and current attempt.
4. Invoke `BizScheduledTaskService.execute(...)`.
5. Return success or failure to PowerJob based on the execution result.

## Misfire

First version supports the modeled policy conservatively:

- `Ignore`: skip if the configured fire time is already stale when scanned.
- `FireOnce`: execute once for accumulated missed time.
- `FireAll`: modeled but may behave as `FireOnce` until catch-up iteration is implemented.

`triggerTimeoutSeconds` is checked before applying misfire behavior. Example: if a task should run at 10:00:00 and `triggerTimeoutSeconds=300`, scanning at 10:04:00 still triggers the 10:00 cycle; scanning at 10:10:00 treats it as a misfire.

## Verification

- Compile `entities` before code generation.
- Run `simple-dao-codegen` from the entity module.
- Compile affected Java modules.
- Add focused tests where practical for next-fire calculation, idempotent claim, and handler invocation.
- Verify admin row actions for sync, stop, and single trigger through the API and browser UI.
