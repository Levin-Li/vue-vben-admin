## ADDED Requirements

### Requirement: 租户站点具有业务类型

TenantSite MUST 提供可持久化的通用字符串 type 字段。字段不预置业务取值，历史空值 MUST 保持兼容。

#### Scenario: 创建带类型标记的站点

- **WHEN** 管理员创建租户站点并填写 type
- **THEN** 系统保存并在后续查询中返回该 type
