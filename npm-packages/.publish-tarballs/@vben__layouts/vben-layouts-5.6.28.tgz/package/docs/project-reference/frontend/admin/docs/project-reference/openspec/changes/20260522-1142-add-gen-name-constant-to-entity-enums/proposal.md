# 为实体模块枚举补齐 GenNameConstant

## 背景

实体模块中的枚举需要统一生成枚举常量名称，避免不同实体枚举在代码生成或前端元数据使用时表现不一致。

## 变更范围

- 检查 `entities` 模块中的所有 Java 枚举。
- 对缺少 `@GenNameConstant` 的实体模块枚举补齐注解和必要 import。
- 不修改 `code-gen.md` 标记保护的生成目录。

## 验收标准

- `entities` 模块中目标枚举声明均包含 `@GenNameConstant`。
- 实体模块编译通过。
