## ADDED Requirements

### Requirement: Agent 工作流必须有单一需求事实源

本项目 SHALL 将 OpenSpec 作为需求、约束、验收标准和任务列表的唯一事实源。任何 Agent、技能、OMX 模式或子 Agent 在执行前 MUST 确认相关任务已经记录到对应 OpenSpec change；当用户追加或调整要求时，MUST 先更新 OpenSpec，再继续实现。

#### Scenario: 用户追加需求

- **WHEN** 用户在执行过程中追加新的需求、约束、验收标准或任务
- **THEN** Agent 必须先更新当前 OpenSpec change 的 `tasks.md` 或相关 spec 文档，再继续改代码或文档

#### Scenario: 使用其他执行工具

- **WHEN** Agent 使用 OMX 模式或子 Agent 执行任务
- **THEN** 这些工具不得替代 OpenSpec 记录，且不得跳过 OpenSpec 前置要求

### Requirement: 日常执行动作不得默认写入 OpenSpec 任务

本项目 SHALL 将 OpenSpec 用于记录需求、约束、验收标准和开发任务。读取文件、检查状态、运行已有测试、构建、发布、提交、推送、整理最终报告等日常执行动作 MUST NOT 默认作为 OpenSpec 需求任务记录；这些动作 SHOULD 在执行过程、提交信息或最终报告中说明。

#### Scenario: 用户要求发布和推送

- **WHEN** 用户要求执行发布、提交或推送等日常交付动作，且没有新增需求、行为变化、约束变化或验收标准变化
- **THEN** Agent 应直接执行并在最终报告中说明结果，不应为了这些动作新增 OpenSpec 任务

#### Scenario: 日常动作暴露新问题

- **WHEN** 构建、测试、发布或推送过程中发现需要改变代码行为、补充约束、调整验收标准或新增修复任务
- **THEN** Agent 必须先把新增需求或修复任务回写 OpenSpec，再继续实现对应变更

### Requirement: OpenSpec change 目录必须按时间前缀命名

本项目 SHALL 要求新建 OpenSpec change 目录使用 `YYYYMMDD-HHMM-语义名称` 格式。时间前缀用于保证 `openspec/changes/` 目录按创建时间自然排序，语义名称用于说明变更目的。

#### Scenario: 新建 OpenSpec change

- **WHEN** Agent 或维护者需要为新需求、约束、验收标准或开发任务创建 OpenSpec change
- **THEN** 新目录名称必须以当前时间前缀开头，例如 `20260519-1829-clarify-agent-workflow-priority`

#### Scenario: 继续维护未归档 change

- **WHEN** Agent 继续维护已有但未归档的 OpenSpec change，且该目录没有时间前缀
- **THEN** Agent 可以在不破坏引用的前提下将目录补齐为时间前缀格式，并同步更新验证命令或文档引用

### Requirement: 带 Spring Boot 启动类的 JAR 不得发布到 Maven 私服

本项目 SHALL 将 Maven 私服发布范围限定为可被其他模块依赖的库、接口、服务和公共模块构件。包含 Spring Boot 启动类、可直接 `java -jar` 启动的 bootstrap 程序 JAR MUST NOT 发布到 Maven 私服。

#### Scenario: 执行后端 Maven deploy

- **WHEN** Agent 或维护者执行后端 Maven deploy 发布到私服
- **THEN** 发布范围必须排除 `admin-bootstrap`、`client-bootstrap` 等带启动类的可执行 JAR
- **AND** 不得使用 `deploy:deploy-file` 绕过这些模块 POM 中的 deploy skip 配置

#### Scenario: 需要后端程序包

- **WHEN** 需要生成后端程序包用于验证或运行环境交付
- **THEN** 可以执行 package 生成 bootstrap JAR
- **AND** 生成程序包不代表可以把该启动 JAR 发布到 Maven 私服

### Requirement: 结构化执行原则必须作为默认工程纪律

本项目 SHALL 将结构化执行原则作为默认工程纪律，用于指导必要的计划、测试优先、系统化调试、代码审查和完成前验证。项目 MUST NOT 强制依赖特定外部执行工具，且外部执行工具 MUST NOT 成为独立于 OpenSpec 的需求或任务事实源。

#### Scenario: 普通实现任务

- **WHEN** Agent 执行已经记录到 OpenSpec 的普通实现任务
- **THEN** Agent 应按任务风险选择合适的结构化执行原则，例如测试优先、系统化调试或完成前验证，而不是创建另一套任务记录或强制启动特定外部执行工具

#### Scenario: 运行环境没有特定外部执行工具

- **WHEN** 当前 Agent 环境没有特定外部执行工具或用户没有要求使用额外工具
- **THEN** Agent 仍必须遵循计划、调试、测试和验证等工程纪律，但不得因为缺少特定工具而阻塞普通任务

### Requirement: 明确实现类任务必须自主闭环推进

本项目 SHALL 要求 Agent 对明确的实现类任务采用端到端自主推进方式。Agent MUST NOT 在需求确认、方案规划、代码实现、测试验证、失败修复、必要的发布、提交、推送代码和最终汇报等阶段之间无限等待用户逐步确认；除关键节点 3 分钟人工确认窗口和真实阻塞事项外，不得把阶段切换变成人工审批关卡。只有当下一步操作具有破坏性、不可逆、需要额外权限、涉及重大产品取舍，或存在真正阻塞执行的歧义时，Agent 才应向用户提问。

#### Scenario: 需求足够明确

- **WHEN** 用户提出的实现任务已经足够明确，且下一步工作可以通过读取代码、运行命令、查看日志或执行测试获得必要信息
- **THEN** Agent 必须自主完成需求确认、方案规划、实现、验证、失败修复、必要的发布、提交、推送代码和最终汇报
- **AND** Agent 不得要求用户提供可由本地上下文或工具验证获得的信息

#### Scenario: 验证未通过

- **WHEN** 实现后的测试、构建或其他验证未通过
- **THEN** Agent 必须继续定位并修复问题，直到任务完成、遇到真实阻塞，或用户明确要求停止

#### Scenario: 交付要求包含发布提交推送

- **WHEN** 任务目标或交付要求包含发布、提交或推送代码
- **THEN** Agent 必须将这些动作纳入闭环交付，不应作为额外强确认节点长期等待
- **AND** 如果发布或推送属于本次交付要求，必须并入提交代码确定环节的 3 分钟人工确认窗口
- **AND** 只有发布环境、提交范围、远端分支、权限缺失、不可逆风险或重大产品取舍存在真实阻塞时，Agent 才应向用户提问

#### Scenario: 发布版本成功后自动提交推送

- **WHEN** Agent 成功发布版本
- **THEN** Agent 必须自动提交并推送本次发布相关代码、版本文件、规则文档和需求记录
- **AND** Agent 不得把发布后的提交推送留给用户另行提醒
- **AND** 只有提交范围、远端分支、权限缺失、不可逆风险或重大产品取舍存在真实阻塞时，Agent 才应暂停并说明阻塞

#### Scenario: 关键节点需要人工确认窗口

- **WHEN** Agent 到达需求确定、执行计划确定、验证结论确定或提交代码确定等重要环节
- **THEN** Agent 必须简要汇报当前结论和下一步动作，并给用户最多 3 分钟确认、打断或调整
- **AND** 如果 3 分钟内没有收到确认或回复，Agent 必须自动继续执行
- **AND** 如果发布或推送属于本次交付要求，必须并入提交代码确定环节
- **AND** 该确认窗口不得演变成无限等待；但破坏性、不可逆、权限缺失或重大产品取舍等真实阻塞事项仍必须获得明确授权或先改走安全替代路径

### Requirement: OMX 必须作为按需编排层

本项目 SHALL 将 OMX 作为可选编排层。只有任务需要多 Agent 并行、复杂计划评审、长期执行状态、持续验证循环，或用户明确要求 OMX 模式时，Agent 才应启用 OMX；普通单线任务 MUST 默认直接执行。

#### Scenario: 简单单线任务

- **WHEN** 用户请求一个范围明确且可在当前会话完成的单线任务
- **THEN** Agent 必须按 OpenSpec 和项目规则直接执行，不应仅因为存在 OMX 就启动复杂编排

#### Scenario: 复杂并行任务

- **WHEN** 任务包含多个相对独立的实现或验证方向，且并行能明显提升质量、速度或安全性
- **THEN** Agent 可以在 OpenSpec 任务已记录后启用 OMX 或子 Agent 编排，并由主 Agent 负责整合与最终验证
