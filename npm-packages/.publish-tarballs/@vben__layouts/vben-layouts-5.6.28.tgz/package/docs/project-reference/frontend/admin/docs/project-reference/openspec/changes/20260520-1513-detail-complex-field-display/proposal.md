# Detail Page Complex Property Display Rules

## Summary

Clarify that detail pages should not render complex-type properties by default. Only explicit JSON object fields and basic-type lists should be displayed, JSON display should use a compact read-only text area plus a Json Viewer action, and enum/dictionary/fixed option values should render their labels.

## Motivation

Complex object properties can make detail pages noisy, unstable, and hard to recover when a nested renderer fails. The default detail-page behavior should minimize blast radius and only display complex data when its presentation contract is clear.

## Scope

- Add frontend page-rule documentation for complex-type property defaults in detail pages.
- Add frontend page-rule documentation for enum, dictionary, and fixed option label display in detail pages.
- Inventory all detail-page entry points before implementation because most pages share one renderer.
- Implement the rule in shared detail/ShowForm rendering where possible; avoid page-by-page hardcoding.
