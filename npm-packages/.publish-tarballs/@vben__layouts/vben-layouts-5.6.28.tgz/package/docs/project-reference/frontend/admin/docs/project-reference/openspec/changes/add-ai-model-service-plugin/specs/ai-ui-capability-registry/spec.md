## ADDED Requirements

### Requirement: 当前用户的界面能力目录
系统 SHALL 为当前用户发布 AI 可发现的界面能力目录。每项能力 MUST 包含稳定标识、名称、输入 Schema、读取或写入类型、风险等级及执行所需权限，且只能来自已登记的菜单、通用 CRUD 或显式业务动作。

#### Scenario: 仅发布用户可用能力
- **WHEN** 用户请求 AI 可用能力目录
- **THEN** 系统只返回该用户当前租户、角色和数据范围内可使用的能力

### Requirement: 通用 CRUD 映射
系统 SHALL 将已启用 CRUD 页面中的查询、详情、创建、修改、删除和批量操作映射为受控 AI 工具，并复用原有请求对象及服务层校验。

#### Scenario: AI 查询 CRUD 数据
- **WHEN** AI 选择一个已发布的查询工具
- **THEN** 系统使用原有查询请求对象和数据范围过滤返回结果

## ADDED Requirements

### Requirement: 禁止任意后端调用
系统 MUST NOT 允许模型直接调用任意 HTTP 控制器、DAO、SQL、动态脚本或未登记业务服务。

#### Scenario: 拒绝未登记工具
- **WHEN** 模型请求执行不在能力目录中的工具标识
- **THEN** 系统拒绝执行并记录安全审计事件
