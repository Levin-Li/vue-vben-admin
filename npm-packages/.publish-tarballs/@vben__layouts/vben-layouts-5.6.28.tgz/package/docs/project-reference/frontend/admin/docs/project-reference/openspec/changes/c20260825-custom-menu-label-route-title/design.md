## Context

`TenantCustomMenu.itemList` 已保存每个节点的展示标签。后端将该标签下发为授权菜单的 `name`，而前端 `buildMenuRoutes` 将授权菜单转换为 Vue 路由及其 `meta.title`。本地页面映射同时含有固定的 `title`，目前本地页面分支错误地优先使用它，导致自定义标签不可见。

## Goals / Non-Goals

**Goals:**

- 让非空的授权菜单名称成为已映射本地页面的最终路由标题。
- 维持页面映射标题作为缺失菜单名称时的稳定回退。
- 用单元测试固定该优先级。

**Non-Goals:**

- 不改变路由路径、组件映射、图标、权限或后端菜单下发逻辑。
- 不在保存后即时重建当前浏览器会话的动态路由。

## Decisions

- 在 `convertLeafRoute` 的 `LocalPage + mapping` 分支中使用 `item.name || mapping.title || normalizedPath`。授权菜单名称包含布局标签，是导航展示层的运行时事实；页面映射标题只描述页面的默认标题。
- 在现有 `menu-route` 单元测试中添加断言。该测试直接覆盖路由 `meta.title`，无需引入浏览器、接口或后端测试。

## Risks / Trade-offs

- [当前已加载路由不会自动重建] → 保存后的用户需刷新页面或重新登录以拉取新的授权菜单树；本修复不扩展为运行时菜单热更新。
- [空名称覆盖默认标题] → 使用逻辑或回退，空名称继续使用页面映射标题。
