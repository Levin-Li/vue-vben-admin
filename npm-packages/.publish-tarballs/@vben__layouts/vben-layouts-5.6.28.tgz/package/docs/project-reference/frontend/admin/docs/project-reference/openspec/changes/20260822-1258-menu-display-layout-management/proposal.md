## Why

租户需要在不修改真实菜单、路由和权限结构的前提下，自定义后台菜单的展示层级。原 `MenuDisplayLayout` 实体（现为 `TenantCustomMenu`）以嵌套 `itemList` 保存布局，但缺少面向管理员的专用查看与编辑界面。

## What Changes

- 将 `MenuDisplayLayout` 重命名为 `TenantCustomMenu`，并生成对应的默认服务和控制器代码；保留现有数据映射和 API 路径以兼容调用方。
- 新增“自定义菜单”标准 CRUD 管理页面，提供多记录列表查询、新增、编辑和删除；每条记录额外提供“调整菜单”操作进入该记录的专用双树调整器，`itemList` 也可按普通 JSON 字段维护。
- 菜单名称统一展示为“自定义菜单”，并保证其后端菜单路径与前端页面路由均指向 `TenantCustomMenu` 页面。
- 后端继续在保存 `itemList` 时校验重复、失效和非法树结构。
- 授权菜单输出按当前租户和域名优先读取专属布局；未命中时回退租户公共布局，布局记录不存在或 `itemList` 为空时回退原始菜单树。
- 授权菜单下发必须同时满足菜单自身的展示权限和菜单配置的全部额外所需权限；列表等接口权限可作为额外权限配置，但仍由接口调用独立校验。

## Capabilities

### New Capabilities

- `menu-display-layout-management`: 租户菜单展示层级的专用查看、编辑、校验与读取契约。

### Modified Capabilities

- 无。

## Impact

- 新增 `TenantCustomMenu` 的默认生成服务、控制器、请求对象与前端 API；既有 `/MenuDisplayLayout` API 路径继续兼容。
- `TenantCustomMenu` 新增可选 `domain` 字段，同租户可按域名分别维护同名布局。
- `admin-api` 中新增菜单展示层级业务控制器；`oak-base-admin` 新增专用管理页面。
- 授权菜单输出消费“当前租户首个非空布局或原始菜单树”读取契约，并供现有侧边栏与路由渲染复用。
- 影响授权菜单服务的权限筛选语义与菜单管理的权限提示；不修改任何接口的后端授权规则。
