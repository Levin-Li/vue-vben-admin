## Why

组织与用户选择器在组织不可选时仍需呈现完整层级。当前组件库的禁用样式使组织名称过浅，削弱了组织结构的可读性。

## What Changes

- 保持不可选组织节点的禁用与不可选择语义不变。
- 将不可选组织节点的文字颜色调整为正常文本色的约三分之二明度，避免使用组件库默认的低对比度禁用灰。
- 不调整节点的选择、勾选、悬停、展开或加载行为。

## Capabilities

### New Capabilities

- `user-org-selector-disabled-org-text`: 组织与用户选择器中不可选组织节点的可读文字色。

### Modified Capabilities

- 无。

## Impact

- 影响 `@levin/admin-framework` 中的公共 `UserOrgSelector` 展示样式。
- 不影响后端接口、权限、数据模型、公开参数或选择结果。
