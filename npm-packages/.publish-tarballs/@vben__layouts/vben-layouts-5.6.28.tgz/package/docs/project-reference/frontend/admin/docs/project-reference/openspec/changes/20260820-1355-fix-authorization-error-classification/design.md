# Design

权限不足和未登录是不同的安全状态。`AuthorizationException` 只在当前请求已经具备登录身份、但 RBAC 判定拒绝访问时产生，因此必须使用 `AuthorizationError` 的业务码区间和 HTTP 403；`AuthenticationException` 仍使用 `AuthenticationError` 与 HTTP 401。

前端共享响应解析已按业务码和 `errorType` 区分认证与授权错误，无需添加字符串判断或在页面层做特殊分支。修正服务端类型后，错误提示将自动使用既有的授权错误文案。

授权拒绝提示由共享响应解析层统一决定，页面不再为 HTTP 403、`AuthorizationError` 或业务码 `25000` 分别实现提示。共享 TypeScript 分类表必须镜像后端 `com.levin.commons.service.domain.ServiceResp.ErrorType`：`getErrorType` 的结果、错误码区间和枚举名称均从该表导出。对于解析为 `AuthorizationError` 的响应，若后端返回非空 `msg`，直接显示该业务文案；否则显示固定文案“未授权的请求”。HTTP 403 在无可解析 `ServiceResp` 时也使用同一展示规则。HTTP 401 继续沿用既有的刷新令牌和重新认证流程，不纳入此规则。
