## Context

`ServicePlugin` 是不区分租户的全局插件元数据，`providerList` 的每项已包含供应商编码、名称、启停状态和 `configEditor`。`ServicePluginSetting` 才是租户/域名的实际供应商参数。支付通道是独立的可选通道记录：它必须按货币类型使用相应支付插件的全局供应商目录，而不能混用法币和数字货币配置模型。

目前法币由 `BizPayServicePlugin` / `DefaultBizPayServiceImpl` 承担，数字货币由 `CryptoPayServicePlugin` / `UsdtPayServicePlugin` 承担。支付页面只有通用 JSON `detailInfo` 编辑器；现有后端绑定器仅能在传入 `providerCode` 后写入 `@JsonSchema`。

## Goals / Non-Goals

**Goals:**

- 让两个支付插件族都通过 `SimpleServicePlugin` 生命周期同步全局供应商目录。
- 页面根据 `currencyType` 静态映射到一个支付插件实现标识，再读取对应的全局供应商列表。
- 管理员选择供应商后使用其 `configEditor` 生成结构化 JsonSchema 表单；供应商编码持久化到 `PayChannel.providerCode`，详情 JSON 同步保留 `providerCode` 和 `@JsonSchema` 以兼容既有配置。
- 将 `PayChannel.type` 重命名为 `category`，仅承担通道类别/筛选语义。
- 后端拒绝不属于当前货币插件族、被禁用或无配置编辑器的供应商，防止绕过页面构造错误配置。
- 把复用 `ServicePlugin.providerList.configEditor` 的规则写入插件开发规范。

**Non-Goals:**

- 不将 `PayChannel.category` 收紧为枚举或作为运行时配置路由键。
- 不允许管理员输入任意 Java 类名、Schema URL 或跨插件供应商编码。
- 不把支付通道实际商户配置迁移到 `ServicePluginSetting`；它继续保存在各个支付通道的 `detailInfo`。
- 不新增动态的“货币类型到插件”后端注册 API；当前两类映射由页面静态维护。

## Decisions

### 1. 供应商目录复用全局 ServicePlugin 元数据

法币和数字货币插件各自声明 `providerList`，以稳定 `code` 和 `configEditor` 作为唯一配置模型目录。页面读取已有服务插件接口得到目录，不能把类名写入支付通道页。

备选方案是新建支付专用映射表；拒绝原因是会重复 `ServicePlugin.Provider` 已有的供应商、启停和 Schema 能力。

### 2. 页面按 currencyType 静态选择插件族

支付页面维护 `LEGAL_TENDER -> DefaultBizPayServiceImpl` 与 `BLOCK_CHAIN_TOKEN_COIN -> UsdtPayServicePlugin` 的静态映射。它以全局插件实现标识过滤供应商目录，防止数字货币通道选择支付宝等法币配置，或法币通道选择链上供应商。

备选方案是把映射放到后端运行时路由；拒绝原因是当前只有两个固定插件族，页面静态配置可直接表达该交互，不增加接口和注册表复杂度。

### 3. ProviderCode 是支付通道的供应商事实字段

后端按 `currencyType` 取得对应插件的全局供应商目录，验证 `PayChannel.providerCode` 属于当前插件族、供应商可用且拥有可解析的配置编辑器。保存时将相同编码写入详情 JSON，并写入与供应商配置编辑器一致的 `@JsonSchema`。运行时先读取实体字段；只有历史记录尚未迁移时才回退读取详情 JSON。

将供应商编码只留在 JSON 内的方案会使数据库筛选、索引、校验和运行时路由依赖非结构化数据，予以拒绝。

### 4. Category 是支付通道的业务分类

`PayChannel.type` 重命名为 `PayChannel.category`，保持系统字典管理和支付通道筛选能力，但不再代表支付宝、微信等供应商。前端将该字段展示为“通道类别”；供应商由独立的受控选择器维护。数据库迁移同步重命名 `base_pay_channel.type` 和 `PayChannel.type` 字典编码。

`PayOrder` 使用 `payChannelCategory` 与 `payChannelProviderCode`，在创建支付订单时从实际选中的支付通道复制，形成不可随通道后续改动而变化的订单事实快照。`payChannelType` 被移除；数据库迁移将历史 `pay_channel_type` 列直接重命名为 `pay_channel_category`，不保留双字段兼容层。

保留 `type` 作为实体别名的方案会持续混淆类别和供应商，并使生成的 API 有两种不一致字段，予以拒绝。

### 5. 后端执行归属与 Schema 完整性校验

页面映射只决定交互，不能成为安全边界。创建和更新支付通道时，后端按 `currencyType` 取得对应插件的全局供应商目录，验证实体 `providerCode`、供应商可用性及其 `configEditor`，并写入与配置编辑器一致的 `@JsonSchema`。已有带 `@JsonSchema` 的历史记录允许继续读取；管理员更新时必须满足新校验。

### 6. 配置数据仍归属 PayChannel

服务插件的全局目录只描述“可选择什么供应商、使用哪个配置模型”，而每条支付通道的商户号、证书引用、回调地址等仍存于 `PayChannel.detailInfo`，维持现有多通道能力。`ServicePluginSetting` 不用于保存支付通道的具体商户配置。

### 7. JsonSchema 请求使用 Oak 基础模块 API 前缀

`JsonSchemaController` 映射在 Oak 基础模块的 `API_PATH` 下。共享前端 `JsonSchemaService` 必须以 `/com.levin.oak.base/V1/api` 作为 `RequestService` 模块前缀，最终请求 `/com.levin.oak.base/V1/api/jsonSchema/genJsonSchema`。不得依赖页面 CRUD 配置推导该前缀，避免支付通道等独立结构化编辑器请求到根路径而返回 404。

## Risks / Trade-offs

- [页面映射随新增支付插件而过期] → 新增支付插件时必须同步页面映射及定向测试；开发规范中明确此要求。
- [历史通道缺少实体 `providerCode` 或 `@JsonSchema`] → 迁移脚本优先从详情 JSON 回填；无法识别的历史记录保持为空，编辑保存时要求选择有效供应商。
- [管理员禁用供应商后历史通道不可编辑] → 读取和运行保持既有行为；新建与配置变更拒绝禁用供应商，并给出明确错误。
- [供应商配置类包含敏感字段] → 配置类只声明密钥/证书引用名，不保存明文；继续沿用数据脱敏授权。

## Migration Plan

1. 先执行 PostgreSQL 迁移，重命名字段及字典编码，并从详情 JSON 回填可识别的 `providerCode`。
2. 发布后由服务插件初始化同步两类支付插件的全局供应商目录。
3. 管理员打开旧通道编辑页时，未绑定的通道需先选择供应商，系统再生成结构化配置表单。
4. 如需回滚，恢复包含 `type` 的旧版本前先将数据库列和字典编码恢复；已保存的 `@JsonSchema` 是 JSON 扩展字段，不影响旧版本读取。

## Open Questions

- 本次仅覆盖现有法币和 USDT 数字货币插件；后续新增货币插件时按本规范扩展页面静态映射。
