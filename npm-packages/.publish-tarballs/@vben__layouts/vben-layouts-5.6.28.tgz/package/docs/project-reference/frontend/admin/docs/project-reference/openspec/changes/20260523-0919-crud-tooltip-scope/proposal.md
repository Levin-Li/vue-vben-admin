# Scope CRUD hover content guidance

## Why

Long hover content in CRUD interfaces can block scanning and form reading, but applying a global tooltip rule to every admin component or every CRUD surface is too broad. The rule should be limited to four common CRUD interface areas: list area, create form, edit form, and detail form.

## What Changes

- Document that hover content constraints apply only to CRUD interfaces, specifically the list area, create form, edit form, and detail form.
- Keep ordinary `common-ui`, login, icon picker, and non-CRUD page tooltip behavior outside this rule.
- Keep CRUD search forms, table toolbars, column settings panels, and other non-target CRUD surfaces outside this rule.
- Clarify that CRUD list cells should show short previews on hover, while long permission/resource/code lists should use summaries or click-driven detail views.

## Impact

- Affects frontend rules and published admin-framework frontend rules.
- Does not change runtime behavior by itself.
