# Change: Split organization-user page from plain user management

## Why

The existing `用户管理` entry is a compound page that combines an organization tree with a filtered user list. The menu name and route should communicate that compound workflow, while a separate plain list-style user management page remains available.

## What Changes

- Rename the existing organization tree + user list page to `组织与用户`.
- Move that compound page to a semantically matching route `/clob/V1/OrgUser`.
- Add a plain list-style `用户管理` page at `/clob/V1/User`.

## Impact

- Frontend module route and backend route mapping metadata change for the base admin module.
- Existing user CRUD configuration is reused for both pages; the compound page keeps its organization-tree behavior, while the plain page uses the shared CRUD list directly.
