## Why

登录页目前只有供应商配置显式下发 `iconUrl` 时才显示图标；未配置时所有 OAuth 平台都退回同一个扫码图标，用户无法区分微信、支付宝、QQ 等入口。

## What Changes

- 为 JustAuth 供应商编码及现有展示别名提供本地默认图标映射。
- 保留服务插件设置中的自定义图标地址优先级。
- 未识别的第三方插件供应商继续使用中性兜底图标，避免登录页空白。

## Capabilities

### New Capabilities

- `oauth-login-provider-icons`: 登录页 OAuth 平台的本地图标解析与自定义覆盖规则。

### Modified Capabilities

- 无。

## Impact

- 影响管理端登录页的 OAuth 按钮图标渲染和对应前端测试。
- 不改变服务端供应商目录、OAuth 配置、授权接口、凭据或登录权限。
