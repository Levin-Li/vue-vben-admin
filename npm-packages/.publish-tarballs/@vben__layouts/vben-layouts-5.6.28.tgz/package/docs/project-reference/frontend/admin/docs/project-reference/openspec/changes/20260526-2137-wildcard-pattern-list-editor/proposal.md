# Wildcard Pattern List Editor

## Motivation

Several admin forms need to maintain Java `List<String>` style pattern lists. Existing generic string-list controls allow entering values, but they do not help users validate `*` and `?` wildcard behavior before saving, nor do they expose a clear AND/OR evaluation mode for local tests.

## Scope

- Add a reusable frontend component for editing wildcard pattern lists.
- Support free input, searchable/selectable candidate patterns, immediate match testing, AND/OR test mode, and JSON array output.
- Reuse and extend the existing frontend pattern matching utility so `?` works as a single-character wildcard alongside `*`.
- Add focused unit tests for wildcard semantics, normalization, matching mode, and JSON output.

## Out Of Scope

- No backend API changes.
- No automatic wiring into every existing CRUD field in this change.
- No new third-party dependencies.
