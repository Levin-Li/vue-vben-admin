# Add Import Export Template Entity

## Why

The platform needs a persisted model for import and export templates that can
be scoped to tenants, organizations, or personal ownership, while also allowing
templates to be shared across tenants or organizations.

## What Changes

- Add an `ImportExportTemplate` entity for reusable import/export templates.
- Model the entity as a tenant, organization, personal, and share-aware object
  by extending `TOPEntity`.
- Include the confirmed template fields: name, code, template type, target
  business type, file type, category, group name, template file resource ID,
  template file URL, JSON config, and the inherited base remark field.
- Generate the default CRUD service and controller from the new entity using
  `simple-dao-codegen`.
- Allow the shared CRUD export dialog to save the current export field
  selection/order/alias configuration as an export template.
- When saving a CRUD export template, allow choosing exactly one ownership
  scope: personal template, platform shared, tenant shared, or organization
  shared. The chosen scope controls the submitted tenant, organization, owner,
  tenant-shared, and organization-shared values.
- Allow the shared CRUD export dialog to select a saved export template from a
  dropdown and apply its saved export field configuration.

## Impact

- Adds a backend entity and generated CRUD surface for import/export templates.
- Adds CRUD export-dialog template selection and saving in the admin frontend.
- Does not add custom backend business service logic in this change.
- Does not introduce dynamic script or expression fields.
