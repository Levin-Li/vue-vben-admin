# Remove BankBranch

## Background

`BankBranch` is no longer needed as a managed entity.

## Scope

- Remove the `BankBranch` entity.
- Remove generated default BankBranch service, request, info, mapper, implementation, and controller code.
- Remove BankBranch business service/controller extensions that depend on the entity and generated APIs.
- Regenerate code after the entity removal and verify the remaining modules compile.

## Acceptance Criteria

- No Java source references remain for the removed `BankBranch` entity type, `E_BankBranch`, `BankBranchService`, or `BizBankBranchService`.
- Existing plain `bankBranchCode` string fields on other entities may remain when they do not depend on the removed entity type.
- Entity module compiles after removal.
- `simple-dao-codegen:gen-code` runs successfully after removal.
- Relevant Maven compile verification is run and reported.
