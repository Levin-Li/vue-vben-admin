# Configurable sidebar navigation colors

## Summary

Expose the sidebar navigation menu background color in the preference drawer's
Appearance theme section.

## Scope

- Keep the existing semi-dark sidebar background-color setting.
- Add a persistent setting for the sidebar navigation's background color only.
- Place the navigation color controls beside the existing semi-dark sidebar and
  header controls, using the existing color-editor experience.
- Label the three color controls in Chinese as “侧边栏背景色”、“导航菜单背景色”
  and “顶栏背景色”.
- Display each semi-dark color control's “自定义” switch before its color
  preview in the preference drawer.
- Add a dedicated custom switch for the navigation-menu background color; when
  it is off, disable its color picker and use the configured sidebar background
  color as the menu background.
- Place the navigation-menu color row directly below the sidebar background
  color row.
- Make the sidebar collapse and fixed-button backgrounds use the same effective
  navigation-menu background color.
- Apply the effective navigation-menu colors to collapsed-sidebar popup menus.
- Apply the same disabled color-picker behavior to the sidebar and header
  background controls while their respective custom switches are off.
- In light global mode, reuse the standard light-sidebar active-menu color
  treatment when a custom sidebar background is enabled.
- Derive the hover color for custom navigation backgrounds by applying the
  original menu hover enhancement to the configured navigation color.
- Ensure the enhanced hover color is applied to the full menu-item background,
  not only its text/icon color.
- Apply the same enhanced hover background to submenu/directory menu items.
- Apply the configured values to dark sidebar menus and mixed-menu sidebars in
  real time without changing light sidebar defaults.
- When the application uses the light theme with a semi-dark sidebar, render
  the active sidebar menu item with the configured primary color.

## Acceptance

- The Appearance > Theme section includes a navigation-menu color entry in the
  highlighted configuration area.
- The three color-control labels use the requested concise Chinese names.
- Semi-dark sidebar and header rows display the custom switch before the color
  preview.
- The navigation-menu color picker is disabled until its custom switch is
  enabled.
- The navigation-menu color row appears directly below the sidebar background
  color row.
- When its custom switch is disabled, the visible navigation menu background
  follows the configured sidebar background color.
- The sidebar collapse and fixed-button backgrounds match the navigation-menu
  background color.
- A collapsed-sidebar popup menu uses the same navigation-menu background and
  hover colors.
- Sidebar and header color pickers are disabled while their matching custom
  switches are off.
- In light global mode, customized sidebar menus use the standard light
  active-menu color rather than a solid primary fill.
- Hovering a customized navigation menu item uses an enhanced shade of the
  configured navigation background.
- The enhanced shade is visibly painted behind the hovered menu item.
- Hovering a submenu/directory entry uses the same enhanced background shade.
- The configured sidebar navigation background updates the visible menu
  immediately and survives preference persistence.
- Reset restores the documented default colors.
- In light mode, an active menu item's background uses the theme primary color;
  global dark mode retains its existing active-menu styling.
