# Client Side CRUD Import

## Why

CRUD pages need a lightweight import capability that reuses existing generated backend APIs instead of adding import-specific backend endpoints. The feature should let operators parse files in the browser, preview and map columns, save reusable import templates, and batch-submit records through the existing generated `batchCreate` operation.

## What Changes

- Add a framework-level CRUD import tool button when the current API service exposes an enabled `batchCreate` operation.
- Parse Excel/CSV files on the client side and provide field mapping, basic data conversion, and preview before import.
- Reuse `ImportExportTemplate` for import templates with `Import` and `ImportAndExport` types.
- Save import templates with the same ownership/scope flow used by export templates; default template name uses the current controller `@Tag.name`/page title as prefix.
- Add template deletion for both import and export template selectors, shown only when permission and ownership rules allow deletion.
- Start import in a separate console-style modal that appends batch logs, calls `batchCreate` in batches of 2000, and reports final success/failure counts.
- Do not add backend import, preview, progress, or error-file endpoints.
- Keep Demo `batchCreate` generated and available as the import test target.

## Impact

- Affects the shared CRUD page component and template utilities in the admin framework frontend package.
- Reuses existing business API services and ImportExportTemplate service.
- Demo backend business controller remains the smoke-test resource for generated batch create.
