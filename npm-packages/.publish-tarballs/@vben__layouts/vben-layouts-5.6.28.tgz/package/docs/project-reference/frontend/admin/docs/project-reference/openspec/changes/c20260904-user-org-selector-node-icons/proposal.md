## Why

组织与用户选择器当前只显示文字，层级展开后不易快速区分用户与不同组织类型。需要用稳定图标增强识别，同时允许少数紧凑场景关闭图标。

## What Changes

- 默认在节点文字前展示图标。
- 用户节点使用固定用户图标；组织节点按后端 `Org.Type` 映射公司、分公司、部门、团队、小组、临时组织和外部主体图标。
- 增加默认开启的 `showNodeIcons` 开关，关闭后保留原有纯文字展示。

## Capabilities

### New Capabilities

- `user-org-selector-node-icons`: 组织与用户选择器的节点类型图标及显示开关。

### Modified Capabilities

- 无。

## Impact

- 影响 `@levin/admin-framework` 的 `UserOrgSelector` 公共组件、类型映射工具和单元测试。
- 图标来源仅使用已加载节点的 `kind` 与后端 `Org.Type` 值，不改变加载、选择、权限或提交语义。
