# Default Init Menu Uses Local Page

## Why

Default initialized menus should route to locally registered frontend pages instead of AMIS JSON pages. The existing controller-derived menus already use `Menu.PageType.LocalPage`, while root/default menu entries still use `AmisPage`.

## What Changes

- Change default root menu initialization from `AmisPage` to `LocalPage`.
- Change plugin root menu initialization from `AmisPage` to `LocalPage`.
- Keep SimplePage initialization data unchanged because the request only changes menu type.

## Impact

- Affects newly initialized default menu records.
- Existing persisted menu rows are not migrated by this change.
