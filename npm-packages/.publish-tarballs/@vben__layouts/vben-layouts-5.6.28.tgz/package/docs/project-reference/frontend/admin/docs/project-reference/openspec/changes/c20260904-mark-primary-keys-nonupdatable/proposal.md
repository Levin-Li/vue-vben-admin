## Why

实体主键是记录身份，不应在更新路径中被修改。当前主键字段的 JPA 列注解不一致，无法统一表达这一不可更新约束。

## What Changes

- 为所有实体主键字段的 `@Column` 注解补充 `updatable = false`。
- 按实体变更流程重新生成受影响的默认服务、请求和控制器产物。

## Capabilities

### New Capabilities

- `primary-key-nonupdatable-mapping`: 所有实体主键的统一不可更新列映射。

### Modified Capabilities

- 无。

## Impact

- 影响实体 JPA 映射及由 `simple-dao-codegen` 生成的默认产物。
- 不修改主键生成策略、数据库主键值或业务接口路径。
