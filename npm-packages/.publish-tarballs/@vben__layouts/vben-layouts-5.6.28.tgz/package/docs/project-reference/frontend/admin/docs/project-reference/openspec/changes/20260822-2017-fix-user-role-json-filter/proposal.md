## Why

租户管理员刷新用户列表时，业务层为隐藏超管和 SaaS 管理员角色，对 JSON 类型的 `User.roleList` 使用了普通 `notContains`。该操作被转换为 JPQL `NOT LIKE`，Hibernate 无法对 JSON 集合字段执行该条件，导致列表接口失败。

## What Changes

- 将用户角色过滤中的两处普通 `notContains` 改为公共 DAO 组件提供的 JSON 同语义条件。
- 保持现有租户管理员、超级管理员和 SaaS 管理员的数据可见范围不变。
- 为该权限过滤补充回归测试，覆盖生成的 JSON 查询表达式而非普通 `LIKE`。

## Impact

- `services-impl` 的用户业务查询服务及其测试。
- 不修改实体、生成请求对象、前端接口或页面配置。
