## Context

`UserOrgSelector` 的源代码、类型、综合使用手册和组件测试已经存在；综合手册中的组件章节适合查阅，但组件使用者不能从包 README 快速定位，也无法独立阅读与版本一致的完整参数契约。`@levin/admin-framework` 的发布配置已将包根 `docs`、`src` 和 `dist` 纳入 tarball，因此专用文档可以作为无需编译的静态发布资产。

## Goals / Non-Goals

**Goals:**

- 为组件使用者提供稳定、可发现、随 npm 包发布的专用 Markdown 文档。
- 将参数、事件、默认数据源、选择和过滤语义、典型场景及已知边界与当前源代码保持一致。
- 让 README 和综合手册均能导航到该文档。
- 通过打包 dry-run 验证文档真实进入 tarball。

**Non-Goals:**

- 不改变 `UserOrgSelector` 的任何运行时行为、接口或类型。
- 不把组件提升为全局当前组织状态，也不新增跨页面状态、事件或请求拦截机制。
- 不在 `dist` 中手工维护第二份文档。

## Decisions

### 以包根 `docs/components/user-org-selector.md` 作为唯一专用文档

该路径由 `package.json` 的 `files` 直接发布，且不依赖构建工具是否复制 Markdown；使用者可在安装后的 `node_modules/@levin/admin-framework/docs/components/user-org-selector.md` 查看。README 使用相对链接作为主入口，综合手册使用相对链接作为组件章节的延伸入口。

不将完整文档仅放在 `src/framework-commons/docs`：虽然源码会随包分发，且构建当前会生成对应 `dist` 资料，但这会使阅读路径依赖源码或构建布局，发现性较弱。

### 文档以组件真实契约为唯一事实来源

参数、默认值、事件和加载语义均从 `user-org-selector.vue`、`user-org-selector-types.ts` 以及辅助函数读取；专用文档说明 `onlyShowTypeMatchNode` 对不匹配祖先的压缩行为，并明确其与懒加载组合时可能不可达后代的边界。

不把仅存在于历史文档的描述当作 API 事实，避免发布文档与编译后组件脱节。

### 保持文档职责分层

专用文档负责组件 API 与接入示例；综合手册保留目录级概览并链接过去；README 只提供高可见入口和安装后路径。这样减少同一参数表的多处复制。

## Risks / Trade-offs

- [组件以后新增参数而文档未同步] → 文档明确源码位置和验证要求，并将专用文档作为组件改动的同步维护点。
- [根 `docs` 被发布配置排除] → 使用 `npm pack --dry-run --json` 按具体文件路径验证。
- [用户把普通选择器误当成全局上下文] → 在文档开头明确职责边界，并给出调用方需要另行维护状态的说明。
