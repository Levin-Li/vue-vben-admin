# 测试 JSON 操作日志追加行为

## 背景

`JsonActionLogAppendReq` 用于向实体的 `actionLog` JSON 字段追加 `ActionLog` 列表。目前该类在多处业务服务中使用，需要用自动化测试验证它对 JSON 操作日志字段的追加语义，避免存储或追加结果异常。

## 目标

- 增加覆盖 `JsonActionLogAppendReq` 的回归测试。
- 本地运行相关 Maven 测试，确认当前行为是否通过测试暴露问题。
- 在公共组件修复 JSON 数组追加后，确保 `ActionLog` 本身可被 Hibernate JSON 映射正常回读。

## 非目标

- 本次不修改生成目录下的默认服务或默认控制器。
- 本次不引入新的第三方依赖。
