# Fix Required Permission Editor UI

## Why

The simple page row action area currently shows the "所需权限" action with too much spacing between its icon and text. In shared required-permission modals such as simple page and role management, selecting a child resource permission does not put its parent resource/type checkbox into an indeterminate state.

## What Changes

- Tighten the icon/text spacing for simple page managed row actions.
- Fix the shared resource permission tree editor so parent checkboxes show half-selected state when only some child actions are selected.
- Improve the shared permission tree menu view by keeping menu nodes vertical and rendering action permissions as simple checkbox items with an "操作" label.
- Add visible tree guide lines to the system menu permission view so parent-child hierarchy is easier to scan.
- Allow the system menu permission tree to expand/collapse, with the default view opened to the second menu level.

## Impact

- Affects the simple page "所需权限" row action and all pages using the shared resource permission tree editor, including role management.
- No API contract changes.
