# 删除范围

以下文件均核实具有生成器标记，业务包装类仅保留生成模板职责。按用户明确删除授权移除，保留其他工作区改动。

- `admin-api/src/main/java/com/levin/oak/base/controller/BizTenantAppController.java`
- `admin-api/src/main/java/com/levin/oak/base/controller/base/tenantapp/TenantAppController.java`
- `client-api/src/main/java/com/levin/oak/base/controller/BizTenantAppController.java`
- `services/src/main/java/com/levin/oak/base/biz/BizTenantAppMapper.java`
- `services/src/main/java/com/levin/oak/base/biz/BizTenantAppService.java`
- `services/src/main/java/com/levin/oak/base/biz/bo/tenantapp/StatTenantAppReq.java`
- `services/src/main/java/com/levin/oak/base/services/tenantapp/TenantAppMapper.java`
- `services/src/main/java/com/levin/oak/base/services/tenantapp/TenantAppService.java`
- `services/src/main/java/com/levin/oak/base/services/tenantapp/info/TenantAppInfo.java`
- `services/src/main/java/com/levin/oak/base/services/tenantapp/req/CreateTenantAppReq.java`
- `services/src/main/java/com/levin/oak/base/services/tenantapp/req/DeleteTenantAppReq.java`
- `services/src/main/java/com/levin/oak/base/services/tenantapp/req/QueryTenantAppReq.java`
- `services/src/main/java/com/levin/oak/base/services/tenantapp/req/SimpleQueryTenantAppReq.java`
- `services/src/main/java/com/levin/oak/base/services/tenantapp/req/SimpleUpdateTenantAppReq.java`
- `services/src/main/java/com/levin/oak/base/services/tenantapp/req/TenantAppIdReq.java`
- `services/src/main/java/com/levin/oak/base/services/tenantapp/req/UpdateTenantAppReq.java`
- `services-impl/src/main/java/com/levin/oak/base/biz/BizTenantAppServiceImpl.java`
- `services-impl/src/main/java/com/levin/oak/base/services/tenantapp/TenantAppServiceImpl.java`

## 前端移除（用户追加）

移除 TenantApp 页面、接口封装、模块注册和加载器、选项加载器、文档目录项及对应 E2E 适配器和布局测试名单。保持其他功能，不编译、不启动服务。
