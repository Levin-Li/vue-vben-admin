## Decisions

- `certificationStatus` 仍是当前认证状态的唯一持久化快照；它用于状态机校验和当前页面展示。
- `lastStatusTime` 与 `lastStatusDesc` 是通用当前结果摘要，而不是按提交、通过、撤销等事件分拆的历史字段。每次认证状态迁移都更新这两个字段；没有人工说明时，结果说明使用实际认证事件，确保摘要可读且不为空。
- 每次认证事件继续以 `JsonActionLogAppendReq` 增量追加到 `certificationLog`，日志中的 `occurTime`、`operator`、`beforeStatus`、`afterStatus` 和 `remark` 是认证历史的唯一追溯来源。审核拒绝意见写入日志 `remark`，同时作为最后一次结果摘要供当前状态快速查看。
- 不物理删除现有数据库列，避免无授权的破坏性数据迁移；实体与生成模型移除后，应用不再读写这些列。
- 服务和请求/信息对象不手工修改。实体变更后先编译 entities，再运行 simple-dao-codegen 刷新生成目录。
