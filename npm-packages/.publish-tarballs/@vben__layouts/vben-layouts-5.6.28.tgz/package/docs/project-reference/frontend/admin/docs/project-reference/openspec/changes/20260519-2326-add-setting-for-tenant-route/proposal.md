# Add SettingForTenant Route

## Why

The SettingForTenant page exists as a local page and is present in generated CRUD resources, but the explicit oak-base module route table does not register it. Consumers that use the module route table directly, including crud-disabled module configuration, cannot reach the tenant setting page through module routes.

## What Changes

- Add an explicit oak-base module route for `/clob/V1/SettingForTenant` pointing to `views/setting-for-tenant/index.vue`.
- Add focused coverage that the explicit route table contains SettingForTenant and that `createOakBaseAdminModule({ crud: false })` exposes it.

## Impact

- Affects oak-base admin module route registration only.
- No API contract changes.
