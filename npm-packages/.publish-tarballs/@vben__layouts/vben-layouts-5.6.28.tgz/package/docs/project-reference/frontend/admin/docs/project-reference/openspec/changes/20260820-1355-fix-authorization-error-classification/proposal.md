# 修正权限拒绝提示

## Why

已登录用户访问无权限接口时，后端虽然抛出 `AuthorizationException`，但全局异常处理将其错误编码为 `AuthenticationError`。前端据此显示“登录认证过期”，掩盖真实的权限不足原因并误导用户重新登录。

## What Changes

- 将 `AuthorizationException` 统一响应为 `AuthorizationError` 与 HTTP 403。
- 保持未登录、令牌失效等 `AuthenticationError` 的现有登录失效处理不变。
- 前端错误分类必须以后端 `ServiceResp.ErrorType` 枚举及其错误码区间为准，不得在页面或请求层散写 `AuthorizationError`、`25000` 等分类常量。授权拒绝响应存在 `msg` 时，前端必须显示该内容；`msg` 缺失时统一显示“未授权的请求”。HTTP 403 作为未携带可解析响应体时的传输层兜底。
- 补充回归测试，确保前端按授权错误显示权限提示而非登录过期提示，并覆盖授权提示文案优先级。

## Impact

- 后端全局 Web 异常响应。
- 管理前端共享 ServiceResp 错误提示。
