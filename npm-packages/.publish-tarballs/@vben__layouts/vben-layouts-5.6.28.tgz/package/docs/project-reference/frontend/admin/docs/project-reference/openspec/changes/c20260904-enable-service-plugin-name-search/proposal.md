## Why

服务插件设置页用自定义下拉实现插件与供应商级联，但该下拉没有按显示名称筛选，用户只能凭插件 ID 搜索，难以定位目标插件。

## What Changes

- 为服务插件设置页的“服务插件”查询和表单下拉补充本地名称与 ID 搜索。
- 保持插件→供应商联动、禁用供应商过滤和已有值重置逻辑不变。

## Capabilities

### New Capabilities

- `service-plugin-setting-name-search`: 服务插件设置页按插件显示名称或 ID 搜索下拉选项。

### Modified Capabilities

- 无。

## Impact

- 仅影响 `oak-base-admin` 的服务插件设置页面；不修改后端查询接口、插件数据加载量或租户插件设置页。
