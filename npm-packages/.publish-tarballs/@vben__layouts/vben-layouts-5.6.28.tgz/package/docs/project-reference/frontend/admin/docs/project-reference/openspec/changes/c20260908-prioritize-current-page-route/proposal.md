## Why

页面展示设置在从菜单动态路由进入页面时，设置编码会优先采用来源页面路径，而不是地址栏中的当前路由。不同菜单入口因此可能错误共用展示设置，且设置面板显示的编码与用户正在访问的 URL 不一致。

## What Changes

- 页面展示设置编码优先使用当前 `route.path`。
- 页面展示设置编码只使用当前 `route.path`。
- 当前路由为空时，不提供页面展示设置入口，也不读取或保存设置。
- 移除 `sourcePagePath`、`uiSettingCode`、`apiBase` 及固定字符串作为展示设置编码兜底。
- 更新单元测试和页面展示设置专题中的编码优先级说明。

## Capabilities

### New Capabilities

- `current-route-page-display-code`: 当前页面路由作为展示设置编码的首要来源。

### Modified Capabilities

无。

## Impact

影响管理前端公共 CRUD 的页面展示设置读取、保存和缓存键。已有以来源页面路径、页面手工编码或 API 路径保存的记录不会自动迁移或兼容；它们需要在当前页面路由下重新保存后才会匹配。没有当前路由的页面不再共享或创建展示设置记录。
