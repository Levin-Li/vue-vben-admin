# 增加 Forward Email 邮件中转

## Why

租户需要用自定义域名接收邮件，并把一个邮件别名同时转发到多个外部邮箱和 HTTPS Webhook。

## What Changes

- 新增一个仅支持 Forward Email 的入站邮件中转插件。
- 一个邮件别名可配置多个外部邮箱和/或 HTTPS Webhook 目标，每个目标可独立启停。
- 租户提供 Forward Email Token 时优先使用；未提供时使用平台公共配置。
- 系统通过 Forward Email API 同步域名和 alias；DNS 记录完全由域名管理员在 DNS 托管商中手动配置。
- 管理页只提供路由维护、同步状态和 Forward Email DNS 验证记录查看。

## Out of Scope

- Cloudflare Email Routing、Worker、KV、自动 DNS 写入。
- 系统二次解析、保存或再投递邮件内容。
- 原始 EML 或附件内容投递策略；Webhook payload 与重试完全遵循 Forward Email 原生行为。
