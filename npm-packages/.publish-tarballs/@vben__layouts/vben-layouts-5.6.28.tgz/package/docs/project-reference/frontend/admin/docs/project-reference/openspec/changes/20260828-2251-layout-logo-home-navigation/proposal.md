# Layout logo navigates home

## Why

The authenticated admin layout displays the tenant-site logo and name as the
primary brand affordance, but clicking it has no navigation effect. Users
expect that familiar entry point to return them to the application home page.

## What Changes

- Make the authenticated layout logo area navigate to the current application
  home route when clicked.
- Render the brand name from the current tenant site's display title, falling
  back to the tenant site's name when no display title is configured, then to
  the existing application preference.
- Reuse the tenant-site brand state loaded on the login page; the authenticated
  layout must not issue a duplicate request after that state is available.
- Treat footer outer margin, corner radius, and border width as optional
  overrides: leave all twelve fields blank by default and use the existing
  frontend defaults until an operator enters a value.
- Close the login-success notification automatically after three seconds.
- Add a regression test for the click-to-home behavior.

## Impact

- Frontend only: the shared authenticated admin layout, tenant-site brand
  mapping, and shared layout preferences.
