## Why

公共 CRUD 即使没有任何可执行的行操作也会保留“操作”列，造成空白表格列和无意义的视觉干扰。需要让列展示与当前页面真正可用的操作保持一致。

## What Changes

- 公共 CRUD 根据当前实际可渲染的行操作自动显示或隐藏“操作”列。
- 没有行操作时移除操作列表头和单元格；存在任一可用行操作时保持现有操作列行为。
- 保持权限、行级可见条件、内置编辑/删除动作和页面自定义行操作的既有判断规则。

## Capabilities

### New Capabilities

- `crud-operation-column-visibility`: 公共 CRUD 操作列按实际行操作可用性展示。

### Modified Capabilities

- 无。

## Impact

- 影响 `@levin/admin-framework` 的公共 CRUD 表格列构建与相关单元测试。
- 不改变后端接口、控制器权限元数据或业务页面的操作配置。
