## ADDED Requirements

### Requirement: 集合 JSON 查询条件独立组合

系统 SHALL 为默认生成请求对象中的集合 JSON 条件生成 `@ForceSplitCondition`，使每个条件可独立参与查询表达式组合。

#### Scenario: 多个集合条件查询

- **WHEN** 请求对象包含多个使用 JSON 路径的集合查询字段
- **THEN** 每个字段 SHALL 带有 `@ForceSplitCondition`

### Requirement: 可复制字段安全注解同步

系统 SHALL 将实体字段上标记为复制到生成代码的安全注解同步到对应默认信息对象。

#### Scenario: 服务插件配置值展示

- **WHEN** 服务插件配置值可能包含敏感凭据
- **THEN** 生成的信息对象 SHALL 保留该字段的数据脱敏授权约束
