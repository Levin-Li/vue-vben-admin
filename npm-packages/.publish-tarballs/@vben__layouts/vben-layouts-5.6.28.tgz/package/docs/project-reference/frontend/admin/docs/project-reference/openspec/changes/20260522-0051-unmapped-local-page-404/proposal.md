# Unmapped Local Page Shows 404

## Why

Backend menu records can point to routes that do not have a registered frontend page. The current fallback sends some of those routes to the generic controller iframe page, and some paths then fall back to `/admin`, which renders a nested admin home page inside the content area.

## What Changes

- Render the standard 404 page for menu routes when no registered frontend route mapping exists.
- Keep explicit local route mappings and special action types unchanged.
- Add route conversion coverage for unmapped backend menu paths so they do not use the controller CRUD iframe fallback or carry backend iframe fallback metadata.
- Remove the generic `/clob/V1/:resource` iframe alias so unmatched paths reach the framework 404 route.

## Impact

- Affects backend menu items without matching frontend page registrations.
- Prevents nested admin home pages for unsupported menu routes.
