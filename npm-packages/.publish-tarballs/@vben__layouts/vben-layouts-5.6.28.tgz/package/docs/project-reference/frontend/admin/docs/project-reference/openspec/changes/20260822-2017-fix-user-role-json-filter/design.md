## Decision

只替换 `BizUserServiceImpl.query(...)` 中作用于 `User.roleList` 的两个条件操作。原有条件组、`roleList IS NULL` 兼容分支及角色可见性判定保持不变；将普通字符串 `notContains` 改为公共 DAO 组件的 JSON 对应方法，并保留数组路径参数。

## Rationale

`User.roleList` 映射为 JSON `List<String>`。普通 `notContains` 的字符串 `LIKE` 语义不能用于该字段；公共组件的新 JSON 版本方法保留同样的“包含匹配取反”语义，并在 JSON 路径上执行。

## Non-Goals

- 不更改角色权限策略。
- 不改动其它已经使用 JSON 路径注解的生成查询对象。
- 不修改前端请求参数或列表组件。
