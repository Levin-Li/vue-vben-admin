## Why

升级 `simple-dao-codegen` 后，生成的 `SimpleQueryXxxReq` 不再包含实体完整查询字段。现有业务服务仍以它承载完整字段查询，导致重新生成后的 `services-impl` 无法编译。

## What Changes

- 保留业务服务对 `QueryXxxReq` 的实际对象使用，并在继承的链式 setter 使静态类型退化为 `SimpleQueryXxxReq` 时调用 `.cast()` 恢复完整查询类型。
- 不修改生成的请求对象，不增加手工字段或修改其泛型继承。
- 清除新版生成器在客户端默认控制器中写入、但项目不存在且未被使用的业务 BO 导入，使客户端 API 能编译。
- 编译生成输出所在的服务和 API 模块以验证生成器升级兼容性。

## Capabilities

### New Capabilities

- `biz-service-query-request-compatibility`: 业务服务与新版生成查询请求对象的类型兼容性。

### Modified Capabilities

无。

## Impact

- 影响 `services-impl` 中使用实体完整查询字段的业务服务实现，以及三个客户端默认控制器的无效导入。
- 不改变对外 API、实体模型和数据结构。
