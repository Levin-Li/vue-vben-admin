## ADDED Requirements

### Requirement: Organization-user and plain user management pages must be separate

The admin frontend MUST provide two distinct user-related pages: a compound organization tree + user list page named `组织与用户`, and a normal list-style page named `用户管理`.

#### Scenario: Open organization-user compound page

- **WHEN** a user opens `/clob/V1/OrgUser`
- **THEN** the page title/menu title must be `组织与用户`
- **AND** the page must show the organization tree beside the user list
- **AND** selecting an organization must filter the user list by that organization

#### Scenario: Open plain user management page

- **WHEN** a user opens `/clob/V1/User`
- **THEN** the page title/menu title must be `用户管理`
- **AND** the page must show the normal CRUD list-style user management page
- **AND** the page must not require selecting an organization tree node before showing the list

#### Scenario: Sync menu metadata

- **WHEN** frontend route metadata is uploaded to the backend menu system
- **THEN** the sync payload must contain both `/clob/V1/OrgUser` and `/clob/V1/User`
- **AND** `/clob/V1/OrgUser` must map to the organization-user compound page
- **AND** `/clob/V1/User` must map to the plain user management page
