## Why

当前管理后台虽然已经具备角色、用户等基础管理页面，但角色的数据权限分配与用户的数据权限分配仍缺少独立、可用、符合后端控制器驱动规则的前端页面。这导致组织范围与资源权限的维护只能依赖基础编辑表单字段或临时手工方式，无法满足后台日常授权管理的使用要求。

与此同时，项目规则明确要求前端页面、按钮和交互行为优先依据业务控制器、父类控制器与 RBAC 辅助接口提供的元数据与能力实现，而不是前端自行发明一套权限页面结构。因此，需要为管理后台补齐一套基于后端接口与数据模型的“数据权限分配”页面能力。

## What Changes

- 为角色列表增加“数据权限分配”行操作，并提供角色数据权限分配弹窗。
- 为用户列表增加“数据权限分配”行操作，并提供用户数据权限分配弹窗。
- 组织范围编辑基于 `authorizedOrgList` 获取授权组织树，维护 `orgScopeList`。
- 角色资源权限编辑改用新的统一权限树接口，接口直接返回纯树形结构；树中每个节点必须显式声明节点类型，并可选携带 `permissionExpr` 和 `remark`，页面基于树形勾选逻辑维护 `permissionList`。
- 组织范围支持模板化编辑与高级模式手填 `orgScopeExpression`。
- 抽取共享弹窗与共享编辑器，避免角色页和用户页重复实现。
- 将前端按钮权限匹配统一收口到 `admin-ui` 在线暴露的 `RbacPermissionMatchUtils.js`，不再使用简化字符串匹配替代。

## Capabilities

### New Capabilities

- `rbac-data-permission-assignment`: 管理后台必须支持在角色与用户列表中打开独立的数据权限分配弹窗，并依据后端 RBAC 接口维护组织范围和角色资源权限。

### Modified Capabilities

- `system-role-management`: 角色管理页面新增“数据权限分配”行操作。
- `system-user-management`: 用户管理页面新增“数据权限分配”行操作。

## Impact

- 影响前端目录主要为 `frontend/vue-vben-admin/apps/web-antd/src/views/system/` 与共享组件目录。
- 影响后端依赖方式主要为角色、用户详情更新接口，以及 `RbacController` 的组织树与新的统一权限树接口消费方式。
- 本次不调整后端实体结构，但需要新增统一权限树查询接口，替代角色资源权限分配页面对旧 `authorizedResList` 结构的直接依赖。
- 本次界面行为依赖以下后端驱动来源：
  - `BizRoleController` / `RoleController`
  - `BizUserController` / `UserController`
  - `RbacController.authorizedOrgList()`
  - `RbacController.authorizedPermissionTree()`

## 2026-09-05 补充：页面元数据与操作权限上报

- 所有可访问本地页面必须在前端路由映射中显式声明稳定 `name`、用户可见 `title` 和中文 `description`。
- 路由上报必须把这三项及页面操作列表同步到后端菜单配置；服务端保存后，在动态路由下发时原样提供给页面。
- 操作权限表达式使用 `模块ID:系统数据-页面操作:name:opName`，不使用菜单 ID、显示标题、路由或源码路径。
- 页面操作通过其实际调用 API 的权限元数据派生关联资源权限，上报后由后端保存、下发并参与按钮展示与授权判断。

## 2026-09-11 补充：DataScope 2.2 模型升级

- `service-support` 升级到 2.2.0-SNAPSHOT 后，User、Role 及同样实现 `RbacUserInfo` 的 Customer 的旧 `orgScopeList: List<SimpleOrgScope>` 直接替换为新的六个可空 JSON 集合：允许/拒绝租户、领域、组织范围；不保留运行时旧模型兼容。
- 空集合表示显式的空配置，`null` 表示继承角色；迁移旧 JSON 必须通过独立、可审计的迁移交付完成，应用运行路径不得自动转换历史数据。
- 数据权限分配弹窗将六个范围字段分别显示在六个 Tab 中。每个 Tab 单独保存，只提交该字段、目标 ID、乐观锁和字段级强制更新标识；资源权限维持既有的独立按钮和独立弹窗，不与数据权限混合。
- 修改任一允许或拒绝范围时，服务端必须逐项验证操作者对提交范围本身具有访问权；前端只做候选项收窄和交互提示，不能替代服务端验证。
- 新模型引入领域目录，平台领域作为 `RbacDomainInfo` 的实现，并由 RBAC 基础服务提供领域加载能力。
