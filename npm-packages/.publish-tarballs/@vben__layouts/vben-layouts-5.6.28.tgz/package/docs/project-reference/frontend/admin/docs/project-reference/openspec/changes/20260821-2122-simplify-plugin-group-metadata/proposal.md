## Why

服务插件接口中的历史分组名称仅服务于启动期兼容迁移，却要求每个插件声明额外元数据并使初始化逻辑复杂。当前只需要一个明确的分组名称。

## What Changes

- 移除 `SimpleServicePlugin.getLegacyGroupNames()` 及所有插件实现的覆盖。
- 删除依据历史分组名称回填或迁移插件类别、分组的启动逻辑。
- 保留 `getGroupName()` 作为插件唯一的分组元数据来源。

## Capabilities

### New Capabilities

- `simple-plugin-group-metadata`: 服务插件仅通过当前分组名称声明分组。

### Modified Capabilities

- 无。

## Impact

- 后端服务插件接口、插件初始化同步逻辑及相关测试。
- 已由管理员维护的插件分组保持原值；本次不执行自动迁移或回填。
