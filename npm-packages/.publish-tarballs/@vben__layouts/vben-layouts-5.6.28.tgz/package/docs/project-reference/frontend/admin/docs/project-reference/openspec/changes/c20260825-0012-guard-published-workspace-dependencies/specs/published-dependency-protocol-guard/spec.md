## ADDED Requirements

### Requirement: 发布 tarball 不得保留工作区或目录协议依赖

公共包发布流程 MUST 检查本地 tarball 与私服精确版本 tarball 中的 `package/package.json`。`dependencies`、`optionalDependencies`、`peerDependencies` 与 `devDependencies` 中的依赖版本 MUST NOT 使用 `workspace:` 或 `catalog:` 协议。

#### Scenario: 本地 tarball 协议残留

- **WHEN** 待发布包的本地 tarball 中存在 `workspace:*` 或 `catalog:` 依赖
- **THEN** 发布流程失败，且不得上传该 tarball

#### Scenario: 私服 tarball 协议残留

- **WHEN** 私服中反查的精确版本 tarball 中存在 `workspace:*` 或 `catalog:` 依赖
- **THEN** 发布验证失败，并报告包名、依赖区段和依赖名称

### Requirement: 发布物使用消费者可安装的依赖版本

公共包发布 tarball MUST 使用能将源码工作区依赖转换为具体版本的打包流程；上传前 MUST 保持源码工作区文件不被为发布而改写。

#### Scenario: 源码使用工作区依赖

- **WHEN** 公共包源码的依赖声明使用 `workspace:*`
- **THEN** 打包后 tarball 使用对应公共包的具体版本，而源码声明保持不变
