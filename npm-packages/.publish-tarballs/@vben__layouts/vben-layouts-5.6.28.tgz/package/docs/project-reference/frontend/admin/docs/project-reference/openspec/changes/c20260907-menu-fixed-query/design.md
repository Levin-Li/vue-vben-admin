## Context
菜单 params 已存在，但前端没有将其用于固定列表过滤，同一路由名称会冲突。
## Goals / Non-Goals
实现配置、导航和通用 CRUD 请求闭环；不增加后端强制过滤，不把固定条件注入写请求。
## Decisions
复用 params 存 JSON 对象，通过菜单元数据提供固定条件。为带参数菜单建立独立入口路径并复用目标组件，路由 name 按最终 path 替换斜杠生成，避免改动整个导航框架。页面设置仍引用原始页面路径。查询字段按显式提交参数键过滤，列表最终请求合并固定条件，固定条件优先。导出沿用同一查询构造入口。
## Risks / Trade-offs
固定条件不是安全边界，用户已明确只要求前端提交时固定。格式错误需明确报错，不可静默忽略形成无过滤请求。条件支持 JSON 标量及标量数组，禁止原型污染键。不同入口的加载和查询状态必须隔离。新增表单只对与固定条件完全同名的实际表单字段预填并禁用；编辑表单隐藏同名字段，并将其排除出更新载荷和强制更新字段。不根据 `containsXxx`、范围键或级联展开键猜测写入字段，详情和删除保持原行为。

## 查询表单配置入口
管理员选择已有页面后，复用页面静态 CRUD 查询字段及公共控件配置固定条件，逐字段显式勾选是否固定，支持 false 和 0。日期范围按原页面提交规则转换。目标页面无法提供公共 CRUD 查询配置且未配置 Schema 时，“表单查询条件”入口禁用，不推测字段。无论目标页面是否 CRUD，“扩展查询条件”始终使用逐行新增/删除的键、类型和值编辑器，且不加载目标页面查询配置。JSON 仅作底层存储。

## JSON 字段迁移
用户已将 Menu.params 从 String 改为 JSONObject 并使用 JSON 映射；生成器同步请求/信息对象，前后端只使用对象契约，不增加旧字符串运行时兼容。迁移前必须备份 base_menu，显式转换 params 到 jsonb，空字符串转空对象，非法 JSON 或非对象值阻断并人工处理。迁移默认由用户执行，本任务不执行；恢复从备份或显式转回文本，回滚应用版本必须与列类型同步。

## 编辑器优先级
paramsEditor 非空优先 Schema(class:/url:/内联)，失败降级 JSON；为空优先页面查询表单，缺失则 JSON。复用现有Schema解析加载与JSON组件，不静默丢弃未知参数。新增 params_editor text 列由显式迁移提供。

## 外部菜单接口边界
私服最新 service-support 快照和正式版本的 MenuItem.getParams 均为 String，不存在可直接升级版本。本项目持久化 Menu 改为只实现已需要的 MultiTenantPublicObject/AuthorizedObject，并继续继承 AbstractTreeObject；不再宣称实现旧 MenuItem。生成 MenuInfo 同步移除该接口。保留 MenuItem.ActionType/OpButton 类型，不复制或遮蔽外部类。外部插件 getMenuList 仍使用 RbacUtils 生成的 MenuItem，RBAC REST 返回具体 MenuInfo。此为JSONObject契约变更的一部分，下游不得再将持久化菜单强制转换为外部MenuItem。AMIS查询参数从JSON对象显式编码生成，现有字段和树结构由编译与RBAC/菜单同步测试确认。
