## Why
多个菜单需要复用同一个页面，以固定查询条件区分业务入口，用户不能通过查询表单修改这些条件。

## What Changes
- 复用菜单 params 保存 JSON 固定查询条件，配置时验证对象格式。
- 同页面不同菜单入口分别导航、选中、保留页签状态。
- 隐藏固定条件对应的查询字段，查询、分页、刷新和导出最终覆盖同名参数；重置不清除固定条件。

## Capabilities
### New Capabilities
- `menu-fixed-query`: 菜单固定查询条件与复用页面入口。
### Modified Capabilities
无。

## Impact
影响 admin-framework 菜单路由与公共 CRUD，oak-base-admin 菜单表单。Menu.params 调整为 JSONObject JSON 列并重新生成默认服务、控制器；不新增依赖，不改后端权限过滤，提供显式数据库字段迁移，不自动执行。仅列表请求附加条件，不影响新增、编辑及删除请求。
