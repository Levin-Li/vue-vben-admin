# File Resource Preview View Design

## Page Structure

The file resource page remains the single menu entry for file resources. Its menu title is `文件资源库`. Inside the page, a segmented view switch controls the visible content:

- `列表`: existing CRUD table and maintenance workflow.
- `资源预览`: preview-oriented card grid for mixed file resources.

The preview view uses the same `fileResService.list` endpoint as the table view. Query state can be kept local to the preview view, with pagination and type filtering independent from the table.

## Preview Data

Each card is based on one `FileRes` record. Display fields:

- name
- id
- type
- mimeType
- category
- tagList
- publishable
- deleted
- enable
- createTime

Preview URL resolution:

1. Use `coverUrl` for visual cover when available.
2. Use the first usable `paths` entry.
3. Fall back to a type-specific placeholder.

Resource type comes from `FileRes.type`. `mimeType` is used as a secondary hint for rendering details such as PDF preview.

## Default Image Samples

Module data initialization should seed several default image `FileRes` records for the preview view. The records must be idempotent: each sample uses a stable `bizObjId`, and initialization skips creation when a matching image resource already exists.

The default samples use inline SVG image data URLs so startup does not depend on external network access or additional static-resource deployment. They are public, enabled, editable, and tagged as initialized image samples.

## Preview Rendering

The card grid uses stable card dimensions and semantic theme classes or CSS variables. Cards must not resize when an image loads or fails.

Preview modal behavior:

- Image: large image preview with open, copy, download, and metadata actions.
- Video: HTML video player with controls.
- Audio: HTML audio player with controls.
- Document/PDF: iframe or embed preview when the resolved URL is likely a PDF.
- Zip/Other/unsupported document: generic file preview with open and download actions.

## Batch Archive Download

The preview view supports selection mode:

- Each card has a checkbox.
- The toolbar shows selected count, clear selection, select current page, and archive download.
- Archive download only includes selected resources.

Archive creation runs entirely in the browser:

1. Expand selected resources into file entries from `paths`; include `coverUrl` only if it is the only usable URL.
2. Fetch each URL as a `Blob`.
3. Add successful blobs to the zip under a type/name/id based directory.
4. Record both successful and failed file entries in `manifest.json`.
5. Download the zip through the existing blob download utility.

Failure handling:

- A failed file fetch is recorded in `manifest.json`.
- Other files continue downloading.
- If every file fails, the user receives an error and no archive is downloaded.

Limits:

- The first implementation should cap selected resources and expanded file count to avoid browser memory issues.
- The preview view should show progress while packaging.
- Unsupported CORS or missing URLs are treated as per-file failures.

## Dependency Decision

The repository currently has blob download helpers but no zip packaging library. Because project rules avoid new dependencies unless explicitly requested, the first implementation should use a small local ZIP Store writer. The generated archive is a standard `.zip` file without compression. If compressed archives become necessary later, a dedicated zip library can be introduced through a separate dependency decision.
