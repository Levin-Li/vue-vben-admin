## Why

验证码登录页包含冗余说明，并允许在未输入登录账号时触发获取验证码请求。精简提示并在客户端阻止无账号请求，可使界面更清晰且避免无效调用。

## What Changes

- 将验证码登录提示缩短为“输入手机号或邮箱后获取验证码”。
- 登录账号为空白时禁用“获取验证码”按钮。
- 隐藏“当前使用短信/邮箱验证码”说明文字。

## Capabilities

### New Capabilities

- `contact-login-verify-ui`: 验证码登录页的精简提示和账号前置按钮状态。

### Modified Capabilities

- 无。

## Impact

- 仅影响 `@levin/admin-framework` 的登录页前端展示与本地按钮可用状态。
- 不修改登录接口、验证码类型解析、发送请求参数或服务端配置。
