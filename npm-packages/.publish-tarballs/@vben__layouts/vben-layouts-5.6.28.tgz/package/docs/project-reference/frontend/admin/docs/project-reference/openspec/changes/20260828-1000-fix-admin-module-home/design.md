## Decision

使用 Bootstrap 偏好配置指定应用根路径的默认首页：`/` 直接进入后台管理模块根路径 `/clob/V1/index`。该模块根路由直接注册概览组件。

## Rationale

`/clob/V1/index` 是后台管理模块的父菜单路径，必须同时成为模块首页的实际页面路由。通过 `defaultHomePath` 直接设置该地址，应用入口与模块首页保持一一对应；模块路由直接注册模块自身的概览页面，避免复制页面或让路由依赖会话中的上次访问路径。

模块首页页面、工具函数和页面测试必须位于 `oak-base-admin` 的 `modules/com_levin_oak_base/views/home/`。其 `backendRouteMappings.sourceFilePath` 与 `viewPath` 指向同一个模块页面；Bootstrap 应用不再覆盖应用级 `_core/home` 页面。

`admin-crud.ts` 仅生成 CRUD 子页面。模块首页作为非 CRUD 页面在模块专属 `routes.ts` 中定义，并在 `module.ts` 组装到模块根路由的默认子路由位置。

## Non-Goals

- 不新建或改造概览页。
- 不覆盖后端为特定用户返回的非根 `homePath`。
