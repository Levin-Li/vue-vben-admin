# Design: URL ACL Security Delegation

## 最新外观要求：参考登录，保持外层独立

最后文案调整：服务端文字/图标点选 instruction 固定为“请按顺序依次点击”；前端在原生题面头部把文字与提示图靠右排列，不另起段落。
成语点选 instruction 经用户确认改为“请按语义顺序点击下图的文字”。
操作提示使用正常正文14px字号，取消此前单独缩小为12px的样式。

用户进一步明确：操作提示文案由服务端 instruction 负责，前端只展示排版，不按模式自行拼句。补齐服务端五种实际题面生成分支（滑块、文字点选、图标点选、成语、避障）的空 instruction，前端移除模式默认句。此条取代前一轮前端缺省操作指引约定。

用户明确不合并登录与二次验证外层/后端，仅对齐展示。行为宽度严格采用 login.vue 当前的 min(题面宽度+48,700)，未加载题面按427宽预留；普通验证采用Ant Modal登录默认520。二次验证继续自身Modal.confirm生命周期，通过局部样式去掉确认框图标缩进、采用登录24px内容内边距，标题和取消按钮保持业务二次验证语义。行为验证完成会自动继续，不显示无效外层确定按钮。

共用的BehaviorCaptcha内部不再在题面外单独放指令段落：点击/滑块的指令进入GoCaptcha原生header title，与提示图同区；避障进入其已有头部区域。默认点选短句按用户原文“请按顺序依次点击下方图片中的文字或图标”。两套外层和后端仍分别维护，不抽取或合并完整登录流程。

## 验证弹窗文案与通用组件

删除公共二次验证弹窗标题下“Api接口需要……才能调用”等重复说明，对短信、邮箱、MFA、图片和行为验证码统一生效。短信/邮箱发送结果、测试码和真实错误继续保留；MFA不显示“已发送”类错误语义。删除说明对应的固定空白高度，不改验证协议或业务页面。

现有 BehaviorCaptcha 已通过框架包公开导出，输入 challenge/loading，输出 complete/refresh，登录和 URL ACL 共用。本轮直接完善此唯一组件，不新增相同职责的包装层、不破坏公共导出路径。优先显示服务端 instruction；缺失时按 CLICK、IDIOM_CLICK、SLIDE、OBSTACLE_AVOIDANCE 显示具体操作指引。操作指令属于完成题面所需信息，与外层重复认证说明区分。提示用普通文本渲染，不执行 HTML；公开使用文档及测试覆盖组件级复用。

## 六项安全加固（2026-09-09）

本节取代本文此前缺失安全服务仍放行的约定。用户授权修复六项风险，无实体迁移、无新依赖，不修改既有业务页面。旧的可计算 VerifyId 不再接受；在途挑战需重新申请，不提供旧协议降级。

1. URL ACL Apply 创建随机 256-bit token（VerifyId），Redis 保存五分钟的绑定摘要。摘要使用无歧义序列化的登录会话、用户、租户、appId、验证类型、HTTP 方法、真实路径/query 和服务器请求体 SHA-256。提交在分布式锁及原子消费下验证，错误次数有上限；Redis/锁不可用拒绝。请求内同类型验证成功可复用，跨请求不可复用。
2. VerifyServicePlugin 新增 verificationScope 生成参数及 verifyScoped 方法，默认不支持作用域验证并拒绝，避免未知插件默默降级。BizVerifyCodeService 新增 verifyScoped 分派入口。短信、邮箱、图片验证码缓存隔离 scope；MFA/行为插件保留自身算法，结合外层挑战绑定与自身一次性消费。普通登录/找回等原有无 scope 调用仍是独立用途，不能读取 scoped OTP。
3. MFA 对有效码增加 Redis 原子消费；消费键不依赖可变 appId/账号别名，依据真实租户/用户 ID、密钥摘要及有效码，TTL 覆盖 SDK 接受窗口。缺少 Redis、异常或重复消费均拒绝。不会改变或泄露用户密钥。
4. 签名/加密委托缺失返回 503；流量规则阈值无效、无可用算法引擎或执行异常返回 503 标准失败响应、禁止缓存，不再放行。未命中规则仍照常通过。TokenBucket 无实现不冒充 FixedWindow。
5. 短信/邮箱数字码使用 SecureRandom，至少六位；默认每接收账号 60 秒发送间隔、十分钟最多五次发送、每租户/类型十分钟最多500次总发送、十分钟最多十次验证尝试（按租户和类型隔离，跨 app/scope 共享防刷配额，租户总配额防止轮换任意收件地址无限发送）。保护参数可配置且校验正值，mock 模式同样保护，Redis 计数/锁故障不发送也不放行；OTP 成功原子消费。发送服务失败不能保存有效 OTP。
6. UrlAclSecurityFilter 对命中的签名/加密及动态验证请求，在读流前检查声明长度、读流时最多读取上限+1；缺失 Content-Length 或 chunked 同样受限。默认 1 MiB，通过 plugin.com.levin.oak.base.url-acl.max-request-body-bytes 配置正值；解密后的明文也检查。没有缓存的非空请求直接拒绝摘要验证；客户端 RequestHash 不作为可信依据。multipart/form-data 参数解析不作为突破限制的途径，按真实字节限定；既有未命中接口不受此局部限制影响。

验收必须分别证明正常、篡改、重放、并发、依赖异常和超限，不能以 happy-path 代替安全修复证明。涉及普通登录验证码/MFA、URL ACL、签名/加密和流量拦截器的直接及间接入口均纳入审计。真实测试使用既有独立测试数据库副本及新 QA 配置；不启动无关定时作业，不修改外部项目。

上传透明性：公共请求层仅在收到动态验证要求后、首次 Apply 前通过原生浏览器 multipart 编码生成一次字节数组，固定 boundary，Apply 与最终提交复用这些字节；初始请求尚未签发挑战，不要求其 boundary 相同。未触发验证的普通 FormData 上传不提前整包读取，业务上传页面不改。后端使用当前默认 Tomcat 已提供的 multipart 解析器在有界缓存上保留字段、文件和 Part headers，不新增依赖或临时文件。按路径/方法/域名保守预筛选在解析参数前实施大小限制，因此同候选路径但主体/IP/参数条件最终不匹配的请求也受上限保护。其他未命中路径维持原行为。

前置客户端应用认证过滤器也存在请求体缓存入口，且执行在 URL ACL filter 之前。为避免组合认证请求在前置层无限读流，该入口使用同一大小配置及 413 语义，在可能解析请求体的登录检查前有界读取；未携带客户端认证材料的请求保持原样。

真实联调发现普通 MVC 配置中的 `@ConditionalOnBean(RedissonClient)` 在自动配置注册前可能误判，旧本地引擎降级掩盖了它。将两个限流引擎 Bean 移至独立 RateLimitConfiguration，去掉默认 Redis 引擎的过早条件，延后可选注入实际 Redis 客户端；客户端缺失时 acquire 拒绝。保留原 Bean 方法名称及显式单机属性，独立配置使用真实 Spring 装配测试覆盖晚注册/缺失场景，不用模拟整个 MVC 配置。

## 独立测试入口与验收（2026-09-09）

### 业务透明性（用户再次明确）

实测协议修正：Hmi Apply 响应仍通过现有 Type/VerifyId/ParamName 头声明挑战，题面对象直接放 JSON 响应体（不再发送 InteractionData 响应头），由公共请求层统一读取；其它类型保持各自协议。短信提示不能因 operator 中无手机号而在实际验证码已成功生成后抛空指针。中文提示需 URL 编码，删除无消费者且名称含中文的开发提示头；签名错误说明同样编码。不会在业务页面增加分支。

为既有业务接口配置二次验证不要求修改原页面或业务调用。业务仍调用公共请求客户端；公共层保持原 Promise 待决、识别挑战、弹出共享组件，验证后保留原 HTTP 方法、URL、query、body 及业务请求头重放，只有后端验证成功才允许业务执行。取消/错误不能作为业务成功返回。测试页仅触发普通接口请求，不自行申请、填入或提交动态验证码。增加普通 DELETE 请求的保真和取消拒绝测试，防止只对测试页工作。

测试页访问声明：当前后端菜单模式会将没有授权菜单的所有映射替换为禁止页。为本测试页增加源码路由映射的显式 `onlyRequireAuthenticated: true`，公共菜单路由构建器仅对开发者显式声明的此类映射提供隐藏但可直达页面；全局登录守卫仍要求 accessToken。未声明的原有业务映射保持无菜单即拒绝，不修改用户角色，不信任后端菜单数据自行授予此标记。需分别验证普通登录用户可访问、匿名被登录守卫拦截和其它无菜单页面仍禁止。

- `BizAclTestController` 位于 admin-api 非生成目录，路径 `/aclTest`，仅 local/dev/test 装配。五个 POST 方法 `sms`、`email`、`mfa`、`hmi`、`sign` 免 RBAC 认证，只以 ApiResp 包装并回显输入 JSON，不持久化业务数据，不在方法中实现验证。
- 动态验证保持现有登录用户绑定机制；匿名动态请求拒绝。签名使用独立 ClientApp（HMAC_SHA256），仅允许 `/aclTest/sign`，不隐式登录。
- 管理 API 显式创建五条限于测试 POST 路径的 ACL。重复执行检查已有配置，不改写旧 Demo 规则。测试凭据、令牌、验证码不得提交仓库或写入日志/报告。
- 本地自动验收使用显式 `scripts/qa/acl-live-smoke.py` 创建随机隔离 QA 租户及新测试配置（PostgreSQL 测试夹具），随后从真实注册/登录 HTTP 入口创建用户。仅本次新用户初始化虚构手机号、邮箱及随机 MFA 密钥，签名随机密钥和状态文件权限为 0600。不更改任何既有账号、规则或登录配置；属于用户授权的新测试数据而非历史迁移。一般管理界面仍可按同样字段手工创建配置。
- 现场原库与当前实体存在字段差异，真实验收使用新建本机 `acl_test_` 前缀数据库副本；只在该一次性副本允许 Hibernate 更新结构。启动通过系统属性指定数据库，夹具使用同一数据库名。原库不进行迁移；首次启动暴露的旧结构错误写入验证记录。
- 前端独立测试页面与专用 API service，五个入口复用公共请求客户端和动态验证弹窗，展示提交数据及返回结果。短信/邮箱使用用户授权的模拟模式，明确展示模拟验证码来源；不得标记为真实投递。MFA、行为验证码、签名使用真实算法与协议。
- 签名密钥由测试操作者临时输入，仅页面内存使用，不存 localStorage、不写日志；浏览器签名绑定实际发送的 JSON 字节、POST 路径和查询串。页面不引入全局自动签名。
- 验收覆盖回显、匿名认证边界、正确/错误动态码、取消、签名正确/错误/篡改/过期/重放；通过真实 HTTP、浏览器界面、单测三类证据分别报告。行为验证码触发与完成均须验证，不能用插件单测代替。
- 本轮不扩大为上一轮发现的全部安全改造；真正阻塞本次测试的缺陷先追加任务再修复。测试接口生产禁用，页面标明用途；不添加匿名配置写入接口。

## Boundary

`ClientAppAuthFilter` is intentionally not part of this flow. That filter authenticates a third-party client application and logs the request in as a bound service user. URL ACL signature verification and data crypto are different concerns: they protect selected URL requests according to `UrlExAcl` policy and must not implicitly create a login token or depend on client-app authentication.

## Flow

```
request
  -> normal web filters
  -> UrlAclInterceptor matches UrlExAcl rules
  -> SignVerify/DataRsaCrypt delegates to UrlAclSecurityService
  -> controller runs only when the delegated action passes
```

## Security Manifest

`BizUrlExAclController` exposes a public manifest endpoint for clients to discover which URL patterns currently require signature or data crypto handling. The manifest is a client-side optimization and protocol hint; the server still enforces the active `UrlExAcl` rules on every request.

The first client implementation may keep the manifest in memory only. The response includes `version`, `generatedAt`, and `ttlSeconds`; clients refresh after expiration or after receiving a server response that advertises a different manifest version.

The manifest endpoint itself must not require `SignVerify` or `DataRsaCrypt`, otherwise clients could not discover the rules needed to protect later requests.

The manifest must never include secrets, private keys, or decrypt keys. It may include only rule matching information, protocol names, algorithm identifiers, TTL, and version metadata.

## Service Contract

Add a dedicated URL ACL security service in the web/security boundary. The interceptor passes request context and the matched ACL; the service owns signature and crypto protocol decisions.

Suggested methods:

```
boolean verifySignature(operator, acl, request, response, tenantInfo);
boolean handleDataCrypto(operator, acl, request, response, tenantInfo);
```

## Signature Verification

`SignVerify` should validate request-level signature material supplied by the caller, such as timestamp, nonce, request body digest, and signature. Key lookup should be explicit and configurable for this URL ACL security mechanism; it should not infer success from `ClientAppAuthFilter`.

Possible later key sources:

- `acl.exInfo` for a simple shared secret or key reference.
- A dedicated URL ACL credential table if multiple callers or key rotation are required.
- A named Spring bean resolver when deployments need custom key lookup.

## Data Crypto

`DataRsaCrypt` should delegate to the same service boundary, but actual request-body decryption and response encryption may require a filter or request/response wrapper. The ACL decides when crypto is required; the delegated service/filter owns how crypto is performed.

## Concrete Protocol

The implementation must provide an executable default protocol rather than a pass-through placeholder.

### Signature

Request headers:

- `X-UrlAcl-App-Id`: client credential id.
- `X-UrlAcl-Timestamp`: epoch milliseconds.
- `X-UrlAcl-Nonce`: per-request nonce.
- `X-UrlAcl-Body-Sha256`: lowercase hex SHA-256 of the request body bytes.
- `X-UrlAcl-Signature`: lowercase hex HMAC-SHA256.

Canonical string:

```
METHOD
path
queryString
timestamp
nonce
bodySha256
```

The default key source is `ClientApp.appSignSecret` looked up by `clientId` and tenant. This reuses the credential data only; it must not use `ClientAppAuthFilter` or create/login an operator. The signing service must reject missing headers, stale timestamps, duplicate nonce, disabled/missing client apps, body hash mismatch, and signature mismatch.

### Data Crypto

Request headers:

- `X-UrlAcl-App-Id`: client credential id.
- `X-UrlAcl-Crypto`: `AES_GCM` or compatibility alias `RSA_AES_GCM`.
- `X-UrlAcl-Crypto-Iv`: base64 12-byte GCM IV.
- `X-UrlAcl-Plain-Content-Type`: optional decrypted request content type; defaults to `application/json`.

The default executable implementation derives an AES-256 key from `ClientApp.appSignSecret`, expects the encrypted request body to be base64 AES-GCM ciphertext, decrypts it in a servlet filter before MVC request binding, and encrypts successful 2xx response bodies back to base64 AES-GCM ciphertext. Response headers include `X-UrlAcl-Crypto`, `X-UrlAcl-Crypto-Iv`, and `X-UrlAcl-Crypto-Content: base64`.

## Compatibility

Missing `UrlAclSecurityService` remains pass-through for compatibility in tests or partial application contexts. In a normal Spring context the default executable service is present and enforces the signature/crypto gates above.

## Demo Defaults

Module data initialization should create a public Demo-only client credential, two public URL ACL rules, and a public Demo traffic-control sample rule for the Demo request-body test endpoint pattern:

- Client app id: `demo-url-acl-client`.
- Demo URL pattern: `/com.levin.oak.base/V1/api/Demo/testRequestBody*`.
- URL ACL rules: one `SignVerify` rule and one `DataRsaCrypt` rule, both limited to `POST`.
- Traffic-control rule: one fixed-window sample rule, limited to `POST`, with a rule-level bucket.

These defaults are demo/sample configuration only. They must be created by `ModuleDataInitializer` rather than a separate Spring initializer, must not use `ClientAppAuthFilter`, must not require a login, and must be idempotent so repeated startup does not create duplicate rules. All initialized path matchers must point at Demo business controller endpoints rather than real business APIs, because the Demo module is intentionally not an operational business surface. The full-chain verification should use the Demo URL pattern rather than an unrelated simulated business path.

## 安全基础类运行时说明

为 UrlAclSecurityService、默认实现、加密上下文、挑战存储和限流契约补齐中文职责与方法说明。优先通过 Swagger Schema/Operation 保留运行时元数据；内部算法步骤使用代码注释，说明真实默认行为，不通过注解改变安全校验或接口暴露。

验证：JDK25，`mvn -U -Penv0-local -pl web-commons -am test -Dmaven.test.skip=false -DskipTests=false -Dtest=UrlAclSecurityDocumentationTest,DefaultUrlAclSecurityServiceTest -Dsurefire.failIfNoSpecifiedTests=false`，16项通过，包含运行时反射读取 Schema/Operation 和既有签名加密回归。未变更执行逻辑。

## 签名四字段协议（用户确认）

签名原文改为 appId、timestamp、nonce、bodyHash 四行，UTF-8，换行连接且末尾无换行。HMAC-SHA256 小写十六进制输出；不再绑定方法、路径或查询串，不接受旧六行签名。应用权限白名单、时间校验、Redis 防重放、服务端实际请求体摘要校验仍保留。前端测试工具和 HTTP 验收脚本同步更新。

四字段协议验证：JDK25，`mvn -U -Penv0-local -pl web-commons -am test -Dmaven.test.skip=false -DskipTests=false -Dtest=DefaultUrlAclSecurityServiceTest,UrlAclSecurityDocumentationTest -Dsurefire.failIfNoSpecifiedTests=false`，19项通过；前端 acl-test 目录 Vitest 11项通过；两个QA脚本语法检查通过。当前后台进程未重启，未执行新协议实时HTTP验收。

## 应用标识请求头命名

用户确认将签名及加密协议的应用标识头统一改为 `X-UrlAcl-App-Id`，不保留旧请求头别名；四字段签名原文和验证逻辑不变。

应用头更名验证：JDK25，`mvn -U -Penv0-local -pl admin-api -am test -Dmaven.test.skip=false -DskipTests=false -Dtest=DefaultUrlAclSecurityServiceTest,UrlAclSecurityDocumentationTest,UrlAclSecurityFullChainMockMvcTest -Dsurefire.failIfNoSpecifiedTests=false` 共21项通过，包含签名加密全链路 MockMvc；前端 acl-test Vitest 11项通过。Demo读取头及全链路测试四字段原文已同步。当前后台进程未重启。

## Swagger开发规范强制化

接口类使用 Tag(name, description)（Operation不支持TYPE），接口方法必须使用 Operation(summary, description)，DTO/VO/BO/PO等值对象实例字段必须使用 Schema(title, description)，两项文案均非空且为真实中文说明。此轮维护规则，不进行存量全库注解补齐。

## 前后端代码段落规范

用户要求前后端代码不要过度紧凑，按逻辑分段且每个段落有中文注释。将其写入通用规则，前后端规则入口引用；本次不批量重排存量代码。

## 签名应用查询租户隔离

应用必须按服务端确认的当前域名租户 ID 与 appId 联合查询。缺失租户 ID 时拒绝，不执行无租户查询；查不到时不回退公共或其他租户应用。查询结果须再次严格校验租户归属，签名和数据加密共用此约束。

补充要求：最终应用查询键为 tenantId + orgId + appId。orgId 在匿名签名调用中的来源待用户确认，尚未实施组织条件。已完成租户条件必填和禁止跨租户回退；JDK25 `mvn -U -Penv0-local -pl admin-api -am test -Dmaven.test.skip=false -DskipTests=false -Dtest=DefaultUrlAclSecurityServiceTest,UrlAclSecurityFullChainMockMvcTest -Dsurefire.failIfNoSpecifiedTests=false` 24项通过。不得将此结果视为三字段查询已完成。

## 应用标识改为主键（取代此前联合查询方案）

用户已将 ClientApp.id 定义为 appId。X-UrlAcl-App-Id 及四字段签名中的 appId 均为该主键，应用仅按 findById(appId) 查询，不追加 tenantId/orgId 查询条件，不保留旧业务 appId 字段回退。查询后保留既有启用、密钥、算法、有效期、当前域名租户归属和白名单校验。无需新增组织请求头。此轮不修改用户实体或执行数据库迁移。

编译暴露 ClientAppAuthFilter 仍调用已删除的 getAppId；同步请求上下文应用标识为 getId 并更新过滤器夹具，纳入本轮回归。

同轮编译还暴露 BizClientAppController 创建逻辑调用已删除 appId 字段；移除该字段的额外生成逻辑，应用 ID 由实体已有主键生成器负责。

主键映射验收：JDK25，`mvn -U -Penv0-local -pl admin-api -am test -Dmaven.test.skip=false -DskipTests=false -Dtest=DefaultUrlAclSecurityServiceTest,UrlAclSecurityFullChainMockMvcTest,ClientAppAuthFilterTest -Dsurefire.failIfNoSpecifiedTests=false` 41项通过；前端 acl-test Vitest 11项通过；QA脚本语法检查通过。当前后台进程未重启，未迁移现有QA数据库记录。生成目录中他人改动的空白检查问题未修改。

## 应用标准最佳匹配入口（最新约定）

签名及加密获取 ClientApp 统一使用标准服务 findBestMatch(tenantId, orgId, id)，替代直接 findById。tenantId 来自当前域名租户；orgId 来自传入的服务端操作者，匿名时为 null。标准服务负责 nullOrEq 归属匹配和启用/有效期；不增加请求头或旧接口回退。公共 NULL 归属不能再被后置严格相等校验拒绝。按用户要求不编译，更新测试源码并静态核对。

## 最佳匹配委托及编译收口

用户要求业务服务原有 findBestMatch 委托标准服务，避免重复维护匹配条件和排序；同时解除暂不编译约束，完成后端 reactor 编译及相关定向回归。检查同类委托缺失、旧调用及通用历史服务编译问题，禁止手改生成目录，保留用户实体改动。

新生成代码编译暴露旧调用：Demo及应用认证残留ClientApp.appId，证书更新残留不可更新domain。按现有主键ID模型调整应用引用，并移除证书更新中重复设置原域名；创建时域名仍保留，不修改实体/生成产物。

标准CreateClientAppReq不允许设置自动主键，Demo初始化改按专用Demo名称定位并使用标准create生成主键，日志输出实际ID；不继续使用旧固定appId。

开通区域仍有业务最佳匹配调用，但OpenArea缺少SelfOverridableObject元数据，无法生成标准方法。本轮声明tenantId/orgId/domain/bizType匹配字段，按实体编译后生成标准代码，再恢复业务委托及原行政编码辅助方法，避免删除有效控制器能力。

## 客户端签名对接指南

输出 docs/签名验证对接指南.md，面向首次接入者，覆盖应用主键与密钥申请、服务端ACL配置、归属匹配、四字段签名逐字节规范、完整请求、Java/Python/Node客户端、固定公开测试向量、失败排查、重试及上线检查。示例仅使用公开虚构凭据，离线自测及本机模拟HTTP验证，不访问真实业务接口。

## 交付定位与命名

按用户要求定位为面向客户端开发者的对接指南，统一名称《签名验证对接指南》，文件名同步调整，保留逐步操作、可运行示例和排查指导。

## 对接指南读者边界

用户明确指南只面向客户端使用者。删除平台配置、数据库映射、标准服务查询及内部验签执行顺序；只保留接入资料、对外协议、客户端实现、可操作的错误处理和联调步骤。内部验收细节保留在本change，不进入客户指南。
