# 实现与边界

过滤器顺序在TenantFilter之后、ClientAppAuthFilter及UrlAclSecurityFilter之前（HIGHEST_PRECEDENCE+50）。命中配置后使用getContentLengthLong，不访问正文或表单解析。显式长度0允许，未知长度拒绝；因此受保护URL的无正文请求也须声明Content-Length: 0。多条规则全部满足才放行。Content-Length只控制声明大小，传输帧一致性仍由HTTP容器处理，不声明完全阻断已发至代理的流量。

新增RequestBodyLimit枚举；参数复用exInfo.maxRequestBodyBytes（Long正整数，缺省1MiB），管理员可在前端按规则配置。不能伪装为对现有签名1MiB缓存限制的替代；其他安全处理的限制仍独立适用。

本类型支持URL/方法/域名/IP/地区/操作系统/请求头等无需读取正文的匹配条件。不能依赖用户类型、用户角色或请求参数，因为执行发生在应用认证和表单解析之前。保存时验证这些限制，运行时对命中的非法配置失败关闭。空匹配规则沿用不命中语义；禁用和排除规则不执行。MVC拦截器跳过已在过滤器执行的本类型，避免再次触发参数读取。

测试：长度未知/超限0次正文读取，边界长度及零长度放行，chunked拒绝，多规则最严格上限，路径/方法/域名/IP/Header及排除、禁用、非法配置、过滤器顺序。前端提交回显及字段说明。真实本机HTTP仅使用测试服务和虚构数据，无生产写入。

前端现有CrudFieldConfig不支持字段visibleOn，不扩展公共运行时；阈值字段显示但明确仅RequestBodyLimit类型生效，其校验和提交按类型执行，其他类型不写入此扩展参数。
