# 设计

`VbenLayout` 的主内容区域是固定顶栏之后唯一应承担页面级滚动的 flex 子项。当前 `LayoutContent` 只有 `flex: 1`，未显式允许收缩，也未定义页面级 `overflow-y` 边界；页面根节点的 `min-height: 100%` 与内容外边距会参与高度计算，导致微小溢出落在不稳定的祖先元素上。

`LayoutContent` 将显式设置 `min-height: 0`、`overflow-y: auto` 和 `overflow-x: hidden`。这样 flex 布局能把它收缩到顶栏以下的实际可用高度，只有 `scrollHeight > clientHeight` 时才显示纵向滚动条。表格和弹窗继续管理各自的内部滚动区域。

该修复位于 `@vben-core/layout-ui` 的实现源中，并随 `@vben/layouts` 对外分发；不在每个 CRUD 页面增加局部补丁。

## 2026-09-09：修正页面可用高度

上述滚动容器约束保留，但不能解决自动高度 Page 使用了外框高度的问题。在 `@vben-core/composables` 的 `useLayoutContentStyle` 每次尺寸重算时读取内容元素的计算样式，从可见外框高度扣除 `paddingTop`、`paddingBottom`、`borderTopWidth`、`borderBottomWidth`，使用浮点像素并将结果限制为非负值。元素为空时结果为零。

`visibleDomRect`、`overlayStyle` 和内容宽度仍使用原始 `getElementVisibleRect()` 的结果，不修改通用工具，不修改 Page 或业务页面。沿用现有 ResizeObserver 和防抖更新，确保布局间距或大小变化后重新计算。

回归覆盖外框 765px、上下内边距各 2px 时输出 761px，以及无间距、小数和非对称间距、边框、视口高度限制、尺寸和间距更新、空元素及零高度。遮罩的位置和外框尺寸必须保持原值。
