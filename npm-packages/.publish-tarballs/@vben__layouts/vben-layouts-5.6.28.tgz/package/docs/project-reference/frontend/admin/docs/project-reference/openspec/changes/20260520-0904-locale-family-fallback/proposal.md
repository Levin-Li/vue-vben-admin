# Locale Family Fallback

## Why

Locale loading currently expects an exact resource directory match. Inputs such as `zh`, `zh-TW`, `en`, `en-UK`, or underscore/case variants can fail to load messages when only `zh-CN` and `en-US` exist, causing untranslated keys to appear in the UI.

## What Changes

- Normalize incoming locale codes internally without changing the public API: trim, convert `_` to `-`, lowercase the language segment, and uppercase segments after the first dash.
- Resolve requested locales against the actually available locale resource directories.
- Prefer exact matches, then same-language family fallbacks, then the configured default locale, then the first available locale.
- Ensure i18n is set to the resolved existing locale instead of a missing requested locale.

## Impact

- Affects `@vben/locales` locale loading only.
- Existing callers keep using the same `setupI18n` and `loadLocaleMessages` APIs.
- Prevents common locale aliases from producing raw translation keys when compatible resources exist.
- Existing `zh-CN` and `en-US` preference values remain valid.
- Keeps preference configuration typing constrained to the existing supported persisted locale values; fallback is handled at locale loading time.
