# Import Export Template Admin Page

## Summary

Add the missing frontend CRUD page registration for import/export templates and keep its menu entry under the backend/system management CRUD root instead of appearing as a standalone top-level menu item.

## Scope

- Add the import/export template API service wrapper.
- Add the import/export template CRUD page and field configuration.
- Register the resource in the oak-base admin CRUD route and backend route mapping list.
- Add focused frontend tests for route/menu placement.
