# Use tenant site name for layout brand

## Why

The authenticated admin layout currently renders the sidebar/header logo text from the static application preference name, which is ultimately derived from `VITE_APP_TITLE`. In tenant/domain deployments, operators expect the visible backend name to come from the current tenant site information so each domain can show its own site/system name.

## What Changes

- Load tenant site brand information in the authenticated basic layout.
- Render the layout logo text from the tenant site brand name, with the existing application preference name as fallback.
- Reuse the existing tenant site brand mapping used by the authentication pages.

## Impact

- Affects the visible logo text in the authenticated admin layout.
- No backend API or payload change; reuses existing `rbac/tenantSiteInfo`.
