# Keep pay channel currency code inline

## Why

The pay channel form currently renders `支持货币代码` as a full-width row, separating it from the related `货币类型` field. Operators expect these two currency-related fields to sit on the same form row for faster scanning and editing.

## What Changes

- Remove the full-row layout override from the pay channel `支持货币代码` field.
- Let the existing form grid place `支持货币代码` inline after `货币类型`.

## Impact

- Affects only the pay channel create/edit form layout.
- No API, payload, or validation behavior changes.
