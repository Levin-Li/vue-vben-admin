# Reset Preferences Without Logout

## Why

The preferences drawer currently labels its reset action as “清空缓存 & 退出登录” and clears the current login session after clearing preference data. Resetting the visual and interaction preferences should take effect immediately without interrupting the user’s authenticated work.

## What Changes

- Rename the preferences-drawer action to “恢复默认设置”.
- Clear only preference/cache data owned by the preferences subsystem; preserve the authentication session and user identity.
- Restore the default preference values in the active application immediately, so the current layout and theme update without requiring a reload or logout.
- Remove the obsolete logout event chain; perform the preference reset locally in the drawer.

## Impact

- Affects the preferences drawer, layout event names, localized action labels, and the packaged locale/layout build output used by local development.
- Does not change backend APIs or authentication/session storage.
