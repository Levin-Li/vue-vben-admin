## Why

登录页需要使用当前域名对应租户站点自身维护的内容，避免后台 UI 设置、租户或平台配置混入站点的登录页展示。

## What Changes

- 管理员在租户站点管理中维护 `title`、`titleImg`、`mainImg`、`logo`、`copyright` 与 `techSupport`。
- 登录页只读取当前域名匹配的 TenantSite；不读取后台 UI 设置、Tenant 或 Platform 的登录页信息。
- `title` 用于登录页系统标题，`titleImg` 用于标题图，`mainImg` 用于左侧主图；图片不可用时回退内置展示，不阻断登录。

## Impact

- 前端：认证品牌状态、认证布局；移除后台 UI 设置中的登录页配置入口。
- 后端：TenantSite 实体、生成的服务/请求对象/控制器模型，以及公开 `tenantSiteInfo` 返回值。
