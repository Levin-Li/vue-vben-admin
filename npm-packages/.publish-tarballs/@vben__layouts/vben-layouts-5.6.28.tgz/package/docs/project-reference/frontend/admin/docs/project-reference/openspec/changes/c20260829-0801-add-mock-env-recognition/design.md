## Context

`BizEnvServiceImpl` 以 Spring 的激活 Profile 为唯一输入，并以 `prod` Profile 作为生产环境的排它开关。当前环境枚举和接口没有 mock 表达，尽管部分启动模块已有同名配置文件。

## Goals / Non-Goals

**Goals:**

- 让调用方能通过 `BizEnvService#isMock()` 识别 `mock` Profile。
- 保持既有的大小写无关匹配和 `prod` 优先语义。
- 用单元测试锁定 mock 单独激活、与其它非生产环境叠加、与 prod 同时激活的结果。

**Non-Goals:**

- 不新增或启用 Maven、Spring Profile 配置。
- 不调整验证码、第三方登录或外部接口模拟功能的授权条件。
- 不改变现有 `isNonProd()` 的定义。

## Decisions

### 将 Mock 作为独立的非生产环境枚举值

在 `Env` 中新增 `Mock`，并让 `isMock()` 使用现有私有 `isEnv(String)` 进行检测。这样保留唯一的 Profile 规范化和大小写无关逻辑，避免接口实现之间产生不同语义。

拒绝由调用方以 `isNonProd()` 推断 mock：非生产环境也包含 dev、test、local 和 demo，无法表达调用方需要的精确环境。

### 复用生产排它保护

`isMock()` 与其它非生产环境方法一致，先受 `isNonProd()` 约束。只要 `prod` 被激活，所有非生产环境判断均返回 `false`。

拒绝为 mock 建立独立优先级：这会破坏现有服务的统一生产保护模型。

## Risks / Trade-offs

- [调用方开始依赖 `isMock()` 但启动配置未启用该 Profile] → 本次仅提供识别契约；配置启用作为独立需求处理。
- [将 mock 误用为外部接口模拟放行条件] → 本次不迁移任何既有功能；外部接口模拟仍受现有 `test` Profile 规则约束。

## Migration Plan

1. 发布服务接口、实现与测试。
2. 已有调用方无需迁移；后续需要精确 mock 判断的调用方可显式使用新方法。
3. 回滚时删除 `Mock` 枚举值和 `isMock()` 方法；无数据迁移或配置变更。

## Open Questions

无。
