# 设计

在 `config-helpers.ts` 定义详情弹窗默认宽度 `min(80vw, 1080px)`，供 `CrudPage` 的详情展示复用。1080px 能容纳现有两列详情网格和弹窗内边距；窄屏仍受 80vw 约束。

只替换未配置宽度时的回退值。业务页面通过 `detail.modalMaxWidth` 提供的显式宽度继续优先，不改写已有配置。
