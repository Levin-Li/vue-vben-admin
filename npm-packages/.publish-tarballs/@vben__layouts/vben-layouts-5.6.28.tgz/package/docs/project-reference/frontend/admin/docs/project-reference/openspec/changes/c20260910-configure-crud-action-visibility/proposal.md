## Why

页面展示设置目前只能控制整个“操作”列，不能为编辑、删除等具体 CRUD 操作增加运行时展示条件。业务操作已有权限和后端 `visibleOn` 限制，需要增加只会收紧展示范围的页面设置层。

## What Changes

- 在页面展示设置的展示列表中新增“具体行操作展示条件”，把内置详情、编辑、删除和已声明的自定义行操作作为可配置项。
- 每个操作支持展示、隐藏或基于当前行数据的显示表达式。
- 运行时把页面展示设置条件与权限、后端 `visibleOn`、可编辑性和业务状态限制做逻辑与。
- 为自定义行操作提供稳定的展示设置标识；无显式标识时使用操作标签的兼容键。

## Capabilities

### New Capabilities

- `crud-action-display-conditions`: 为具体 CRUD 行操作配置附加展示条件。

### Modified Capabilities

无。

## Impact

影响管理前端公共 CRUD、页面展示设置抽屉和持久化的 `pageDisplay.list` 配置。不会修改后端 API 权限、服务端授权或现有操作的业务条件。
