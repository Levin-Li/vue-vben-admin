## Context

`PlatformDomain` 使用状态机字段，业务实现已按流程规范实现读取、事件校验、迁移和事件列表填充，但其业务接口没有同步这些方法。与此同时，`ImportExportTemplateServiceImpl` 是受 `code-gen.md` 保护的默认生成类，不能手改；它与当前生成接口存在方法声明漂移。

## Goals / Non-Goals

**Goals:**

- 使平台领域业务接口与业务实现的状态机契约一致。
- 通过实体编译后执行 simple-dao-codegen 修复默认服务漂移。
- 恢复完整 `services-impl` 编译与相关测试。

**Non-Goals:**

- 不改变平台领域的状态图、权限规则或持久化结构。
- 不手改任何 `services` 或 `services-impl` 默认生成目录文件。

## Decisions

- 在 `BizPlatformDomainService` 中声明现有状态机业务方法；这是业务扩展层，允许手改，且使调用方得到稳定编译期契约。拒绝删除实现方法，因为会破坏已装配的流程接口。
- 先编译 `entities`，再运行 simple-dao-codegen 刷新默认服务与接口。拒绝删除 `@Override` 或在默认实现中手改方法，因为这会掩盖生成漂移并违反目录规则。
- 以完整 `services-impl` 编译为门槛，并执行平台领域和导入导出模板的目标测试。

## Risks / Trade-offs

- [生成器重写其他已修改生成文件] → 先检查实体与生成目录状态，只接受与目标实体相关的生成变化。
- [业务接口同步不完整] → 编译业务实现与调用点，并以状态机测试验证。
- [工作区并行修改] → 不覆盖无关文件，只处理本次契约所涉及的路径。
