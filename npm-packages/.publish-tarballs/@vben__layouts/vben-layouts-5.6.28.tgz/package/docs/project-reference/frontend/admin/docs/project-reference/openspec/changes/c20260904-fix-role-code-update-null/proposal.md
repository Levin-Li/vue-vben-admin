## Why

角色更新为禁止修改编码而将 `code` 设为 `null`，却保留了自动强制更新标记，导致数据库尝试写入空编码并违反非空约束。

## What Changes

- 更新角色时清除角色编码的自动强制更新标记。
- 保持角色编码不可修改，且不改变其它更新字段的行为。

## Capabilities

### New Capabilities

- `role-code-update-protection`: 角色更新时安全忽略不可修改的角色编码。

### Modified Capabilities

- 无。

## Impact

- 影响角色更新服务和回归测试。
- 不影响角色创建、角色编码规则、权限模型或数据库结构。
