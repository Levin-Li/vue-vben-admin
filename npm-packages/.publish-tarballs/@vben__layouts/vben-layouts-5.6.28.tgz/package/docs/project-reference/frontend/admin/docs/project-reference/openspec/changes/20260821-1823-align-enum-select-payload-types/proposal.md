# 对齐枚举下拉字段提交类型

## 背景

共享 CRUD 表单直接提交下拉框保留的选项值。部分页面未在静态字段配置中标明后端 DTO 的原始类型，导致枚举接口返回字符串值时，`Integer` 字段（例如用户的 `confidentialDataAccessLevel`）也被作为字符串提交。

## 变更范围

- 共享 CRUD 字段的 `valueType` 继续作为页面显式声明的提交序列化契约：`number` 转有限数字，`string` 转字符串，`boolean` 转布尔值。
- 为已发现缺失声明且后端 DTO 为 `Integer` 的用户、角色和机构机密等级字段补充 `valueType: 'number'`。
- 不按字段名、选项内容或运行时值猜测后端类型；其它页面必须在静态配置中按 DTO 类型声明提交类型。

## 验收标准

- 用户编辑页的 `confidentialLevel` 和 `confidentialDataAccessLevel` 以 JSON 数字提交。
- 角色和机构页面中同样的 `Integer` 机密等级字段以 JSON 数字提交。
- 显式标记为 `string` 的枚举选择值以字符串提交；无效数字值在请求前显示明确错误而不发起请求。
