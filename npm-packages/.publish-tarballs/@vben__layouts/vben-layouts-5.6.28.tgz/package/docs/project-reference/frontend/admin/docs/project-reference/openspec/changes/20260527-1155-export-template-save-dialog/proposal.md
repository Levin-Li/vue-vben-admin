# Change: Improve Export Template Save Dialog

## Why
The export-template save dialog is too small and exposes internal visibility-rule wording such as super-admin/admin visibility. Operators need a clearer template-name field and a roomier dialog while keeping the existing scope behavior unchanged.

## What Changes
- Rename the save dialog name field label to “模板名称”.
- Enlarge the save-template confirm dialog to approximately 1.5x its current visual size.
- Keep the existing scope choices and backend payload behavior, but remove visible explanatory role text from scope labels.

## Impact
- Frontend-only UI adjustment in the shared CRUD export-template dialog.
- Existing template save scope payloads remain unchanged.
