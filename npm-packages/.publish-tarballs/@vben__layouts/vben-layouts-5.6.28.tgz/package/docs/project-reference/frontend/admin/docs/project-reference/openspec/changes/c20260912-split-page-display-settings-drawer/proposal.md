## Why

页面展示设置抽屉超过两千行，详情表单和展示列表拥有与查询/新增/编辑不同的列模型，继续混在同一个组件会使局部布局调整互相影响。

## What Changes

- 将详情表单 Tab 和展示列表 Tab 提取为独立组件。
- 保持现有配置格式、保存载荷、权限和脚本编辑交互不变。
- 修复详情字段补齐的递归更新后，采用单棵活动编辑树差量更新以减少页签切换重建成本，并验证各视图草稿隔离。

## Capabilities

### New Capabilities

- `page-display-tab-component-boundaries`: 页面展示设置的详情与列表 Tab 组件边界。

### Modified Capabilities

无。

## Impact

影响管理前端公共页面展示设置抽屉及其回归测试；不影响后端接口和持久化结构。
