## ADDED Requirements

### Requirement: 修复受影响 Vben 公共包发布物

系统 MUST 为完整运行时依赖闭包中已发布 tarball 保留工作区或目录协议的 Vben 公共包发布递增补丁版本。依赖这些精确 Vben peer 版本的公共消费者包及其精确 peer 约束消费者包 MUST 同步递增版本并重新发布。发布流程 MUST 在上传后反查每个精确版本，并验证其 tarball 不含工作区或目录协议依赖。

#### Scenario: 发布受影响包的修复版本

- **WHEN** 已识别的受影响 Vben 包完成版本递增并进入发布清单
- **THEN** 私服中存在对应精确新版本，且其 tarball 通过依赖协议门禁
