# Proposal: Admin UI Setting Upload Target

## Background

The "上传界面设置" action currently uploads the admin UI base setting to the current tenant site by default. Operators need to choose whether the setting should be saved to the tenant site or the tenant itself.

## Scope

- Add a two-option upload target to the admin UI setting upload modal.
- Keep the default target as tenant site.
- Add a backend request parameter for the target.
- Save to tenant `uiExInfo` when the target is tenant, and keep existing tenant-site behavior when the target is tenant site.
