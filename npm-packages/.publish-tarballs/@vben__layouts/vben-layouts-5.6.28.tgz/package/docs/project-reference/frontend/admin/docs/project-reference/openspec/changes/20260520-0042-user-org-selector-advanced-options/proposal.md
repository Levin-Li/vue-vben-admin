# UserOrgSelector Advanced Options

## Why

The shared user and organization selector needs to support business-specific organization scopes without creating separate selector components. Callers need to constrain which organization types and user types are visible or selectable, choose whether organizations or users can be selected, limit selectable node shape, cap selection counts, choose root organizations, and decide whether organization children are loaded all at once or lazily.

## What Changes

- Add explicit selector options for organization/user type filters, selectable object switches, leaf/non-leaf organization selection constraints, maximum load depth, maximum selection count, root organization IDs, and organization load mode.
- Keep existing defaults compatible: organization tree loads all at once, both users and organizations remain selectable, organization type mismatch keeps ancestor paths visible by default, and no selection count limit is applied.
- Expose richer custom loading contexts to `loadOrgTree` and `loadUsers` so callers can replace default APIs while receiving the same filter and depth settings.
- Ensure lazy organization loading uses the component's own "load attempted" UI state to decide whether the expand icon remains available; unloaded nodes should be expandable even when the backend does not provide child-count metadata.
- Split the public component demo route into a `Demo` menu with focused child pages so lazy loading and permission assignment can be tested from separate menus.

## Impact

- Affects the shared `UserOrgSelector` public API and its tree-building utility.
- Existing usages should keep working with the previous defaults.
- Tests and documentation need updates for the expanded selector contract.
