## Why

`Org` 同时保留 `partnerId` 和 `externalLegalSubjectId`。在当前 `Partner` 使用 JOINED 继承并与 `LegalSubject` 共用主键的模型中，两者在合作伙伴主体场景会指向同一 ID，容易造成重复维护和数据不一致。

## What Changes

- 移除 `Org.partnerId`，以 `externalLegalSubjectId` 作为组织唯一的外部主体关联。
- 菜单与页面展示设置仍需按合作伙伴子类型匹配时，使用组织的 `externalLegalSubjectId` 查找同主键的 `Partner`；未找到 Partner 时按无合作伙伴类型处理。
- 通过实体重新生成同步默认 Org 请求、信息、服务和控制器模型。
- 提供数据库迁移：对 `external_legal_subject_id` 为空的组织回填旧 `partner_id`，随后删除旧列。
- 对齐机构管理页面：外部法律主体远程搜索使用法律主体查询参数，机构类别按实体非空约束必填。

## Capabilities

### New Capabilities

- `org-legal-subject-link`: Org 使用法律主体 ID 作为唯一外部主体关联，并可从其派生合作伙伴类型匹配。

### Modified Capabilities

- 无。

## Impact

- Org 实体及 simple-dao-codegen 生成的后端模型。
- 租户自定义菜单与运行时 UI 设置的组织类型解析。
- Org 数据库迁移脚本和相关回归测试。
- 管理端机构新增、编辑和查询页面配置。
