## Why

后台大量以 `lucide:名称` 字符串渲染图标。当前 `@iconify/vue` 在浏览器内尚未注册该图标时会请求外部图标 API，并可能回退到 `api.simplesvg.com`；网络受限时会产生控制台错误并导致图标缺失。

## What Changes

- 将 Lucide 的 Iconify 图标数据作为前端本地依赖随构建产物交付，并在图标公共入口注册。
- 保持既有 `lucide:名称` 图标值和 `IconifyIcon` 调用方式兼容，包括后端保存的菜单图标。
- 通用图标选择器对已注册的本地图标集不再请求外部图标集合 API。

## Impact

- 影响 `@vben-core/icons` 公共图标包和通用 `IconPicker`。
- 增加 Lucide 图标数据的构建产物体积，不影响后端接口、权限或数据模型。
