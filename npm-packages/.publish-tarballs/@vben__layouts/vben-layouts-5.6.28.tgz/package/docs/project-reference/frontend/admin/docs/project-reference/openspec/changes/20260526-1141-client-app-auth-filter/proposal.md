# Proposal: Client App Auth Filter

## Summary

Add filter-based third-party application authentication. Requests that include client application connection parameters are validated against `ClientApp`; after validation, the filter logs the request in as the application's bound service user and lets existing controllers, RBAC, tenant, organization, and data-permission checks continue unchanged.

## Scope

- Extend `ClientApp` so it can bind to a service user and hold app-auth restrictions.
- Add a `ClientAppAuthFilter` for app-auth detection and request-local service-user login context.
- Add business service validation for application status, tenant, IP allowlist, mandatory path allowlist, service-user safety, timestamp, nonce, and signature.
- Reuse existing API controllers and authorization path.
- Exclude traffic control/rate limiting from this change.

## Non-Goals

- No new `/api/open/**` controller layer.
- No API gateway, quota, billing, or rate limiting implementation.
- No replacement of existing user login/RBAC semantics.

## Risks

- Binding a client application to an over-privileged service user can expose too much of the existing API surface. The implementation mitigates this with mandatory path allowlists, default-deny management paths, and rejection of platform/super administrator service users.
- Existing environments need database migration for new `ClientApp` columns.
