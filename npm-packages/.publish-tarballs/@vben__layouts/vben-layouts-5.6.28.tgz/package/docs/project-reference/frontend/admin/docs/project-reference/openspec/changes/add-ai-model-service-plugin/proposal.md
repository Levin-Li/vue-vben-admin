## Why

平台现有的服务插件能够按租户和域名管理第三方服务配置，但尚不能统一、安全地调用主流大模型。各业务若自行接入 GPT、DeepSeek、Kimi 或 GLM，将造成密钥管理、流式协议、错误处理、限流与审计策略分散，且难以按租户控制可用模型。

本变更将模型调用沉淀为平台服务插件，并将其扩展为“自然语言操作界面”：AI 在当前用户既有的菜单、按钮、租户和数据权限范围内发现、预览并执行系统能力，而不是仅返回聊天文本。

## What Changes

- 新增 AI 大模型服务插件，复用现有服务插件及其租户、域名配置解析机制。
- 新增统一的同步聊天与 SSE 流式聊天业务接口，首批支持 GPT、DeepSeek、Kimi 和 GLM。
- 使用官方 OpenAI Java SDK 的 OpenAI 兼容聊天协议作为 GPT、DeepSeek、Kimi、GLM 的基础适配层；保留供应商扩展字段，避免丢失 Kimi、GLM 等供应商能力。
- 新增模型别名、供应商、模型能力和默认模型的受控配置；调用方不得提交 API Key、Base URL 或任意模型标识。
- 新增受权限保护的供应商连通性测试、调用审计、超时、限流和标准错误映射。
- 明确密钥仅由后端读取、脱敏返回、禁止记录到日志；配置持久化应使用平台现有的安全存储能力或新增加密保护。
- 新增界面能力目录，将可见页面、通用 CRUD 操作和已明确声明的业务动作映射为 AI 可发现工具；AI 不直接调用任意 HTTP 接口或执行动态脚本。
- 新增 Agent 执行流程：理解自然语言、补齐参数、按当前用户权限预览影响范围、在确认后执行受控业务工具，并记录工具调用审计。

## Capabilities

### New Capabilities

- `ai-model-service-plugin`: 为 GPT、DeepSeek、Kimi、GLM 提供可按租户和域名配置、路由和调用的统一服务插件。
- `ai-chat-api`: 提供受控的同步聊天、SSE 流式聊天和供应商连通性测试 API，并定义错误与审计行为。
- `ai-model-configuration-security`: 保护模型凭据、模型白名单、租户访问边界和调用配额。
- `ai-ui-capability-registry`: 将当前用户可使用的页面、通用 CRUD 与明确声明的业务动作发布为带权限和风险等级的 AI 工具。
- `ai-system-agent`: 提供自然语言任务解析、参数追问、执行预览、确认和受控工具调用的 Agent 工作流。

### Modified Capabilities

无。

## Impact

- 后端：`services` 增加 AI 业务接口、请求与响应模型及插件接口；`services-impl` 增加适配、路由、审计与测试；`client-api` 和 `admin-api` 增加业务控制器。
- 数据：复用 `ServicePlugin`、`ServicePluginSetting` 保存全局插件元数据和租户/域名供应商配置；首期增加调用审计实体。
- 依赖：服务实现模块引入官方 OpenAI Java SDK；不为本期 AI 接入升级全局 Spring Boot 或引入未经验证的供应商 SDK。
- 接口：新增内部及 HTTP 聊天、流式聊天、配置测试与 Agent 任务接口；不在首期提供对外 OpenAI 兼容网关、RAG 或自主执行动态脚本。
