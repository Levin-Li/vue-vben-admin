# Document JSONObject JsonSchema Field Rule

## Background

Entity `JSONObject` fields stored with `@JdbcTypeCode(SqlTypes.JSON)` can be edited either by a generic JSON editor or by a JSON Schema-driven form editor. Developers need a clear field-level rule for when JSON Schema metadata stored inside the JSON object value should be read and how empty metadata should fall back.

## Goal

- Define a development rule for entity fields whose Java type is `JSONObject` and whose persistence mapping uses `@JdbcTypeCode(SqlTypes.JSON)`.
- Allow these JSON fields to declare a `@JsonSchema` / `JsonSchema` metadata property inside the JSON object value.
- Define the accepted `@JsonSchema` / `JsonSchema` value formats: `class:` class name, `url:` JSON Schema URL, or inline JSON Schema content.
- Require JSON Schema editor usage only when the metadata value is non-empty; otherwise use the normal JSON editor.
- Record that JSON Schema fields may be shown inline or in a popup, with popup as the default presentation.
- Preserve existing `@JsonSchema` / `JsonSchema` metadata properties when saving JSON field values from create/edit forms.
- Require JSON Schema editors rendered as structured fields to follow the existing create/edit form rules for layout, validation, submission, and save behavior.

## Scope

- Entity field inspection for existing `JSONObject` JSON fields.
- Frontend CRUD create/edit form handling for these JSON Schema-aware JSON fields.
- Rule documentation and OpenSpec records.

## Non-Goals

- Do not change existing entity fields.
- Do not change `simple-dao-codegen` behavior in this task.
- Do not modify generated service or controller directories.
