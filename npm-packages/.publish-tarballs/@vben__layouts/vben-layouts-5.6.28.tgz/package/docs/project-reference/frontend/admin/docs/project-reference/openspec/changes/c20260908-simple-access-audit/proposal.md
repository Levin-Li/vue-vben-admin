## Why

现有访问日志缺少按时间窗口生成的审计结论。先用确定性统计和规则提供可查询的通用报告，不接入 AI。

## What Changes

- 完善 AuditReport 的字典型 targetType、targetId、startTime、endTime；允许重复生成，不增加周期、版本、去重字段。
- 提供仅超级管理员可调用的访问审计生成和报告查询入口；第一版支持平台或指定租户，限制窗口最长一天并按100条游标分批处理。
- 程序计算请求量、异常与状态分布、耗时、用户/IP 集中度及热点路径；生成中文规则结论和已知覆盖限制，不调用 AI。
- 提供仅审计 AccessLog 的每四小时专用定时任务，不生成日报；跨实例不可重入，逐条检查系统 CPU，超过40%循环等待。

## Capabilities

### New Capabilities
- `simple-access-audit`: 有界、可追溯、无 AI 的访问日志审计报告。
- `fixed-backend-jobs`: 现有固定任务初始化注册、数据库启停、每轮重新读取名称/描述/参数；不兼容旧系统设置。
- `audit-admin-pages`: 审计报告和后端固定任务独立页面及前端路由分组，上报后不再出现在基础模块之外。
- `json-schema-field-actions`: 显式声明且当前记录有编辑器的JSON字段，在默认行操作中提供专用字段编辑入口。

### Modified Capabilities
无。

## Impact

- 后端 entities、services、services-impl、admin-api 及生成代码。
- 管理前端增加两个独立页面、API声明与路由分组；不新增依赖，不修改日志采集链。
- 报告涉及聚合敏感数据，平台/指定租户生成及报告维护入口均限定超级管理员；原始认证头、正文和异常堆栈不进入报告。
- 新增实体结构只交付明确的部署说明，不执行历史数据迁移或生产数据库操作。
