## ADDED Requirements

### Requirement: 授权菜单下发要求展示权限和全部额外权限

系统 SHALL 将每个菜单自身的自动生成“展示”权限与菜单记录 `requireAuthorizations` 中所有有效权限共同作为 `authorizedMenuList` 的访问条件。菜单管理界面 MUST 将 `requireAuthorizations` 称为“额外所需权限”，并明确提示“菜单可见需要菜单展示权限 + 所有的额外所需权限”。非公开菜单只有所有条件均满足时才可下发；超级管理员和公开菜单的既有例外语义不变。列表、详情和写接口 MUST 保持既有独立授权校验。

#### Scenario: 同时拥有展示权限和额外列表权限的用户读取菜单

- **WHEN** 非超级管理员拥有某菜单的展示权限和该菜单配置的查询列表额外权限
- **THEN** `authorizedMenuList` MUST 返回该菜单

#### Scenario: 缺少菜单展示权限的用户读取菜单

- **WHEN** 非超级管理员拥有某页面列表接口权限，但不拥有该菜单展示权限
- **THEN** `authorizedMenuList` MUST 不返回该菜单

#### Scenario: 缺少任一额外权限的用户读取菜单

- **WHEN** 非超级管理员拥有菜单展示权限，但缺少任一已配置的额外所需权限
- **THEN** `authorizedMenuList` MUST 不返回该菜单

### Requirement: 租户菜单展示布局管理

系统 SHALL 允许有权限的管理员查看和维护当前租户的具名 `TenantCustomMenu`，并使用嵌套 `itemList` 表达展示树。

#### Scenario: 查看布局列表

- **WHEN** 管理员打开自定义菜单管理页面
- **THEN** 系统 SHALL 以标准列表展示当前租户的布局记录

#### Scenario: 标准 CRUD 维护

- **WHEN** 管理员新增、编辑或删除布局记录
- **THEN** 系统 SHALL 通过通用 CRUD 表格和表单完成操作
- **AND** 普通新增、编辑表单 SHALL 不展示 `itemList`

#### Scenario: 调整指定布局

- **WHEN** 管理员点击某条布局记录的“调整菜单”行操作
- **THEN** 系统 SHALL 在当前 CRUD 列表页上弹出调整菜单弹窗，只编辑该条记录的 `itemList`
- **AND** 关闭弹窗后 SHALL 继续显示标准 CRUD 列表。
- **AND** 保存 SHALL 调用既有的 `TenantCustomMenu/update` 接口，并显式提交 `itemList`。
- **AND** 弹窗 SHALL 只展示真实菜单与当前展示结构两栏；不展示取消按钮或展示项属性栏。
- **AND** 两栏标题 SHALL 分别显示为“系统菜单”和“我的菜单”。
- **AND** 两栏菜单内容 SHALL 各自在卡片内部滚动，弹窗本体不得承载菜单树滚动。
- **AND** 左侧系统菜单 SHALL 仅作为拖拽来源；鼠标悬停节点时提示“可拖到我的菜单”。
- **AND** 左侧系统菜单 SHALL 展示后端菜单下发的图标；缺失时使用默认菜单图标。
- **AND** 左侧系统菜单 SHALL 展示展开状态和层级缩进，以清晰表达父子关系，且不得重复绘制树形连线。
- **AND** 右侧我的菜单 SHALL 使用相同的树形展示形式。
- **AND** 右侧为可调整层级与顺序的树形结构。
- **AND** 右侧 SHALL 默认包含固定的“菜单列表”接收容器；该容器不属于持久化的 `List<Item>`，仅在悬停时显示紧凑的 `＋` 操作。
- **AND** 该接收容器 SHALL 作为右侧树的虚拟根节点参与展开和拖拽落位，但不得保存到 `itemList`。
- **AND** 非根节点可新增子节点，并可在节点行内设置名称和启用状态。
- **AND** `Item` SHALL 使用默认启用的 `enable` 字段，不再使用 `disabled` 或提示字段。
- **AND** 根节点即使没有任何子节点也 SHALL 持续显示，并在保存和重新打开后保持唯一。
- **AND** 从左侧拖入时，右侧悬停目标 SHALL 高亮并提示松开后会作为该节点的子菜单加入。
- **AND** 拖拽反馈宽度 SHALL 跟随节点内容，不得铺满整个菜单栏。
- **AND** 右侧节点的新增子节点与删除操作 SHALL 仅在鼠标悬停该节点时以紧凑操作显示。
- **AND** 弹窗最大宽度与高度 SHALL 分别不超过视口的 70% 和 80%。

#### Scenario: 打开自定义菜单页面

- **WHEN** 管理员点击“自定义菜单”菜单项
- **THEN** 系统 SHALL 打开 `TenantCustomMenu` 专用页面，不得跳转至原始“菜单管理”页面


### Requirement: 布局项路径校验

系统 SHALL 在保存布局前校验每个菜单项的 `path` 属于当前租户可用真实菜单，且一个布局内不得重复引用同一路径。

#### Scenario: 保存有效布局

- **WHEN** 布局中的所有菜单路径有效且互不重复
- **THEN** 系统 SHALL 保存布局及其嵌套顺序

#### Scenario: 保存失效路径

- **WHEN** 布局项引用不存在或不可用的菜单路径
- **THEN** 系统 SHALL 拒绝保存并指出失效路径

### Requirement: 当前租户有效布局读取

系统 SHALL 在授权菜单输出阶段读取当前租户首条 `TenantCustomMenu`；仅在其 `itemList` 非空时使用该布局生成展示菜单。没有记录或其 `itemList` 为 `null` 或空集合时，系统 SHALL 使用原始菜单树。

#### Scenario: 存在非空布局

- **WHEN** 当前租户首条布局的 `itemList` 非空
- **THEN** 授权菜单接口 SHALL 将该布局作为当前租户的自定义展示清单

#### Scenario: 不存在有效布局

- **WHEN** 当前租户没有布局记录，或首条布局的 `itemList` 为 `null` 或空集合
- **THEN** 授权菜单接口 SHALL 回退到原始菜单树

### Requirement: 域名专属自定义菜单

系统 SHALL 支持为同一租户的不同域名维护独立的 `TenantCustomMenu`。`domain` 为空的布局表示租户公共布局。

#### Scenario: 当前域名存在专属布局

- **WHEN** 当前租户存在 `domain` 等于当前访问域名的非空布局
- **THEN** 授权菜单接口 SHALL 优先使用该域名专属布局

#### Scenario: 当前域名没有专属布局

- **WHEN** 当前租户不存在当前域名的非空布局
- **AND** 存在 `domain` 为空的非空租户公共布局
- **THEN** 授权菜单接口 SHALL 使用租户公共布局

### Requirement: 布局不改变真实菜单授权

系统 SHALL 将布局限于展示层；它不得修改真实菜单的父子关系、路由路径、资源标识或授权结果。

#### Scenario: 布局包含无权菜单

- **WHEN** 当前用户无权访问布局中引用的某个菜单
- **THEN** 系统 SHALL 在预览和后续导航解析时不展示该菜单及其空分组

### Requirement: 自定义菜单路由访问边界

当当前租户存在非空自定义菜单布局时，系统 SHALL 仅注册该布局中已授权菜单对应的前端页面路由；未包含的页面不得因前端路由映射自动补齐而变为可访问。

#### Scenario: 直接访问未包含菜单的地址

- **WHEN** 用户在地址栏输入未出现在当前自定义菜单展示树中的页面路径
- **THEN** 前端 SHALL 进入无权限页
- **AND** 不得渲染该页面的业务内容
