# Add file resource preview view

## Why

The file resource page currently focuses on table maintenance. Operators can manage records, but browsing media and documents requires opening individual rows or raw URLs. The page needs a dedicated preview-oriented view so users can inspect mixed file resources more naturally and later download selected resources as a client-side archive.

## What Changes

- Rename the menu title to `文件资源库`.
- Add two page views for the file resource page: `列表` and `资源预览`.
- Keep the existing CRUD table as the `列表` view.
- Add a `资源预览` view that renders file resources as cards and supports resource-type filtering.
- Render previews by resource type:
  - Image resources show thumbnails and image preview.
  - Video resources show a cover or type placeholder and video preview.
  - Audio resources show an audio preview.
  - PDF documents use browser preview where possible.
  - Zip and other unsupported resources use a generic file preview with download/open actions.
- Add client-side batch archive download in the preview view:
  - Users can select multiple resource cards.
  - The frontend fetches selected resource URLs, packages them into a zip archive, and downloads the archive.
  - The archive includes a `manifest.json` with resource metadata and per-file success/failure details.
  - Individual file download failures do not block the archive download.
- Add several default image `FileRes` records during module data initialization so the preview view has usable image samples after startup.
- Reuse the existing file resource API and existing frontend download utility.

## Impact

- Affects the oak base admin file resource page and menu title.
- Affects backend module data initialization for `FileRes` sample image records.
- Adds one frontend zip packaging dependency unless an equivalent dependency is already available during implementation.
- Does not require a new backend archive endpoint.
- Does not change existing list querying, create, edit, delete, detail, or upload behavior.
