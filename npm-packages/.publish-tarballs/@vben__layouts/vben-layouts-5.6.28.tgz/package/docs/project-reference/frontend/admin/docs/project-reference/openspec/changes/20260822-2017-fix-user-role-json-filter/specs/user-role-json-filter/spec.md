## ADDED Requirements

### Requirement: 用户角色 JSON 权限过滤

系统 SHALL 在用户列表权限过滤中使用 JSON 字段对应的包含匹配操作，而不是将 `User.roleList` 作为普通字符串执行 `LIKE` 或 `NOT LIKE`。

#### Scenario: 租户管理员刷新用户列表

- **WHEN** 非超级管理员请求用户列表
- **THEN** 系统 SHALL 排除包含超管或 SaaS 管理员角色的用户
- **AND** 角色过滤 SHALL 在 JSON 数组路径上执行
- **AND** 查询 SHALL 不因 JSON 集合字段的字符串 `LIKE` 类型错误而失败

#### Scenario: 超级管理员查询用户列表

- **WHEN** 超级管理员请求用户列表
- **THEN** 系统 SHALL 保持现有可见范围，不追加超管角色排除条件
