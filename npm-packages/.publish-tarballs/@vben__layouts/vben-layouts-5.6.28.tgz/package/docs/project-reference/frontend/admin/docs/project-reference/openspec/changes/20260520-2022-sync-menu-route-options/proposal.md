# Sync Menu Route Options

## Why

The upload page route modal needs per-row control over whether existing backend menus should be overwritten and whether uploaded menus should be enabled. The current modal only supports selecting routes and editing text fields, and the backend only updates page location fields for an existing menu matched by `moduleId + path`.

## What Changes

- Increase the upload page route modal width to about 85% of the viewport.
- Name the existing upload selection checkbox column `是否上传`.
- Add `是否覆盖` and `是否启用` checkbox columns to the route upload tree table.
- Make all three checkbox columns support tree-style cascading selection and indeterminate parent state.
- Include the new per-row `overrideExisting` and `enable` options in the upload payload.
- Make the backend honor `overrideExisting` by matching the menu unique constraint shape: parent id, page type, path, and name.
- When overwriting an existing menu, fields explicitly uploaded by the client may overwrite the old menu; fields not uploaded by the client must keep the existing backend value.
- Make the backend honor `enable` when creating or updating uploaded local page menus.

## Impact

- Affects the framework upload page route modal.
- Affects `Menu/syncMenu` request DTO and synchronization behavior.
- Existing menus are only overwritten when the new option is selected for that uploaded row.
