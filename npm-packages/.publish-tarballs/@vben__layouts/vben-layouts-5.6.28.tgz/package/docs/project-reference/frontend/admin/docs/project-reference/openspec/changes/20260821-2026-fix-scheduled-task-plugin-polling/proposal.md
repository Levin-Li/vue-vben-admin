## Why

Redis 调度器的四个每秒运行入口会重复解析服务插件配置；即使没有任何业务定时任务，也会持续触发对同一 `RedisScheduledTaskScheduler` 插件设置的读取，造成无效数据库与缓存负载。

## What Changes

- 缓存调度器插件的可用状态和 Redis 调度器运行时配置，避免在每秒轮询中重复解析插件配置。
- 在服务插件或服务插件设置发生创建、更新、删除事件时，使本地缓存失效；下一次调度入口重新解析并应用新配置。
- 为缓存复用和变更失效添加单元测试。

## Capabilities

### New Capabilities

- `scheduled-task-plugin-runtime-cache`: 调度器插件运行时配置的按需加载与事件失效。

### Modified Capabilities

- 无。

## Impact

- 后端：调度器插件公共基类、Redis 调度器及其测试。
- 数据库与接口：不修改表结构、CRUD 接口或权限。
- Redis 消息流：`MessageBroker-*` 线程池与 Redis Stream 消费逻辑保持不变。
