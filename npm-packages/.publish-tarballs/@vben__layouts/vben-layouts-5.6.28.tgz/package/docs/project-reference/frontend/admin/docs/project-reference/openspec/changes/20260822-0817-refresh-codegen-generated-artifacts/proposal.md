## Why

`simple-dao-codegen` 更新后，现有默认服务、请求对象和信息对象仍使用旧模板产物，无法获得生成器对集合 JSON 查询条件和字段安全注解的最新支持。

## What Changes

- 使用更新后的 `simple-dao-codegen` 全量刷新可安全覆盖的默认生成文件。
- 为集合 JSON 查询条件生成 `@ForceSplitCondition`，保持每个集合条件独立组合。
- 将实体字段的可复制安全注解同步到生成的信息对象。

## Impact

- `services`、`services-impl` 中受 `code-gen.md` 保护的默认生成代码。
- 不修改业务服务、业务控制器或被生成器识别为非模板内容的文件。
