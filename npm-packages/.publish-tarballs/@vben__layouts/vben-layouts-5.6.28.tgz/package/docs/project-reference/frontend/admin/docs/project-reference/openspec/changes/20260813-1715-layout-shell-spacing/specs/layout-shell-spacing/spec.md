## ADDED Requirements

### Requirement: Layout shell spacing preferences
The system SHALL provide independent four-direction margin, four-direction
border-width, and four-corner radius preferences for the sidebar, header, and
main content shell.

#### Scenario: Zero-value defaults
- **WHEN** preferences are first initialized or reset
- **THEN** every new margin, radius, and border-width value is `0`
- **AND** no rounded corner or border is applied by these new settings.

#### Scenario: Live update and persistence
- **WHEN** a user updates one of the layout shell parameters in the preference drawer
- **THEN** only its target shell updates immediately
- **AND** the value remains after a page refresh.

#### Scenario: Compact directional controls
- **WHEN** a user opens layout shell settings
- **THEN** each directional group is displayed in one row
- **AND** its decrement and increment controls appear while the input is hovered.

### Requirement: Base layout background customization
The system SHALL let users optionally customize the base background color of
the outermost layout container.

#### Scenario: Live background preview
- **WHEN** a user enables and changes the base background color
- **THEN** the outer layout container updates immediately
- **AND** exposed outer-margin areas use the configured color
- **AND** the preference remains after a page refresh.
