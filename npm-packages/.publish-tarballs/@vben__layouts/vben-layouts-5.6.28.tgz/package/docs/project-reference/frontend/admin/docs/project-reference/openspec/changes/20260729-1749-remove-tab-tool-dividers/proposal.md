# Remove tab tool button dividers

## Summary

Adjust the admin frontend tab bar so the right-side tool buttons no longer use vertical divider lines between adjacent buttons.

## Scope

- Remove the internal left borders between the tab bar tool buttons.
- Keep the tool group sizing, hover state, icon color, and click behavior unchanged.
- Keep the visual boundary between the active tabs area and the tool button group.

## Acceptance

- The top tab bar right-side tool buttons are displayed without vertical separators between the buttons.
- The refresh and fullscreen controls continue to work as before.
