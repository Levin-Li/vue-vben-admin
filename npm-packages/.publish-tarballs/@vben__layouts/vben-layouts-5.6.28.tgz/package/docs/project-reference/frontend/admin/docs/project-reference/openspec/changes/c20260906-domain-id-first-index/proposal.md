## Why
包含 domainId 的实体需要统一声明域查询索引，包括从父类继承该属性的实体。

## What Changes
- 扫描所有生产 JPA 实体及完整父类链。
- 将 `@Index(columnList = E_实体类名.domainId)` 放在 `@Table.indexes` 第一项；已有同类单列索引移至首位，避免重复。
- 保留其他索引和唯一约束。
- 自动生成字段字典时，按实体完整类名匹配所属插件包名，并写入匹配插件的 ID 作为 `domainId`。

## Capabilities
### New Capabilities
- `domain-id-first-index`: 所有具有 domainId 字段的实体统一首位索引。

## Impact
实体索引元数据、必要生成产物及自动字段字典的领域归属；不执行数据库 DDL，不修改外部依赖项目或工作区已有业务变更。
