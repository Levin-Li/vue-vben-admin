# Traffic Control Pattern Editor

## Motivation

`TrafficControlRule` already has multiple wildcard list fields for URL, method, domain, region, IP, user type, user role, and limit dimensions. These fields currently use a page-local editor and duplicate wildcard matching logic. After introducing the shared wildcard pattern editor, traffic-control rule editing should use the common editor so matching behavior, JSON array output, and immediate testing stay consistent across modules.

## Scope

- Replace traffic-control string-list wildcard editors with the shared `PatternListEditor`.
- Keep request parameter and header name/value JSON rules editable as structured JSON, while reusing shared wildcard matching behavior for their test logic.
- Preserve existing remote option loading for controller paths, tenant site domains, role options, and dictionary options.
- Keep backend payload compatibility: string-list fields are submitted as arrays and name/value rule fields remain JSON arrays.

## Out Of Scope

- No backend schema or DTO changes.
- No change to rate-limit runtime semantics.
- No forced migration of existing stored rule values.
