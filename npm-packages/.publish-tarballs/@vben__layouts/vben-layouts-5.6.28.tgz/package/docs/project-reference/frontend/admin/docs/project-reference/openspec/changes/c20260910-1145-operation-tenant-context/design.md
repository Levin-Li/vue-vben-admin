## Context

现有 `BizTenantService#getCurrentDomainTenant()` 保存当前域名解析出的租户；`checkCurrentUserTenantInfo()` 对有归属租户的登录用户执行“身份租户必须等于域名租户”的安全校验。平台用户没有归属租户，可以通过域名进入不同租户场景。当前全局组织与用户选择器只处理 `orgId`、`orgIdList` 和 `ownerId`，不维护操作租户。

## Terms

| 名称 | 含义 | 可信来源 |
| --- | --- | --- |
| 域名租户 | 当前请求 Host 绑定并审计后的租户 | 服务端域名解析 |
| 用户归属租户 | 当前已认证用户记录的 `tenantId` | 认证会话中的用户信息 |
| 请求操作租户 | 本次业务读取、写入、权限和组织候选的租户边界 | 服务端解析规则 |

三者不能互相别名。平台用户的用户归属租户为空是合法状态；未显式选择跨租户时，请求操作租户不是空，而是域名租户。

## Public service contract

后续实现应在 `BizDataScopeContextService` 提供以下方法：

```java
TenantInfo getCurrentDomainTenant();
TenantInfo getCurrentUserTenant();
TenantInfo getCurrentRequestTenant();
DataScopeInfo getCurrentRequestDataScope();
```

- `getCurrentDomainTenant()`：只返回服务端从当前 Host 解析和审计后的租户。适用于登录、域名站点、URL ACL、验证码和域名级配置。
- `getCurrentUserTenant()`：只返回当前认证用户的归属租户；平台用户返回 `null`。不得读取客户端 `tenantId`，也不得用域名租户替代用户归属。
- `getCurrentRequestTenant()`：返回当前业务请求应操作的租户。业务服务、数据范围、组织候选和配置解析默认必须使用此方法；不允许自行回退到域名租户或用户租户。
- `getCurrentRequestDataScope()`：返回经服务端验证的完整数据范围，包括 `DomainObject.domainId`、三个租户 ID、组织范围和选中用户。它不修改认证会话或普通 DTO。

## Header protocol

前端可在业务请求中发送以下候选 Header：

```text
X-Oak-Domain-Id
X-Oak-Tenant-Id
X-Oak-Org-Id
X-Oak-Org-Id-List
X-Oak-Owner-Id
```

`X-Oak-Org-Id-List` 使用 Base64URL 编码的 JSON 字符串数组，不是加密。Header 只表达候选数据范围，服务端必须解析当前 Host、认证用户和实际租户后再校验；未发送 Header 时不代表空租户，而是按域名租户解析请求操作租户。`X-Oak-Domain-Id` 对应业务对象的 `DomainObject.domainId`，作为关联领域筛选独立保存，不能与 Host 解析出的域名租户或 `TenantInfo.domainId` 比较。`X-Oak-Org-Id` 存在时必须属于 `X-Oak-Org-Id-List`；未传列表但传单个组织时，服务端可以派生单元素列表。

`X-Oak-Owner-Id` 只表示业务筛选用户，不得映射到当前认证用户、`_operatorId` 或 `InjectConst.USER_ID`。服务端必须验证该用户、所有组织都属于请求操作租户，且选中用户组织属于选中组织范围。

## Request operation tenant resolution

```text
resolveDomainTenant(host) → D
resolveAuthenticatedUser() → U
resolveUserTenant(U) → A
resolveExplicitOperationTenant() → S

非平台用户：要求 A == D；请求操作租户 = D
平台用户且 S 未选择：请求操作租户 = D
平台用户且 S 已选择：校验 U 的平台身份和 S 存在；请求操作租户 = S
```

域名没有绑定有效租户时，要求租户上下文的请求失败。非平台用户的 `A != D` 必须拒绝并退出当前会话，不能由前端选择器或请求参数修复。当前实现以 `operator.isPlatformUser()` 作为跨租户的授权边界，并验证目标租户存在；后续新增平台用户与租户的细粒度授权关系时，应替换该平台身份校验，不改变 Header 协议和数据范围模型。前端传来的租户 ID 只作为候选，不能成为授权依据。

## Organization and user selection

组织和用户候选加载必须使用 `getCurrentRequestTenant()`，并验证：

- 选中的组织属于请求操作租户；
- 选中的用户属于请求操作租户，且其组织也属于该租户；
- 非平台用户不能通过选择器选择其它租户的组织或用户；
- 未选择组织/用户只表示没有附加筛选，不能改变请求操作租户。

全局选择器如需支持平台用户跨租户，应新增明确的操作租户选择状态并通过 `X-Oak-*` Header 作为候选请求上下文。不得继续借用 URL 参数中的 `tenantId`、`orgId`、`orgIdList` 或 `ownerId` 实现租户切换；这些字段分别可能承担数据筛选、数据归属或个人范围语义。

## Enforcement order

1. Web 入口解析并审计域名租户。
2. 认证完成后解析用户归属租户。
3. 服务端解析并缓存请求操作租户。
4. 资源授权、组织范围、业务 DTO 注入、服务查询和写入都读取请求操作租户。
5. 组织/用户选择只能在步骤 3 成功后处理。

所有步骤在同一请求内保持不可变；异步任务、消息消费和定时任务没有 HTTP Host 时，必须由可信任务上下文显式提供请求操作租户，不能依赖 ThreadLocal 遗留值。
