## Why

Several business services create new ID request objects after receiving an already scoped request. The new objects can drop tenant, organization, or owner filters before downstream reads or writes. SSL certificate download is the most sensitive example because it returns the private key.

## What Changes

- Preserve the validated request scope when SSL certificate, domain DNS, tenant-site domain, and electronic-invoice services create downstream ID or update requests.
- Preload a tenant site through the caller's scoped request before changing its domain.
- Give electronic-invoice red-issue requests the same organization and personal scope as the invoice entity, then use that scope for related invoice, partner, legal-subject, and provider-connection lookups.
- Add focused tests that assert every recreated request retains the original scope.

## Impact

Changes only business-service request propagation and tests. No new APIs, persistence fields, dependencies, or migrations.
