## ADDED Requirements

### Requirement: Org 的唯一外部主体关联

Org MUST 使用 `externalLegalSubjectId` 作为唯一的外部法人、机构或个体关联，MUST NOT 再持久化或公开 `partnerId`。

#### Scenario: 创建或更新组织

- **WHEN** 管理员为组织选择外部法律主体
- **THEN** 系统 SHALL 仅保存 `externalLegalSubjectId`

### Requirement: 从法律主体派生合作伙伴类型

菜单与运行时 UI 设置需要组织合作伙伴类型时，系统 MUST 使用该 Org 的 `externalLegalSubjectId` 查询同主键的 Partner，并在 Partner 不存在时按无合作伙伴类型处理。

#### Scenario: 外部法律主体是合作伙伴

- **WHEN** Org 的 `externalLegalSubjectId` 对应一个 Partner
- **THEN** 系统 SHALL 使用该 Partner 的 `subCategory` 进行菜单与 UI 设置匹配

#### Scenario: 外部法律主体不是合作伙伴

- **WHEN** Org 的 `externalLegalSubjectId` 没有对应 Partner
- **THEN** 系统 SHALL 使用通用菜单与 UI 设置匹配，且不得报错

### Requirement: 旧 Org 关联数据迁移

迁移 MUST 在 `external_legal_subject_id` 为空时从旧 `partner_id` 回填，且不得覆盖已有法律主体关联；完成审计后必须移除旧 `partner_id` 列。

#### Scenario: 旧组织尚未迁移法律主体关联

- **WHEN** `external_legal_subject_id` 为空且 `partner_id` 有值
- **THEN** 迁移 SHALL 将旧值写入 `external_legal_subject_id`

### Requirement: 机构页面的法律主体选择

机构管理页面的新增、编辑和查询 MUST 使用 `externalLegalSubjectId`，并使用法律主体名称的后端查询参数进行远程搜索。

#### Scenario: 按名称搜索外部法律主体

- **WHEN** 管理员在外部法律主体选择框输入关键字
- **THEN** 页面 SHALL 使用 `containsSubjectName` 请求法律主体列表并展示匹配项

### Requirement: 机构页面的必填输入

机构管理页面 MUST 将实体非空的 `category` 标记为必填。

#### Scenario: 新增机构

- **WHEN** 管理员未填写机构类别
- **THEN** 页面 SHALL 阻止提交并提示该字段必填
