# Preserve Frontend Home Path Route Fallback

## Why

When a user opens a URL that has no matching frontend route, the admin app should fall back to the user's configured home page, such as the photography workspace, instead of redirecting to the root path `/`.

The current frontend user-info normalization overwrites the backend-provided home path with `/`, so route recovery cannot use the user's actual landing page.

## What Changes

- Preserve `homePath` returned by backend user info.
- Keep `/` only as the fallback when backend user info does not provide a usable home path.
- Add a focused regression test for user-info normalization.

## Impact

- Affects login and route-recovery redirects that depend on `userInfo.homePath`.
- Does not change menu generation or static route definitions.
