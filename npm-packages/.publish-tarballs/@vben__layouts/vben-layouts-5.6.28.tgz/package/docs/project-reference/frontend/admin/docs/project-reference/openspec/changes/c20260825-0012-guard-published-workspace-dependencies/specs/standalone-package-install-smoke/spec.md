## ADDED Requirements

### Requirement: 发布前独立安装烟测

每个待发布公共包的 tarball MUST 在临时、非 workspace 项目中完成 `pnpm install`。烟测项目 MUST 只通过 tarball 引用待发布包，不得引用本仓库的 workspace、link 或 overrides；内部 `@vben`、`@vben-core` 与 `@levin` 依赖 MUST 走配置的私服，第三方依赖 MUST 走项目默认公共 registry。

#### Scenario: 独立消费者安装

- **WHEN** 发布流程生成待发布公共包 tarball
- **THEN** 临时消费者项目能通过私服安装该 tarball 及其依赖
