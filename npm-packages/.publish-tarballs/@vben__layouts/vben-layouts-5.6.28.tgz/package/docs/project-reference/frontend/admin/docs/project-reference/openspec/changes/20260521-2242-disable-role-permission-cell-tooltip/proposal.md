# Disable Role Permission Cell Tooltip

## Why

角色管理列表的“资源权限列表”列内容较长时会自动显示悬浮提示。该列经常包含权限表达式，鼠标移上去的大浮层会遮挡相邻列和当前表格阅读区域。

## What Changes

- 为通用 CRUD 表格字段配置增加单元格 Tooltip 开关。
- 在角色管理的“资源权限列表”列关闭单元格 Tooltip，但保留原有截断展示。

## Impact

- 仅影响显式配置关闭 Tooltip 的表格字段。
- 不改变角色资源权限数据、接口提交和权限分配弹窗行为。
