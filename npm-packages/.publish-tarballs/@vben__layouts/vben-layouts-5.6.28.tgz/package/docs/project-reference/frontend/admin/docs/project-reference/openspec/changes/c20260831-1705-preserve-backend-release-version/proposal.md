## Why

后端 Maven 发布版本由用户负责最终决定和手动修改。无论当前是快照还是正式版本，Agent 因发布动作自动修改根 `revision`，都会扩大发布范围并改变既有部署与依赖约定。

## What Changes

- 明确后端发布版本（根 `revision`）只能由用户手动修改；Agent 不得因发布动作自动递增、替换、恢复或覆盖该版本号。
- 后端发布请求、用户口头要求“发布”或 OpenSpec 版本记录均不构成 `revision` 修改授权；Agent 只能使用用户已手动写入工作区的发布版本。
- 此约束不限制有明确开发需求的依赖版本、模块 POM 版本、版本属性或生成版本常量维护。
- 保留发布前依赖闭包、构建、私服反查以及发布成功后的提交和推送要求。

## Capabilities

### New Capabilities

- `backend-snapshot-release-version-preservation`: 约束后端 Maven 发布复用用户已手动写入的根 `revision`，禁止发布流程隐式修改发布版本。

### Modified Capabilities

- 无。

## Impact

- 影响根目录发布约束和后端 Maven 构件发布规则。
- 不改变业务接口、数据模型、前端构件或既有 Maven 发布顺序。
