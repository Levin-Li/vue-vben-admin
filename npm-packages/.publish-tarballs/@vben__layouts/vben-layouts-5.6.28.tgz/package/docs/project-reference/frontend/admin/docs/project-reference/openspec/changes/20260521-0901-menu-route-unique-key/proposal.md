# Menu Route Unique Key

## Why

Uploading frontend page routes can create duplicate local page menu rows when the module id, page type, and path are the same but the display name differs. The sync lookup currently treats `overrideExisting` as part of the lookup branch and can match by parent, page type, path, and name, while the route identity should be determined by the database uniqueness rule.

## What Changes

- Change the menu entity unique constraint for page routes to `tenantId + moduleId + pageType + path`.
- Make page route sync use `moduleId + pageType + path` as the existing-record lookup key for uploaded local page routes.
- Keep `overrideExisting` only as the flag that decides whether matched records may receive uploaded field updates.
- Keep missing uploaded fields from overwriting existing backend values.
- Resolve parent ids through the uploaded tree before applying the current menu's parent id.

## Impact

- Affects menu entity metadata and generated DDL expectations.
- Affects backend `Menu/syncMenu` lookup and overwrite behavior.
- Existing duplicate rows with the same route key may need data cleanup before applying the database constraint in an environment that already contains duplicates.
