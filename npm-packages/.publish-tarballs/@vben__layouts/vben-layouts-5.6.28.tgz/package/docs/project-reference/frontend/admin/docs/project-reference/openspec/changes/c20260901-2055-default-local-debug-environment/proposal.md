## Why

本地联调按默认开发 profile 启动会偏离调用者期望的本机数据与配置，且现有启动说明与团队约定不一致。需要把本地调试的默认环境明确为 `local`，减少每次启动时的环境选择歧义。

## What Changes

- 将管理后台后端启动说明中的默认 profile 从 `env1-dev` 改为 `env0-local`。
- 规定启动本地前后端时默认使用 `local` 环境；用户明确指定其它环境时，以指定值为准。
- 说明本地后端编译与运行必须使用同一个 Maven profile，避免资源过滤结果与 Spring 运行参数不一致。

## Capabilities

### New Capabilities

- `local-debug-environment-default`: 统一项目本地前后端调试的默认环境选择与覆盖规则。

### Modified Capabilities

- 无。

## Impact

- 更新根目录的后端启动说明。
- 不改变业务接口、数据模型、前端运行逻辑或外部依赖。
