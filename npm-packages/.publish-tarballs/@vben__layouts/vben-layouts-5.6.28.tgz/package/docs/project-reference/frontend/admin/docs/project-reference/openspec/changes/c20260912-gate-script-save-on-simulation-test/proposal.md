## Why

The API script editor currently permits a user to confirm a script save before a successful simulation result is visible. A failed or untested script can therefore be accepted as an intentional save.

## What Changes

- Require a successful simulation test for the current API-script draft before enabling the editor modal's Save action.
- Show a dedicated three-state simulation indicator while preserving the simulation-test action's name and appearance: untested on entry, passed after success, and failed after an error or a draft edit.
- Invalidate that passed state whenever the script or any saved runtime configuration changes.

## Capabilities

### New Capabilities

- `api-script-simulation-save-gate`: Gate intentional API-script saves on a successful simulation of the exact draft.

### Modified Capabilities

None.

## Impact

The managed API simple-content editor in `frontend/admin` and its focused Vitest coverage. No API authorization, server-side execution boundary, or script-test transport contract changes.
