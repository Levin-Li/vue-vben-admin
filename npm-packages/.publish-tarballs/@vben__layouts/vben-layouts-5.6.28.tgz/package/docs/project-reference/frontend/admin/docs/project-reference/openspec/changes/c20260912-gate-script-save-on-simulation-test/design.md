## Context

The API simple-content editor already has a simulation path and result console, but the modal confirmation button is independently available. Script content and simulation configuration are all persisted by the same final update action.

## Goals / Non-Goals

**Goals:**

- Make an untested or failing current script draft impossible to intentionally save through the editor confirmation action.
- Give a clear green visual acknowledgement after a successful simulation.
- Ensure a subsequent draft change requires another simulation.

**Non-Goals:**

- Change backend authorization or dynamic-script execution rules.
- Treat a transport response alone as success when its structured body reports failure.
- Gate non-script content editors.

## Decisions

- Derive a reactive fingerprint from every value included in the API script editor's final save payload. A simulation approval is valid only while its fingerprint equals the current fingerprint.
- Record the fingerprint only when the simulation response is not a structured failure. Parse errors and request failures do not approve a draft.
- Bind the modal confirmation button's disabled state to that approval. Keep the simulation action unchanged and render a separate indicator beside it: no passed/failed label on entry, green after success, red after a failed attempt or a draft change.

## Risks / Trade-offs

- A user must repeat a simulation after any configuration edit, including request schema or timeout. This is intentional because these values are saved with the script and influence the simulation context.
- The gate is a client-side workflow safeguard; existing server-side authorization remains the security boundary.
