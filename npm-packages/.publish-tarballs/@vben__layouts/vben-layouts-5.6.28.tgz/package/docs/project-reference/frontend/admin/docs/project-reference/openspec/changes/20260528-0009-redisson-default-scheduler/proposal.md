# Proposal: Redisson Default Scheduler

## Summary

Make Redis the default scheduler for configurable scheduled tasks and implement the Redis scheduler through Redisson primitives. PowerJob and XXL-JOB remain modeled as optional external scheduler types. Redis is the built-in default scheduler, and PowerJob is integrated in this change through its OpenAPI client and a local processor bridge.

## Motivation

The current scheduled-task module has CRUD fields and an unfinished execution stub, but it does not register jobs with any scheduler or execute them reliably. Product usage also needs each business object, such as an electronic paper, to define its own scheduler and execution handler. Redis is already a project dependency through Redisson, so a built-in Redis scheduler avoids adding another required platform while preserving extension points for PowerJob and XXL-JOB.

## Scope

- Add scheduler selection fields to `ScheduledTask`, with `Redis` as the default scheduler.
- Add business binding fields so one electronic paper or other business object can own its own task definition.
- Add scheduler runtime fields for handler name, scheduler job id, structured scheduler config, run parameters, misfire policy, timeout, retry settings, and task version.
- Implement the first Redis scheduler adapter with Redisson.
- Implement the PowerJob adapter for registering, enabling, disabling, and deleting scheduled tasks in PowerJob.
- Add a PowerJob processor bridge that routes PowerJob executions back to the scheduled-task business execution service.
- Support multi-node scheduling without a single elected leader.
- Use database records as the task fact source and Redis only as a rebuildable runtime index.
- Write scheduled execution logs and update task execution metadata.
- Regenerate default service/controller request and info classes through `simple-dao-codegen`.
- Expose the new fields in the admin scheduled-task CRUD page.

## Non-Goals

- Do not require XXL-JOB servers in the first implementation.
- Do not implement full XXL-JOB client registration in this change.
- Do not guarantee distributed exactly-once execution; first version provides at-least-once dispatch with task-cycle idempotency.
- Do not replace existing hard-coded Spring `@Scheduled` maintenance jobs.

## Risks

- Redis outage can pause the built-in scheduler. The DB remains the fact source, and the Redis index must be rebuilt on recovery.
- PowerJob integration depends on configured PowerJob server addresses, app name, and password. Missing PowerJob configuration should fail the external scheduler operation clearly without blocking Redis scheduler usage.
- User-provided script execution remains high risk. Script-like execution content continues to require privileged backend validation before non-admin usage is broadened.
- Long-running tasks may exceed lock TTL. Task timeout and retry fields are modeled so later runtime behavior can be tightened.
