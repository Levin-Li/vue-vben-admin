## Requirements

### Requirement: 后台管理模块具有固定首页

管理端必须为后台管理模块的根路径定义实际首页组件，不得依赖用户上次访问记录或系统默认首页决定模块入口落点。

#### Scenario: 直接访问后台管理模块根路径

- **WHEN** 已登录用户访问 `/clob/V1/index`
- **THEN** 直接显示后台管理模块注册的概览页面

### Requirement: 模块首页页面归属模块

后台管理模块首页的组件、页面工具函数和页面测试必须属于 `oak-base-admin` 模块；后端路由映射必须指向该模块的实际页面。

#### Scenario: 同步后台管理模块首页路由

- **WHEN** 前端同步 `/clob/V1/index` 的后台管理菜单路由
- **THEN** `sourceFilePath` 为 `modules/com_levin_oak_base/views/home/index.vue`
- **AND** `viewPath` 为 `/system/com_levin_oak_base/home/index.vue`

### Requirement: 模块首页不属于 CRUD 路由生成器

后台管理模块首页是模块专属页面，不属于 CRUD 资源路由。

#### Scenario: 组装模块路由

- **WHEN** 创建后台管理前端模块
- **THEN** 模块专属路由定义提供 `/clob/V1/index` 的默认首页子路由
- **AND** `admin-crud.ts` 只生成 CRUD 资源子路由

### Requirement: 应用根路径直接进入后台管理模块首页

应用根路径必须通过 Bootstrap 的 `defaultHomePath` 直接进入后台管理模块的固定首页。

#### Scenario: 访问应用根路径

- **WHEN** 已登录用户访问 `/`
- **THEN** 根路由直接指向 `/clob/V1/index`
