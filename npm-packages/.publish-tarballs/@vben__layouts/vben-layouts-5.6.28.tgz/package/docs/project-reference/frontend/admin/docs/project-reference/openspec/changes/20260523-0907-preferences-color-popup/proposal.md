# Preferences Color Popup

## Why

The preferences appearance tab currently expands color controls inline. The built-in theme palette takes too much vertical space, and the semi-dark area color controls rely on native color inputs only. Users need a compact entry that opens a dedicated color selection popup, with an explicit way to clear color settings back to defaults.

## What Changes

- Move the built-in theme palette from the main appearance tab into a dedicated color settings popup.
- Let the semi-dark sidebar, semi-dark header, and main theme color entries reuse the same color picker popup as an editor, while preserving three independent target values.
- Keep the main appearance tab compact by showing color previews and an entry button instead of the full palette.
- Add text inputs for custom color values so users can type or paste a color value in addition to using the native color picker.
- Add a popup footer action to restore theme color settings to their default values.
- Preserve real-time preview behavior when users choose built-in themes, custom colors, or semi-dark area colors.
- Keep the popup compact and focused on choosing a color for the active target. Do not include the semi-dark area color form section in the popup.
- Rename the appearance tab section title from "颜色设置" to "主题色".
- Move the semi-dark sidebar/header color previews toward the middle of their rows.
- Show the matched color preset name beside the semi-dark sidebar/header preview, consistent with the main theme color entry.
- Rename the main color settings entry label from "颜色设置" to "主色".
- Expose the existing semantic theme colors for success, warning, and destructive states in the same color settings popup.

## Impact

- Affects the preferences drawer appearance tab.
- Affects the theme mode, semi-dark sidebar/header color, and built-in theme controls.
- Affects success, warning, and destructive theme color preferences that already drive generated CSS variables.
- Affects localized preferences text for the new popup, entry, color input, and reset action.
