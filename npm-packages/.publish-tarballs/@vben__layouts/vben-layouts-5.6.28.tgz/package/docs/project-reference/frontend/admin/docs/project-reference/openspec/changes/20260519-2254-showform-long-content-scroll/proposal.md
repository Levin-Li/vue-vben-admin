# ShowForm 长内容独占行和内部滚动

## Summary

调整 CRUD `ShowForm` 操作结果弹窗：长文本、代码、JSON 等大内容字段独占一整行，并在字段内容区域内部滚动。

## Motivation

在线代码生成的“生成百度 Amis 页面”结果中，`pageContent` 是大段 JSON/代码内容。当前 `ShowForm` 结果展示固定按两列排布，导致长内容被挤在右侧半栏，阅读困难，也没有遵守“长内容独占一行”的详情表单规则。

## Scope

- `ShowForm` 结果展示应优先匹配当前页面 `fields` 配置。
- 匹配到 `fullRow`、`span=-1`、`code`、`json`、`html`、`css`、`textarea` 等大内容字段时，字段卡片跨满整行。
- 大内容值使用独立内部滚动区域，避免撑高整个弹窗。
- 保持普通短字段的两列展示。

