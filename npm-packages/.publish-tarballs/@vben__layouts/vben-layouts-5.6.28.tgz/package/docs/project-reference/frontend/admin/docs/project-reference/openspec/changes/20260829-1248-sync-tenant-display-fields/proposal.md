# Sync tenant display fields into admin pages

## Why

Admin CRUD pages can lag behind their generated controller request models.
Operators then cannot view or maintain newly available fields.

## What Changes

- Compare every current admin-page controller's generated request model with
  its frontend CRUD page configuration.
- Add missing safe, operator-maintained fields using explicit static page
  configuration and nested mappings where required.
- Preserve the nested `siteInfo` request contract and ensure create and update
  payloads serialize correctly.
- Keep security-sensitive or runtime-only fields out of page forms unless an
  existing requirement explicitly permits them.

## Acceptance

- Every controller that has a corresponding management page appears in the
  audit result, with its page mapping and uncovered fields.
- Form payloads update `siteInfo` without sending dotted pseudo-properties to
  the backend.
- The audit records any intentionally absent fields and its reason.
