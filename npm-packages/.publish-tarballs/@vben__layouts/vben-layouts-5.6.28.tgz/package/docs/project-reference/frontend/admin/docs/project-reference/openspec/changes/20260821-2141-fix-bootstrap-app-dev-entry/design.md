## Context

通用 Vite 配置固定预热 `src/bootstrap.ts`。`bootstrap-app` 的应用初始化在 `src/main.ts` 中完成，缺少预热目标导致开发服务器对不存在模块报错。

## Goals / Non-Goals

**Goals:**

- 让开发服务器可以解析预热模块。
- 不在预热时执行应用挂载或网络请求。

**Non-Goals:**

- 不重构现有 `main.ts` 初始化流程。
- 不变更生产入口、路由或认证逻辑。

## Decisions

新增空模块 `src/bootstrap.ts` 作为 Vite 预热兼容入口。它不导入 `main.ts`，因此预热不会引入重复挂载副作用。

## Risks / Trade-offs

- [未来预热入口承载初始化逻辑] → 当前文件显式保持无副作用；真实初始化继续由 `main.ts` 唯一负责。
