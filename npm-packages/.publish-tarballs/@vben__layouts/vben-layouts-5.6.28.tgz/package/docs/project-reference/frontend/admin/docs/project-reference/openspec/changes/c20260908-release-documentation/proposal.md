## Why
用户要求本次全部变更发布并推送，并确认设计文档、开发规范随发布包交付。当前发布物仅含部分规范，需补齐可追溯设计资料。
## What Changes
前后端发布包携带项目设计文档、OpenSpec需求/设计/任务和开发规范。规范入口区分下游强制模块规范与发布方项目参考资料。构建核对实际tarball/JAR中的文件内容。修复新增prepack日志导致发布器JSON解析失败。
## Capabilities
### New Capabilities
- `release-documentation`: 发布文档完整性。
## Impact
根POM资源打包、发布README、前端文档同步和发布门禁及测试。
