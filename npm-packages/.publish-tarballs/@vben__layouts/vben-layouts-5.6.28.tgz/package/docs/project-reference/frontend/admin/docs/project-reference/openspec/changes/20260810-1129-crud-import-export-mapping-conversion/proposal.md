# Shared CRUD Import/Export Mapping and Conversion

## Why

The shared CRUD toolbar exposes import and export on many generic pages, but its current behavior is incomplete for real exchange files: export can rename a header but cannot persist or apply a value conversion, while import date/datetime conversions do not actually normalize or validate dates. The import dialog also rejects standard `.xlsx` files even though it is presented as an Excel import.

## What Changes

- Treat column header aliasing and source-to-target selection as explicit, reusable import/export mappings and persist the mappings in the existing template flow.
- Add a constrained shared conversion set for import and export: raw/trimmed text, number, boolean, date, datetime, and JSON where applicable.
- Validate and normalize date and datetime input before batch submission; report the row and target field when a conversion fails.
- Support ordinary first-sheet `.xlsx` import without adding a third-party dependency, while retaining CSV and the existing Excel XML/HTML parsing paths.
- Keep conversion declarative and template-backed; do not add arbitrary script evaluation or per-page hard-coded mapping logic.
- Load each import or export template selector with one exact visibility query instead of issuing compatibility and scope-variant requests, and identify the returned personal, organization, or tenant-owned templates in the selector.

## Impact

- Affects every page backed by the shared `CrudPage` component in `@levin/admin-framework`.
- Existing export templates without conversion settings preserve their current list-display export behavior.
- Existing import templates remain compatible and gain actual date/datetime conversion semantics.
