# Use image upload for pay-way logo

## Why

The pay channel page contains an embedded pay-way editor. Its `logo` field represents an image resource, but the current UI renders it as a plain text input. Operators need to upload and preview the pay-way logo instead of manually pasting an image URL.

## What Changes

- Replace the embedded pay-way `logo` text input with a single-image upload control.
- Upload through the existing `FileStorageController` frontend wrapper.
- Store the uploaded image URL back into the `logo` field so the existing pay-way payload shape remains unchanged.
- Show existing logo URLs as picture-card thumbnails and allow preview/removal.

## Impact

- Affects only the pay channel page embedded pay-way editor.
- Reuses existing file storage upload APIs; no backend API or payload schema change.
