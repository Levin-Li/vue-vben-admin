## Context

公共 CRUD 将字段元数据筛选为 `searchFields`，再归并日期范围等控件形成 `searchFieldItems`，模板仅渲染该最终集合。`EditableObject` 是后端接口能力，前端不应也无法直接识别 Java 接口，只能依据当前页面的字段元数据与实际控件决定行为。

## Goals / Non-Goals

**Goals:**

- 非平台用户仅在查询表单实际存在 `editable` 控件时，默认查询可编辑记录。
- 重置查询后保持相同的默认筛选。
- 仅在 CRUD 具有 `editable` 字段时，对非超管限制内置修改类操作。

**Non-Goals:**

- 不改动后端 `EditableObject`、接口参数契约或数据权限。
- 不为没有查询控件的页面隐式添加 `editable` 查询参数。
- 不限制详情操作。

## Decisions

- 使用最终的 `searchFieldItems` 判断可用控件，而不是原始 `fields` 或 `searchFields`。前者与查询表单实际使用的渲染及请求序列一致，能够排除不可渲染或被合并的字段。
- 将该判定与“当前 CRUD 是否支持 editable”分成两个独立的小型纯函数。查询默认只依赖可渲染查询控件；行操作限制只依赖 CRUD 是否声明了该字段。
- 以字符串 `'true'` 写入查询状态，保持与现有选择控件和请求序列化逻辑一致。

## Risks / Trade-offs

- [运行时字段元数据动态变化] → 查询控件集合重新计算时在加载前应用默认值；重置操作也再次应用。
- [不同页面 `editable` 类型不一致] → 复用现有选择控件的字符串序列化约定，不改变后端入参转换。
