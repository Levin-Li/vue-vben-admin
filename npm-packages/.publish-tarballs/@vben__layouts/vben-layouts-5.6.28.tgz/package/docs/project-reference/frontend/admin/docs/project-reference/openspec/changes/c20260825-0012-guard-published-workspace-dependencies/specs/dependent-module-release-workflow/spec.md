## ADDED Requirements

### Requirement: 基础模块消费者使用统一发布门禁

依赖 `@levin/admin-framework` 或 `@levin/oak-base-admin` 的任何可发布前端模块 MUST 通过仓库根目录标准发布器发布。通用模块 MUST 使用 `pnpm run publish:packages -- --only=<包名>`；基础管理模块自身 MUST 使用 `pnpm run publish:admin-modules -- --only=<包名>`。模块目录内 MUST NOT 直接执行 `npm publish` 或绕过 tarball、独立安装和私服回查门禁。

#### Scenario: 发布基础模块消费者

- **WHEN** 依赖基础模块的业务或公共模块需要发布
- **THEN** 发布命令通过仓库根目录标准发布器执行，并运行完整发布门禁

#### Scenario: 尝试绕过发布门禁

- **WHEN** 模块在子目录直接执行发布命令或使用自定义绕过脚本
- **THEN** 该操作不符合发布规则，不能作为正式发布流程
