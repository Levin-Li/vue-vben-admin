## Why

通用 CRUD 编辑表单会省略空的选择类字段，导致用户在界面中清空值后，请求没有该字段，服务端无法利用既有的 `autoForceUpdateField` 语义完成清空更新。页面因此散落维护 `forceUpdateFields`，既易遗漏也难以保持一致。

## What Changes

- 页面展示设置的“编辑表单”增加自动强制更新开关，默认开启；通用 CRUD 按该页面配置决定是否提交 `autoForceUpdateField: true`。
- 通用 CRUD 对当前编辑界面实际渲染的字段一律提交序列化后的值；空字符串、`null` 和空数组均不得因选择组件策略被省略。
- 编辑时清空行政区划级联选择器时，提交其关联字段的明确空值。
- 创建流程、隐藏字段和未启用的复杂属性分组维持现有不提交语义。
- 移除采用通用 CRUD 的设置页面中重复维护的 `forceUpdateFields` 兜底。
- 优化页面展示设置在“展示列表”页签切换时的表头初始化与预览更新，避免无变化配置触发重复响应式渲染。
- 为上述提交语义补充自动化测试。

## Capabilities

### New Capabilities

- `visible-form-empty-updates`: 通用 CRUD 编辑表单以页面可编辑字段为边界，支持将清空值作为明确更新提交。

### Modified Capabilities

- 无。

## Impact

- 前端公共包：`@levin/admin-framework` 的通用 CRUD 提交与行政区划级联值写入逻辑。
- 后端不改动，继续使用现有生成更新请求的 `autoForceUpdateField` 能力。
- 常规完整表单不再需要逐页维护 `forceUpdateFields`；手工局部更新仍保留原机制。
