## Context

仓库源码中的 `workspace:*` 由 pnpm 用于本地工作区解析，是正确的开发依赖声明。现有公共包发布脚本却通过 `npm pack` 生成 tarball，并且只校验动态路由资源；私服中的 Vben 包因此保留了消费者无法安装的 `workspace:*`。

## Goals / Non-Goals

**Goals:**

- 保留源码中的工作区依赖协议。
- 让发布 tarball 将工作区和目录协议转换为已发布的具体版本。
- 在本地 tarball、私服 tarball 和独立安装场景中阻止协议残留。
- 修复已受影响的 Vben 包并发布递增的补丁版本。

**Non-Goals:**

- 不改变公共包的 `dist` 运行入口或移除随包源码。
- 不在消费者项目添加 overrides、link 或其它临时兼容配置。
- 不重发未包含协议残留的公共包。

## Decisions

- 发布 tarball 统一由 `pnpm pack` 生成，`npm publish <tarball>` 仅负责上传该已验证 tarball。pnpm 会在打包阶段把 `workspace:` 转换为对应包的版本。
- 在公共发布门禁中解析 tarball 的 `package/package.json`，检查 `dependencies`、`optionalDependencies`、`peerDependencies` 和 `devDependencies`；任一值以 `workspace:` 或 `catalog:` 开头即失败。本地包和私服精确版本回查包均执行相同检查。
- 对每个待发布 tarball 创建临时、非 workspace 的最小项目，通过私服执行 `pnpm install --ignore-scripts`。这证明消费者不依赖当前工作区也可解析依赖。
- 独立安装烟测会暴露运行时依赖闭包中更深层的协议残留，因此递增并发布全部 Vben 公共包，而不是只修复最初被消费者直接安装的包。通用发布脚本按依赖拓扑顺序发布；`@levin/admin-framework` 的精确 Vben peer 约束会随之更新，必须递增并通过管理后台公共模块发布流程重发；`@levin/oak-base-admin` 的精确 `@levin/admin-framework` peer 约束也随之更新，必须递增并通过同一流程重发。
- 独立消费者安装使用双 registry：`@vben`、`@vben-core` 与 `@levin` 作用域走项目私服，第三方依赖走项目默认公共 registry；私服认证只写入临时消费者 `.npmrc`。
- 所有依赖 `@levin/admin-framework` 或 `@levin/oak-base-admin` 的可发布模块都必须从仓库根目录调用通用公共包发布器。该发布器已经继承依赖协议、独立安装与私服 tarball 门禁；基础模块自身继续使用管理后台公共模块发布器，二者均不得在子模块目录直接调用 `npm publish`。

## Risks / Trade-offs

- [独立安装需要访问私服] → 发布环境必须使用与上传相同的私服与认证配置，网络或认证失败时禁止发布。
- [一次发布多个相互依赖的包] → 先执行本地 tarball 和安装烟测，发布后逐包反查精确版本与 tarball，降低部分发布风险。
- [pnpm 的打包行为发生变化] → tarball 清单解析是最终门禁，不依赖对 pnpm 行为的假设。
