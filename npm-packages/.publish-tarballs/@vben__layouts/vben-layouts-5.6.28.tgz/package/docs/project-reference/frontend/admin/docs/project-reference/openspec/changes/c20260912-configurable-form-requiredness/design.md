## Context

`CrudFieldConfig.required` 表示后端或开发配置的既有必填约束，而页面展示设置仅保存字段展示和提交方式。新增和编辑必须有独立覆盖，且 UI 设置不能放宽原有约束。

## Decisions

- 在 `CrudPageDisplayFieldConfig` 增加 `required?: boolean`；仅 `true` 表示对原可选字段加严，省略或 `false` 均不改变原字段约束。
- 运行时有效必填性为 `field.required || display.required === true`。后端必填字段永远有效必填。
- 设置抽屉为新增、编辑字段提供“必填”复选框；原字段必填时固定选中并禁用，否则可切换。
- 隐藏提交的有效必填字段必须具有非空默认值；设置面板不允许保存无默认值的该组合，运行时仍保留提交前校验兜底。

## Non-Goals

- 不降低服务端或原始字段的必填约束。
- 不将该能力扩展到查询、详情、列表或后端 DTO。
