# 补齐国际化运行时资源模型

## 背景

国际化资源需要支持客户端按应用、应用版本、模块、终端、租户、站点、域名和语言等上下文获取运行时语言包。现有 `I18nRes` 只有 `tenantId/moduleId/domain/languageCode/nationCode/resKey/label` 等基础字段,不能明确区分应用、应用版本、终端和站点维度。

## 变更范围

- 在 `I18nRes` 实体中新增 `appCode`、`appVersion`、`terminalType`、`siteId` 四个运行时匹配维度,并补充可选长文本资源值 `resValue`。
- 在 `I18nRes` 实体中新增 `TerminalType` 枚举,枚举必须添加 `@GenNameConstant`。
- 调整 `I18nRes` 的索引、唯一约束和租户覆盖键,让匹配维度按从大到小收敛:应用、应用版本、模块、终端、租户、站点/域名、语言、资源键。
- `moduleId` 是应用内资源包边界,位于 `appVersion` 之后、`terminalType` 之前,并且不能为空。
- 站点和域名属于同一定位层:有 `siteId` 且站点存在时优先使用 `siteId`;没有站点 ID 时按 `domain` 匹配。
- 匹配必须按层级前缀收敛,不是扁平加权:上层不匹配时,下层维度不再参与竞争。同一个应用可以提供给不同租户使用,因此 `tenantId` 位于 `terminalType` 之后、`siteId/domain` 之前。
- 运行时查询返回整包资源列表,不在数据库侧使用 `distinct`、`distinct on` 或 Top-K 选最优记录。数据库排序只表达覆盖顺序:通用/公共记录在前,精确/私有记录在后;Java 按 `moduleId + resKey` 后覆盖前完成合并。
- 排序只对可空作用域字段做显式 `case when` 排序: `appCode`、`appVersion`、`terminalType`、`tenantId`、`siteId`、`domain`。`languageCode`、`nationCode`、`moduleId`、`resKey` 是匹配或合并 key,不作为覆盖优先级排序字段。
- 运行时接口通过 `valueType` 区分请求 `Label` 还是 `ResValue`,默认返回 `Label`;两类结果不混在同一个响应值中。
- 运行时接口不提供客户端版本协商字段;客户端每次按应用、版本、终端、租户、站点/域名、语言和模块上下文获取当前服务端匹配结果。
- 运行时缓存按固定客户端上下文加单模块缓存最终合并结果。缓存 key 由 `appCode + appVersion + moduleId + terminalType + tenantId + siteId/domain + valueType + languageCode + nationCode` 归一化组成。
- 第一版缓存清除策略采用保守全量失效:运行时资源缓存放在 `I18nResService.CACHE_NAME` 下,只增加 `RT@...` 缓存 key;国际化资源默认服务写操作触发原有实体缓存 key Evict 时,通过同一套 `SpringCacheEventListener` 清理整个 `I18nRes` cacheName,不在各个业务入口手动触发清理。
- 在 Biz 服务中固化两个业务入口:运行时获取国际化资源、按模块上传客户端语言包。默认生成服务和控制器只通过代码生成刷新,不手工修改生成目录。
- 管理后台用户菜单新增“上传国际化资源”入口,交互参照“上传页面路由”:弹框按当前界面语言聚合各已启用前端模块的本地语言包,展示每个模块可上传的 key 数量,并调用 `uploadModuleLabels` 按模块上传。

## 验收标准

- `I18nRes` 自身字段从 9 个增加到 14 个。
- 新增字段语义明确:空值表示该维度通用。
- 终端类型枚举覆盖 `Admin`、`Web`、`H5`、`MiniProgram`、`App`、`OpenApi`。
- 唯一约束和复合索引字段顺序为 `appCode + appVersion + moduleId + terminalType + tenantId + siteId + domain + languageCode + nationCode + resKey`。
- 实体字段声明和生成 DTO 展示顺序应尽量贴近运行时匹配层级: `appCode + appVersion + moduleId + terminalType + siteId + domain + languageCode + nationCode + resKey`。
- HQL 排序必须显式写空值顺序,不可依赖数据库默认 `NULLS FIRST/LAST`: `case when field is null or field = '' then 0 else 1 end asc` 表示通用先、精确后;枚举字段只判断 `is null`。
- Java 合并必须使用后覆盖前语义,最终结果中精确记录覆盖通用记录。
- 运行时缓存 key 必须按单模块生成,避免 `moduleIds` 组合导致缓存碎片;缓存 miss 时根据 `valueType` 加载并合并该模块的最终 `resKey -> label/resValue`。
- 任意 `I18nRes` 写操作成功后必须清除运行时国际化缓存,保证写少读多场景下不会返回旧文案。
- 业务接口、实体生成代码和控制器编译通过。
- 管理后台上传国际化资源弹框必须只统计当前语言资源,按模块展示 key 数量,提交载荷必须匹配 `UploadModuleI18nLabelsReq`。
