## ADDED Requirements

### Requirement: Bootstrap 应用开发预热入口

Bootstrap 管理端应用 MUST 提供可被通用 Vite 配置预热的 `src/bootstrap.ts` 模块，且该模块不得重复挂载应用。

#### Scenario: 启动开发服务器

- **WHEN** 开发者启动 `bootstrap-app` 开发服务器
- **THEN** Vite SHALL 不再报告 `src/bootstrap.ts` 模块不存在，登录页面可以正常渲染
