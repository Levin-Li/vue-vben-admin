## Why

当前前端公共框架和基础模块已经按 npm 公共模块形态演进，但强制规则入口没有明确要求所有需求、约束和任务变更先记录到 OpenSpec，导致 Agent 可能只读取 `AGENTS.md` 和项目规则后直接改代码或文档，遗漏 OpenSpec 任务记录。

同时，第三方集成需要更明确地理解项目定位：公共模块提供默认页面、默认路由映射和公共组件，最终应用可以按同一页面注册路径覆盖具体页面实现，而不改变后端菜单路径、权限和路由语义。公共组件也需要一个专门测试页，用于验证 `UserOrgSelector` 等可复用组件的真实接入方式。

## What Changes

- 将“需求、约束、验收标准或实现任务发生变化时，必须先更新 OpenSpec”写入强制读取入口，而不是只放在 `openspec/config.yaml` 中。
- 在第三方用户手册中补充公共模块定位：默认功能页面可以由公共模块提供，但最终应用必须能用同一路径覆盖页面实现。
- 新增公共组件测试页，作为 `@levin/admin-framework` 公共组件的本地集成测试入口。
- 在公共组件测试页中加入 `UserOrgSelector` 的典型测试场景，并展示 `v-model` 与 `selectedRecords` 输出。
- 补充 `UserOrgSelector` 第三方使用文档，使第三方可以按稳定入口导入和接入。
- 本次不新增后端接口，不改变现有后端菜单 `path`、权限点或业务数据结构。

## Capabilities

### New Capabilities

- `openspec-governed-development`: 仓库开发流程必须把需求、约束、验收标准和任务变更记录到 OpenSpec，并在实现前确认对应 change/tasks 已存在或已更新。
- `public-module-page-overrides`: 公共框架包和基础业务模块必须作为可复用公共模块提供默认页面，最终应用可以通过同一页面注册路径覆盖页面实现，同时保持后端菜单路径和权限语义稳定。
- `public-component-test-lab`: 公共框架必须提供公共组件测试页，用于本地验证公共组件集成行为，首批覆盖用户与组织选择器。

### Modified Capabilities

- 无。

## Impact

- 影响仓库强制规则入口：`AGENTS.md`、`00-项目规则索引.md`，以及前端规则入口。
- 影响前端公共框架文档：`@levin/admin-framework` 第三方用户手册。
- 影响基础业务模块文档：`@levin/oak-base-admin` 补充手册。
- 影响前端公共框架演示路由和页面：`framework-commons/app/router/routes/modules/demos.ts` 与 `framework-commons/app/views/demos/...`。
- 验证需要覆盖 OpenSpec 校验、前端相关单测或构建检查；若进行页面验证，应按现有前端规则说明环境限制。
