## Why

公共 CRUD 内置新增、编辑、删除和详情请求目前可能对非平台用户携带 `tenantId`。非平台用户的租户范围应由登录态和后端数据范围确定，无需也不应由列表行或表单重复提供租户上下文。

## What Changes

- 公共 CRUD 新增、编辑请求仅在当前用户为平台用户时携带 `tenantId`。
- 基于 ID 的删除和详情请求对所有用户均不提交 `tenantId`；详情请求仍保留主键和已有 `orgId`。
- 复用现有统一平台用户判定，不按字段、路由或角色名称重新猜测。

## Capabilities

### New Capabilities

- `platform-mutation-tenant-context`: 根据当前用户的平台身份控制公共 CRUD 新增、编辑请求的租户上下文参数，并移除基于 ID 请求的租户上下文。

### Modified Capabilities

无。

## Impact

- 前端：影响 `@levin/admin-framework` 的公共 CRUD 内置请求构造和回归测试。
- 接口：非平台用户的新增、编辑请求不再提交 `tenantId`；基于 ID 的删除和详情请求对所有用户均不提交 `tenantId`；后端仍以登录态和数据范围为权威。
- 权限：平台用户可继续在新增、编辑请求中携带租户上下文以执行跨租户管理操作。
