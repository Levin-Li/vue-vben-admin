# Traffic Control Pattern Editor Design

## Field Mapping

Use `PatternListEditor` for list-like traffic-control fields:

- `urlPathList`
- `urlPathExcludeList`
- `methodList`
- `domainList`
- `regionList`
- `ipList`
- `ipExcludeList`
- `userTypeList`
- `userRoleList`
- `limitDimensionList`

The component receives current field options and loader-backed options, emits normalized `string[]`, and displays the generated JSON array.

Use the same editor for `UrlExAcl` list-like fields:

- `urlPathList`
- `urlPathExcludeList`
- `methodList`
- `domainList`
- `regionList`
- `ipList`
- `ipExcludeList`
- `osList`
- `userTypeList`
- `userRoleList`

`UrlExAcl` field-level testing is fixed to field-internal "any match" semantics. The frontend must not simulate cross-field ACL execution. Runtime ACL matching remains a backend responsibility: each configured field matches internally with OR, while different include dimensions are combined by the backend interceptor.

## Name/Value Rules

`requestParamRuleList` and `headerRuleList` are persisted Java `List<String>` fields and use the same `PatternListEditor` interaction as URL paths. Each item is a name/value pattern pair separated by a literal `=`:

- The stored shape is a JSON string array, for example `["param%3F=value_*"]`.
- The name side and value side are URL-decoded independently before wildcard matching so reserved characters can be represented without introducing another JSON object shape.
- Each item must contain exactly one `=` separator.
- Runtime matching reads only `requestParamRuleList` / `headerRuleList`.

## Compatibility

The traffic-control page should not import framework internals other than documented public exports from `@levin/admin-framework` where possible. Existing CRUD slots stay in place so the change is localized to the traffic-control page.

## Shared Editor Layout

`PatternListEditor` uses the user-facing name "通配符清单编辑器" and a compact left/right layout:

- The left side contains one inline add row inside the list flow, followed by a minimum two-row scrollable area for existing entries. The editor keeps a light outer border while rows and inputs provide the local affordance. The empty state text is "暂无内容".
- Each existing entry is displayed on its own row and supports inline edit, copy, and delete with icon-only actions and hover tooltips.
- The right side contains vertically stacked icon-only actions for test and copying the generated JSON array. Actions are subdued until the editor is hovered.
- The right-side actions sit below the inline-add separator line. The test action uses a test-oriented icon rather than a magnifier/search icon.
- In CRUD forms, traffic-control list editors occupy two columns instead of a full row. Generic tag fields still keep the existing full-row default unless a field explicitly configures `span`. Explicit positive `span` must take precedence over field-type defaults such as `tags`, `string-array`, and `textarea`.
- Testing opens a modal. The modal accepts a sample value, runs the caller-provided match mode, and shows success or danger feedback under the input.
- Match mode is provided by the caller (`any` or `all`) and is not written into the generated `List<String>` JSON array.
- Long list values are truncated in the row, and hovering the value shows the full content in a tooltip.
- If the surrounding form field has no help text, the editor shows a default hint that `*` and `?` wildcard matching is supported. If the form field already supplies help text, the editor does not duplicate the hint.
- On create/edit forms, pattern-list editors should use at least two grid columns so the list, inline actions, and hint text have enough room. They may share a row with other fields when the grid remains orderly, or occupy a full row when the page density and visual balance call for it.
- Desktop-width CRUD modals should use available horizontal space before creating tall left-heavy forms. Short fields may form four-column rows when the viewport is wide enough, and two-column pattern-list editors should pair naturally with another two-column editor or with short fields when the row capacity allows.
