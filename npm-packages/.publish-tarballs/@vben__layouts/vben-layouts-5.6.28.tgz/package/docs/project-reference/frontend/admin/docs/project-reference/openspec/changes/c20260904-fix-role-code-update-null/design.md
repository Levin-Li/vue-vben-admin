## Context

`SimpleUpdateRoleReq.setCode()` 会把 `code` 放入自动强制更新字段集合。角色业务服务为了禁止修改编码调用该 setter 并传入 `null`，但现有移除方法只移除普通强制更新集合，最终仍生成 `code = null` 的 SQL。

## Goals / Non-Goals

**Goals:**

- 忽略角色更新请求中的 `code`，避免将既有编码清空。
- 保留其它字段的自动强制更新语义。

**Non-Goals:**

- 不允许角色编码在更新时修改。
- 不修改生成请求类或数据库约束。

## Decisions

- 在业务服务中使用不会调用 `setCode()` 的字段清理方式，并显式移除自动强制更新标记。
- 增加服务层测试，断言传给持久化服务的请求不含 `code` 自动更新标记。

## Risks / Trade-offs

- [遗漏另一类更新标记] → 测试同时覆盖普通和自动强制更新集合。
