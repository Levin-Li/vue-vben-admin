## ADDED Requirements

### Requirement: 模块依赖必须与 Spring Boot 4 兼容

系统各模块的第三方构件必须与 Spring Boot 4 的 Jakarta、自动配置和启动模型兼容。对于明确绑定 Spring Boot 2.x、仅提供旧时代 starter 能力、或者已经确认与当前项目运行方式不匹配的构件，系统必须升级到兼容版本或从模块中移除。

#### Scenario: 发现明确绑定 Spring Boot 2 的 starter

- **WHEN** 审计某个第三方 starter 的本地 POM 或官方发布信息，发现其仍显式依赖 Spring Boot 2.x
- **THEN** 系统必须将该构件升级到更高兼容版本，或者在当前项目未使用时将其移除

#### Scenario: 发现模块保留了未使用的旧依赖

- **WHEN** 通过代码搜索确认某个模块直接声明的第三方依赖没有实际代码使用
- **THEN** 系统必须优先移除该依赖，避免继续污染 Spring Boot 4 的依赖树

### Requirement: 版本管理必须集中且可追踪

项目中仍然需要保留的公共第三方构件版本必须尽量集中在根 POM 统一管理，并且所有升级或移除动作必须写入 OpenSpec 变更记录，便于后续追踪和回滚。

#### Scenario: 多模块共享同一第三方构件

- **WHEN** 某个第三方构件被多个模块共同使用
- **THEN** 系统必须优先在根 POM 中统一管理其版本，而不是在子模块中分散写死

#### Scenario: 调整第三方构件

- **WHEN** 本次变更升级或移除了任何第三方构件
- **THEN** 系统必须在 OpenSpec 变更中记录调整原因、影响范围和验证方式

### Requirement: 构件调整后必须进行构建级验证

所有针对 Spring Boot 4 兼容性的构件调整，在完成后必须至少通过 Maven 编译级验证，以确认新的依赖组合没有破坏当前仓库的构建链。

#### Scenario: 完成依赖升级或移除

- **WHEN** POM 中完成一组依赖升级或移除
- **THEN** 系统必须执行编译级验证，并记录仍然存在的剩余风险或后续处理项

### Requirement: OpenAI SDK 排除旧 Victools 传递依赖

`openai-java` 的 Victools `4.38.0` 传递构件 MUST 在直接依赖处显式排除；项目直接管理的 Victools `5.0.0` JSON Schema 构件 MUST 保持为唯一有效版本。

#### Scenario: 解析 AI 服务依赖树

- **WHEN** Maven 解析 `services-impl` 的运行依赖
- **THEN** `openai-java` 不提供 Victools 构件，依赖树只保留项目直接声明的 `5.0.0` Victools 构件
