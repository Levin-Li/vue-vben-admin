## Why

在同一 SPA 会话中从低权限账号切换到高权限账号时，前一个账号的菜单、动态路由和权限检查状态仍被复用；因此已在侧栏可见的高权限页面会被错误地判定为无权访问，浏览器整页刷新后才恢复正常。

## What Changes

- 在新 accessToken 完成登录初始化前清理前一账号的权限码、菜单、动态路由和访问检查状态。
- 移除上一账号注册到 Vue Router 的动态路由，确保导航守卫按新账号的角色与后端菜单重新生成路由。
- 为账号切换增加回归测试，确认切换后不保留旧权限状态，并立即触发新的权限初始化。

## Capabilities

### New Capabilities

- `user-permission-session-reset`: 在同一浏览器会话切换登录用户时隔离权限、菜单和动态路由状态。

### Modified Capabilities

- 无。

## Impact

- 前端公共包 `@levin/admin-framework` 的认证状态、路由状态和单元测试。
- 不修改后端接口、权限模型或用户数据；仍通过 `RbacController.authorizedPermissionList()` 和授权菜单接口获取新用户数据。
