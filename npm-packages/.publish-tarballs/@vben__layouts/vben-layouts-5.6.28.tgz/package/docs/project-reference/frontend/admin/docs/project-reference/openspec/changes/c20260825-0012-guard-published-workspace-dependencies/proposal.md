## Why

私服中已发布的多个 Vben 公共包保留了 `workspace:*` 依赖，导致非 monorepo 消费者无法安装。源码保留工作区协议是正确的本地开发方式，但发布 tarball 必须携带消费者可解析的具体依赖版本。

## What Changes

- 统一公共包发布时使用能够转换工作区协议的打包方式。
- 对本地 tarball 和私服回查 tarball 的 `package.json` 增加依赖协议门禁，禁止 `workspace:` 与 `catalog:` 出现在可安装依赖中。
- 增加临时非 workspace 消费者安装烟测，验证 tarball 能被独立项目安装。
- 为完整运行时依赖闭包中的全部 Vben 公共包递增补丁版本并重新发布，同时递增依赖其精确 peer 约束的 `@levin/admin-framework` 及 `@levin/oak-base-admin`。
- 要求依赖 `@levin/admin-framework` 或 `@levin/oak-base-admin` 的其它可发布模块使用同一套标准发布流程与门禁。

## Capabilities

### New Capabilities

- `published-dependency-protocol-guard`: 验证公共包发布物不含消费者无法解析的工作区或目录协议依赖。
- `standalone-package-install-smoke`: 在非 workspace 临时项目中验证待发布公共包可安装。
- `vben-package-release-repair`: 修复完整运行时依赖闭包中的 Vben 公共包依赖元数据并重新发布它们及其精确 peer 约束消费者。
- `dependent-module-release-workflow`: 约束基础模块消费者使用统一公共包发布门禁。

### Modified Capabilities

无。

## Impact

- 前端发布脚本、tarball 校验和发布流程。
- 受影响 Vben 公共包的版本来源、包元数据和私服版本。
- 不改变消费者运行入口；发布包仍包含 `dist` 与仅供阅读/调试的 `src`。
