# Use MapStruct for Biz Copy

## Why

Hutool BeanUtil.copyProperties can select interface default getters when business DTOs implement RBAC interfaces and inherit fields from base info classes. This can throw at runtime even when source and target are the same business info type.

## What Changes

- Replace vulnerable business-layer same-domain copyProperties calls with generated MapStruct mappers where the mapper already supports the conversion.
- Keep non-domain, third-party, JSON/map, and unsupported conversions unchanged.
- Document backend development rule priority: MapStruct first, Spring BeanUtils fallback, no Hutool BeanUtil for property copy.

## Impact

- Backend business services only.
- Backend development rules.
- No API contract changes.
