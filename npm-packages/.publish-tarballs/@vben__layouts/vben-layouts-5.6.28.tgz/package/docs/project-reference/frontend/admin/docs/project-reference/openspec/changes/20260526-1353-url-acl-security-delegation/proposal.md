# Proposal: URL ACL Security Delegation

## 2026-09-09：独立访问控制测试页面与接口

新增非生产专用测试控制器，提供短信、邮箱、MFA、行为验证码及签名五个独立 POST 回显接口。方法本身免认证且只返回请求数据，真实 URL ACL 仍执行。用户确认动态验证使用测试用户登录态，并明确要求短信、邮箱模拟发送。前端新增独立测试页面，调用公共 requestClient 触发既有验证弹窗；配置五条专用 ACL 和独立签名 ClientApp，执行页面及实际 HTTP 验收。

## Summary

Keep `SignVerify` and `DataRsaCrypt` as `UrlExAcl` policy types, but move their runtime behavior behind an independent service contract. `UrlExAcl` continues to decide which URL rules match; the security-specific execution is delegated so signature verification and data crypto can evolve outside the ACL matching entity and interceptor branching.

## Scope

- Add an independent URL ACL security handler service contract.
- Delegate `SignVerify` and `DataRsaCrypt` actions from `UrlAclInterceptor` to that service.
- Provide a default implementation that preserves current pass-through behavior when no concrete signature or crypto protocol has been configured.
- Add focused tests proving the interceptor delegates both action types.

## Non-Goals

- No entity field changes.
- No new signature algorithm or encryption protocol in this change.
- No database code generation.
- No dependency on `ClientAppAuthFilter`; URL ACL signature/crypto is an independent request-protection mechanism, not client-app login.

## Risks

- A default pass-through handler preserves compatibility, but does not enforce security by itself. Concrete protocol enforcement must be implemented in the delegated service before relying on these ACL types as hard controls.
