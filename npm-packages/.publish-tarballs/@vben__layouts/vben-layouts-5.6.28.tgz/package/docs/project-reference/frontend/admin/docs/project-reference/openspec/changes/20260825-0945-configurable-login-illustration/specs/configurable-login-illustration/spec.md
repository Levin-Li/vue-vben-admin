## ADDED Requirements

### Requirement: 登录页只使用当前租户站点信息

登录页和后台布局 MUST 仅读取后端返回的 `tenantSiteInfo.siteInfo`。后端 MUST 对当前 TenantSite 与 Tenant 的 `siteInfo` 逐字段合并：TenantSite 字段为 `null` 时回退 Tenant，同字段为空字符串时 MUST 保持为空，不得回退。登录页和后台布局 MUST NOT 从后台 UI 设置、Platform 或旧顶层展示字段读取或合并这些信息。

#### Scenario: 站点独立登录页展示

- **WHEN** TenantSite 的 `siteInfo.logo` 为 `null`、Tenant 的 `siteInfo.logo` 有值
- **THEN** 最终 `tenantSiteInfo.siteInfo.logo` 使用 Tenant 的值

#### Scenario: 站点显式清空字段

- **WHEN** TenantSite 的 `siteInfo.title` 是空字符串、Tenant 的 `siteInfo.title` 有值
- **THEN** 最终 `tenantSiteInfo.siteInfo.title` 保持空字符串

### Requirement: 站点字段映射到登录页

系统 MUST 将 TenantSite 的 `title` 映射为登录页系统标题，`titleImg` 映射为标题图，`mainImg` 映射为左侧主图；现有 `logo`、`copyright` 和 `techSupport` MUST 分别映射到 Logo、版权和技术支持展示。

#### Scenario: 站点主图不可用

- **WHEN** TenantSite 的 `mainImg` 为空或加载失败
- **THEN** 登录页显示内置 SVG 主图，登录表单和其它站点信息继续可用

### Requirement: TenantSite 管理是唯一配置入口

管理员 MUST 通过租户站点管理维护登录页信息。后台 UI 设置抽屉 MUST NOT 显示、保存或上传登录页相关字段。

#### Scenario: 打开后台 UI 设置

- **WHEN** 管理员打开后台 UI 设置抽屉
- **THEN** 不显示登录页系统名称、Logo、标题图、主图或版权的配置入口

### Requirement: 移除偏好设置版权并使用站点页脚信息

后台 UI 设置抽屉 MUST NOT 显示版权配置。登录页和后台底栏的版权信息 MUST 只使用当前 TenantSite 返回的 `copyright`；该字段为空时 MUST 不显示版权内容，也不得补充公司名、网址或年份。

### Requirement: 域名访问按站点再租户校验

通过域名访问站点信息、登录页或登录接口时，系统 MUST 先确认 TenantSite 存在、启用且未过期；仅当站点通过后，系统 MUST 再确认其所属 Tenant 启用且未过期。任一校验失败时 MUST 拒绝访问，不得继续返回站点信息或处理登录。
