## ADDED Requirements

### Requirement: 插件单一分组元数据

服务插件 SHALL 仅通过 `getGroupName()` 声明其默认分组；系统 MUST 不再要求、读取或迁移历史分组名称。

#### Scenario: 初始化插件元数据

- **WHEN** 系统初始化任一服务插件
- **THEN** 系统 SHALL 只使用该插件当前的分组名称参与元数据同步

#### Scenario: 既有插件记录

- **WHEN** 系统加载已存在的服务插件记录
- **THEN** 系统 MUST 不依据历史分组名称自动覆盖管理员已维护的分组
