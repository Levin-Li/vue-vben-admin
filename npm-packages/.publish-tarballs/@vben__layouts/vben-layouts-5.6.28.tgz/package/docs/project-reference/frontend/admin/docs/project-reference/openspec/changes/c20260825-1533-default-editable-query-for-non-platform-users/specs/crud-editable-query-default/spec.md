## ADDED Requirements

### Requirement: 非平台用户的可编辑查询默认值

公共 CRUD 在当前查询表单实际渲染 `editable` 查询控件且当前用户不是平台用户时，MUST 将查询状态默认设为 `editable=true`。该默认值 MUST 在页面首次加载和用户重置查询时生效。

#### Scenario: 非平台用户打开具有 editable 查询控件的页面

- **WHEN** 查询表单的最终渲染项包含 `editable` 且当前用户不是平台用户
- **THEN** 首次列表请求仅查询 `editable=true` 的记录

#### Scenario: 非平台用户重置具有 editable 查询控件的页面

- **WHEN** 用户重置查询表单
- **THEN** `editable` 控件恢复为“是”并以 `editable=true` 重新查询

### Requirement: 不注入未渲染的 editable 查询条件

公共 CRUD 在查询表单没有实际渲染 `editable` 控件时，MUST NOT 写入或提交 `editable` 默认查询条件。

#### Scenario: 页面没有 editable 查询控件

- **WHEN** 当前 CRUD 没有 `editable` 查询控件，或该字段不参与查询表单渲染
- **THEN** 初次查询和重置查询都不包含 `editable` 参数

### Requirement: 可编辑性操作限制的字段边界

公共 CRUD 仅在字段元数据包含 `editable` 时，MUST 对非超管隐藏不可编辑记录的内置编辑、删除和快捷布尔更新操作；详情操作 MUST 不受该限制。

#### Scenario: 不支持 editable 的 CRUD

- **WHEN** 当前 CRUD 字段元数据不包含 `editable`
- **THEN** 既有权限允许的内置编辑、删除和快捷布尔更新操作不因记录缺少 `editable` 而被隐藏
