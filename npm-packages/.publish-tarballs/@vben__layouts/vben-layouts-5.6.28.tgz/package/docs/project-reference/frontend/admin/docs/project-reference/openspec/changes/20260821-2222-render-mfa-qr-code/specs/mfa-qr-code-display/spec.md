## ADDED Requirements

### Requirement: MFA URI 二维码展示

系统 SHALL 以 `ShowForm` 展示用户管理中 MFA 二维码接口返回的对象；其中 `mfaQrCode` URI SHALL 以二维码字段展示，不得只按普通文本详情字段展示。

#### Scenario: 查看用户 MFA 二维码

- **WHEN** 管理员点击用户行的“MFA二维码”操作
- **THEN** 系统 SHALL 打开表单结果弹窗，保留 ID、名称等返回字段，并以响应中的 `mfaQrCode` 作为二维码字段内容

#### Scenario: 二维码字段不回显 URI

- **WHEN** 管理员查看 MFA 二维码
- **THEN** 系统 SHALL 不在二维码下方回显原始 URI 文本
