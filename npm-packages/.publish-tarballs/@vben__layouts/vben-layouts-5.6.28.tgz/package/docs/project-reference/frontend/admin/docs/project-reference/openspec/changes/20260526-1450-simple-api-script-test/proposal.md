# Add Simple API Script Testing

## Why

Simple API records already store Groovy or JavaScript content, but authors need a code editing workflow that can execute the current draft on the server before publishing or saving assumptions into production behavior.

## What Changes

- Add a real Simple API URL invocation path for online testing; the editor saves first and then calls the configured URL with a test-mode marker.
- Execute Groovy scripts with an explicit context object and return result, duration, and error details in test mode.
- Expose Spring beans, the current tenant, and the nullable current login user to scripts.
- Enhance the Simple API content editor with a test panel so users can run the current editor content immediately against the server.
- Support lightweight request and response contracts in `setting.requestSchema` and `setting.responseSchema`, using a JSON Schema subset for runtime validation and test input guidance.
- Store structured request and response parameter definitions in `setting.requestParams` and `setting.responseParams`, and derive the validation schemas from those definitions.
- Reshape the script editor into a workbench with variables on the left, code on the right, and debug/test/contract information at the bottom.
- Keep script save and test behavior under the dynamic-code security boundary: only TopSuperAdmin users see and invoke test mode, and non-TopSuperAdmin saves must drop script content on the server side.

## Non-Goals

- This change does not add persistent invocation logs.
