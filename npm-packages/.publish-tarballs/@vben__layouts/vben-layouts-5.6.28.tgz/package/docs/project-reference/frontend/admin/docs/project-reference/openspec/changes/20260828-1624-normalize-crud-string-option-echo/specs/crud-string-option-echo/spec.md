## ADDED Requirements

### Requirement: CRUD string option value echo

通用 CRUD 表单 MUST 在编辑回显时，使数值型记录值能够匹配同值的字符串枚举或字典选项。

#### Scenario: Single select matches a string option

- **WHEN** 编辑记录中的下拉字段值为数值 `100`，且字段选项包含字符串值 `"100"`
- **THEN** 表单模型值 MUST 为字符串 `"100"`，并能显示该选项已选中

#### Scenario: Multiple select matches string options

- **WHEN** 编辑记录中的多选下拉值含数值，且每个数值存在同值字符串选项
- **THEN** 每个可匹配数值 MUST 转换为对应字符串以完成回显

#### Scenario: No matching string option

- **WHEN** 数值记录值不存在同值字符串选项
- **THEN** 表单 MUST 保留该数值的原始类型

### Requirement: CRUD option label display fallback

通用 CRUD MUST 将下拉、枚举和数据字典字段作为选项驱动的展示字段处理：匹配到选项时展示标签，未匹配时展示原始值。

#### Scenario: Matched list value displays its option label

- **WHEN** 列表字段值严格匹配一个已加载选项的值
- **THEN** 表格 MUST 显示该选项的标签，即使字段值类型为数值

#### Scenario: Integer values match across JSON representations

- **WHEN** 记录值与选项值表达同一整数，但一方为 JSON 数字、另一方为 JSON 字符串
- **THEN** CRUD MUST 以其字符串表示匹配该选项并展示标签；提交类型仍由字段配置决定

#### Scenario: Unmatched list value remains visible

- **WHEN** 列表字段值没有任何可匹配选项
- **THEN** 表格 MUST 显示该字段的原始值，不能显示空白或猜测其它标签

#### Scenario: Numeric enum uses its persisted code

- **WHEN** 字段声明 `valueType: 'number'`，且后端枚举项同时提供名称和值编码
- **THEN** 选项的选择值 MUST 使用该编码，以使编辑回显和提交值均与持久化数值一致

#### Scenario: Unmatched edit value is preserved on save

- **WHEN** 编辑记录的下拉、枚举或字典字段值没有可匹配选项，且用户未修改该字段
- **THEN** 保存请求 MUST 使用该字段的原始值，不得因表单控件或值类型序列化而变更或清空它

### Requirement: Option echo development standard

前端开发规范 MUST 记录选择型字段的回显、数值枚举编码与未映射值保存策略，公共前端包随附规则文档 MUST 与规范保持一致。

#### Scenario: Developer implements a choice field

- **WHEN** 开发者配置下拉、枚举或数据字典字段
- **THEN** 规范 MUST 要求其以选项匹配决定标签展示、以 DTO 类型声明提交类型，并保护未修改的未映射编辑值

#### Scenario: Page rule resolves enum value representation

- **WHEN** 页面字段使用枚举选项，且后端 DTO 声明其为数值类型
- **THEN** 页面规范 MUST 要求用数值编码作为选项值并以字符串表示匹配，不得被“枚举使用 name()”的字符串字段规则覆盖
