# Wildcard Pattern List Editor Design

## Component Contract

Create `PatternListEditor` in `@levin/admin-framework` shared components.

Inputs:

- `modelValue`: accepts `string[]`, JSON array string, plain text, or empty value and emits normalized `string[]`.
- `matchMode`: `any` for OR matching and `all` for AND matching.
- `options`: optional local candidate pattern list with labels/descriptions for selectable/searchable values.
- `testValue`: optional controlled test target.

Outputs:

- `update:modelValue`: normalized Java-compatible `List<String>` payload.
- `update:matchMode`: local AND/OR test mode.
- `update:testValue`: current local test target.
- `change`: normalized value and current match mode.

## Matching Rules

- `*` matches zero or more characters.
- `?` matches exactly one character.
- Literal characters are regex-escaped before matching.
- Empty pattern lists do not match a test target.
- `any` mode succeeds when at least one pattern matches.
- `all` mode succeeds only when every pattern matches.

## UI Shape

- A tags-style select provides both free entry and candidate selection/search.
- A compact editor stores and submits `List<String>` values as a JSON array.
- A segmented control switches local test mode between OR and AND.
- A test input evaluates immediately and shows per-pattern hit/miss status.
- A read-only textarea shows the generated JSON array for `List<String>` persistence.

## Packaging

Export the component and helper functions from both `@levin/admin-framework` root and `framework-commons` entry points. Existing wildcard helper behavior remains compatible for `*` and exact matches while adding `?`.
