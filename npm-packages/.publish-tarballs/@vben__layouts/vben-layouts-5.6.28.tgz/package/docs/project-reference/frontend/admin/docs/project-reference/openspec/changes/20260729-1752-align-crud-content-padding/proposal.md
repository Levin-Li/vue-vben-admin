# Align CRUD content padding

## Summary

Adjust admin CRUD pages so the page content area keeps the same spacing on the top as it does on the left and right.

## Scope

- Restore consistent outer padding around CRUD page content.
- Keep the existing CRUD section spacing, table sizing, and page behavior unchanged.

## Acceptance

- The first CRUD section no longer touches the tab bar area.
- The top spacing around CRUD content visually matches the left and right spacing.
