# Restrict organization-scope script expression types

## Goal

Only expose Groovy and SpringEL organization-scope expression types, including
the Groovy tenant-matching mode, to the current super administrator.

## Acceptance criteria

- A non-super-administrator only sees the safe `IdPath` and `NamePath`
  organization-scope expression types, no script-language hint, and no Groovy
  tenant-matching mode.
- A super administrator continues to see `Groovy`, `SpringEL`, and the Groovy
  tenant-matching mode.
- The existing server-side rejection of non-super-administrator script saves
  remains the authorization boundary.
