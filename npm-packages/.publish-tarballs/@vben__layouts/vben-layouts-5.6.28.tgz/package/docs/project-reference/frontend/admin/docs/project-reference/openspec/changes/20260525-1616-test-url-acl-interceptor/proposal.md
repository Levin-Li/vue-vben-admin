# Test URL ACL Interceptor Behavior

## Summary

Add backend regression tests for URL access-control business behavior.

## Scope

- Verify URL ACL condition matching with mocked requests and users.
- Verify supported intercept actions without relying on the admin UI.
- Verify dynamic verify-code response headers and successful access after submitting the generated verification parameter.

## Non-Goals

- No production behavior changes.
- No frontend or browser validation.
