# Add Menu Action Count Badges

## Why

The menu management row actions open required-permission and page-operation editors, but rows with existing values are not visually distinguishable until opening the dialogs.

## What Changes

- Show a small count badge on the top-right of the "所需权限" action when `requireAuthorizations` has values.
- Show a small count badge on the top-right of the "页面操作" action when `opButtonList` has values.
- Keep the existing row actions and dialog behavior unchanged.

## Impact

- Affects the menu management list row action rendering only.
- No API contract changes.
