## Why

`UserOrgSelector` 已具备较丰富的组织与用户树选择能力，但使用说明目前只散落在综合手册中。第三方项目安装编译后的 `@levin/admin-framework` 包后，需要能从稳定、易发现的包内路径理解组件能力、参数、事件、数据加载方式和类型过滤的显示语义，而不必依赖源码检索。

## What Changes

- 在 `@levin/admin-framework` 包根 `docs/` 下新增 `UserOrgSelector` 专用组件文档。
- 在包 README 和现有第三方使用手册中建立到该专用文档的稳定入口。
- 文档明确组件是表单/业务选择器而非全局当前组织上下文，并说明全局上下文应由调用方另行维护。
- 文档覆盖公开参数、双向绑定与事件、默认授权组织树加载、组织/用户选择模式、类型过滤与层级压缩、懒加载限制，以及典型接入示例。
- 验证该文档会被包的 `files` 配置和打包 dry-run 纳入发布 tarball。

## Capabilities

### New Capabilities

- `user-org-selector-component-docs`: 为发布包消费者提供稳定可发现的 `UserOrgSelector` 专用使用文档。

### Modified Capabilities

- 无。

## Impact

- 影响 `frontend/admin/packages/business/admin-framework` 的发布文档和 README 入口。
- 不修改 `UserOrgSelector` 的运行时代码、公开 API、后端接口或权限语义。
- 发布包中新增静态 Markdown 文档；无需新增依赖。
