## ADDED Requirements

### Requirement: 自定义菜单标签覆盖本地页面默认标题

系统 SHALL 在授权菜单节点已匹配本地页面映射时，使用非空的授权菜单名称作为生成路由的导航标题。该标题 SHALL 被侧边栏、标签页和面包屑消费。

#### Scenario: 租户布局重命名已映射本地页面

- **WHEN** 租户自定义菜单将 `/clob/V1/TenantCustomMenu` 的标签保存为“自定义菜单”
- **THEN** 生成的本地页面路由 `meta.title` 为“自定义菜单”

#### Scenario: 授权菜单未提供名称

- **WHEN** 已映射本地页面的授权菜单名称为空
- **THEN** 生成的路由使用页面映射标题作为导航标题回退

### Requirement: 菜单管理优先展示菜单标签
菜单管理列表 SHALL 以label为主显示文字，缺少label时沿用name/path/id回退。页面名称name不得与label并排常显；悬停主文字时仅显示name原值，不添加“页面名称：”等前缀，无name时不显示该提示。
#### Scenario: 页面名称与菜单标签不同
- **WHEN** 菜单name为Area且label为区域管理
- **THEN** 列表仅常显区域管理，悬停只显示Area

### Requirement: 菜单树展开按可视行渲染
菜单管理 SHALL 使用兼容树结构的虚拟滚动，仅挂载可视窗口附近行；业务树单独保留，编辑、排序和删除目标不得因滚动或未渲染而丢失。每个兄弟集合的排序和位置索引 SHALL 在数据变化后集中构建，避免每行反复排序。
#### Scenario: 展开大菜单分组
- **WHEN** 展开包含大量子菜单的分组
- **THEN** DOM行数受视口约束，能滚动到最后一项，固定列对齐
#### Scenario: 虚拟行操作
- **WHEN** 勾选、复制、排序或删除菜单
- **THEN** 使用完整业务树和稳定ID确定范围，包含未挂载后代，权限和写请求契约不变

### Requirement: 流控与访问控制前端显示名称
前端 TrafficControlRule 页面及本地导航、路由上传标题 SHALL 使用“流控规则”，UrlExAcl SHALL 使用“访问控制”。资源标识、页面name、接口路径、API权限注解保持不变，已有管理员自定义菜单标签继续优先。
#### Scenario: 前端默认标题
- **WHEN** 显示上述页面或选择、上传本地页面路由
- **THEN** 分别显示流控规则和访问控制
