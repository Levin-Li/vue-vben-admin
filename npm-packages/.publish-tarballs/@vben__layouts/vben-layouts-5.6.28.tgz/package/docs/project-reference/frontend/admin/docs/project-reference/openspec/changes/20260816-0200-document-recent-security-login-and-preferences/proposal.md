# Document Recent Login, Security, and Preference Changes

## Why

Recent releases changed the password-login flow, MFA enforcement, challenge revalidation, local-console protection, and preference reset behavior. Developers and operators need one accurate contract for the backend, frontend, and configuration boundaries before they consume the released artifacts.

## What Changes

- Document the two-step password-login challenge API, MFA selection rules, replay/context protections, and the explicit boundary that SMS and email logins retain their existing behavior.
- Document the frontend verification dialog, Google Authenticator wording, five-second captcha auto-login behavior, and the preference-only "恢复默认设置" action.
- Document local-console control requirements: loopback peer address plus `X-Local-Console-Token` matching `localConsoleControlToken`.
- Link the new operational guidance from the existing backend security, verification-plugin, and frontend login/settings documentation.

## Impact

- Affects Markdown documentation only; it does not add or alter APIs.
- Provides release notes and integration guidance for backend consumers, frontend implementers, and operators.
