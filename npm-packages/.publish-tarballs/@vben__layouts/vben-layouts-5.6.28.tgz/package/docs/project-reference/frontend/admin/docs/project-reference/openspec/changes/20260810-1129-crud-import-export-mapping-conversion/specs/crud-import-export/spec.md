## ADDED Requirements

### Requirement: Shared CRUD import mappings convert values before submission

The shared CRUD import flow SHALL let an operator map each file column to a writable target field and choose a fixed, supported converter for that mapping. It SHALL preview converted values and surface row-level conversion errors before it calls `batchCreate`.

#### Scenario: Convert text columns to a number and a date

- **WHEN** an operator maps a text column to a numeric field and another text column to a date field
- **THEN** the preview and submitted records contain a finite number and a normalized `YYYY-MM-DD` date
- **AND** an invalid value identifies its source row and target field and prevents import submission.

### Requirement: Shared CRUD export mappings support headers and conversion

The shared CRUD export flow SHALL let an operator select a source field, set its output header alias, order it, and choose a fixed supported output conversion. It SHALL store these choices in export templates.

#### Scenario: Export a custom numeric column

- **WHEN** an operator sets an output header alias and selects the number conversion for a source field
- **THEN** the generated spreadsheet uses the custom header and deterministic numeric text for that column
- **AND** reapplying the saved template restores the header, order, selection, and conversion.

### Requirement: Shared CRUD import accepts standard XLSX workbooks

The shared CRUD import flow SHALL accept a normal `.xlsx` workbook and read the first worksheet into the same header-and-row shape used by CSV and legacy Excel XML imports.

#### Scenario: Import a first-sheet XLSX file

- **WHEN** an operator selects a valid `.xlsx` workbook containing headers and data in its first worksheet
- **THEN** the mapping dialog shows its headers and rows
- **AND** the operator can use the same mapping, preview, validation, and batch-submit flow as CSV.

### Requirement: Template selectors load once and disclose ownership

The shared CRUD import and export template selectors SHALL load their options with exactly one request per opening action. The load request SHALL use dynamic `targetType` composed as `apiModuleBase:apiBase:listPath`, enum `type` to distinguish `Import` from `Export`, `code` composed as the browser address-bar route plus active `ListTable` name, `fileType=Excel`, `enable=true`, `orgShared=true`, and `tenantShared=true`. It SHALL NOT filter by `category`. Save and load SHALL reuse the same `targetType` and `code` identity pair. Saved templates SHALL omit `category`.

#### Scenario: Show templates from all visible ownership scopes

- **WHEN** an operator opens either template selector
- **THEN** the selector issues one template-list request with the exact target and shared visibility flags
- **AND** a record with `ownerId`, `orgId`, or `tenantId` is labeled respectively as personal, organization, or tenant, with personal taking precedence over organization and organization over tenant.
