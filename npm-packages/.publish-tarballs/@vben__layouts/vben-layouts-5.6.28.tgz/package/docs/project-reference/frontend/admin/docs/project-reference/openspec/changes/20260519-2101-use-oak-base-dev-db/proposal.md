## Why

开发环境数据库名称需要统一为 `oak_base`, 方便本地后端服务连接到新的开发库。

## What Changes

- 将开发环境 PostgreSQL 默认库名调整为 `oak_base`。
- 将后端 dev profile 的 JDBC URL 调整为 `oak_base`。

## Impact

- 影响本地 dev profile 启动时连接的 PostgreSQL 数据库。
- 不改变 test/prod 配置。
