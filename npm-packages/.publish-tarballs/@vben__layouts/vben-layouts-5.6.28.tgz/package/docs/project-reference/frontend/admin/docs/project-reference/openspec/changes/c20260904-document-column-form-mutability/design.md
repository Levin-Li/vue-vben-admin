## Context

`@Column(insertable = false)` 与 `@Column(updatable = false)` 是实体字段的持久化可写性事实源。前端 CRUD 使用静态 `formCreate`、`formEdit` 与提交字段配置，不能在运行时反射实体注解。

## Goals / Non-Goals

**Goals:**

- 定义新增和编辑表单对两类 JPA 注解的默认行为。
- 明确不可更新字段在编辑态应展示为不可用且不提交。

**Non-Goals:**

- 不用字段名称推断字段可写性。
- 不引入运行时实体反射或手改生成请求对象。

## Decisions

- `updatable = false` 映射为编辑表单字段不可用，并从编辑请求载荷排除。
- `insertable = false` 映射为新增表单字段不展示且从新增请求载荷排除。
- 同时为 `false` 时，新增不展示；编辑可展示为不可用以回显既有值，且不提交。
- 规则必须由代码生成或静态页面配置转化为 `formCreate`、`formEdit`、`disabledOnEdit` 和 `omitOnEdit` 等明确字段约束。
- 公共 CRUD 在编辑载荷构建时只识别页面显式的 `omitOnEdit`；该开关默认不影响创建载荷，也不根据禁用状态、字段名称或实体注解隐式省略字段。

## Risks / Trade-offs

- [仅隐藏但仍提交] → 规范要求编辑/新增载荷也必须排除对应字段。
- [运行时猜测] → 只允许依据实体注解、生成元数据或页面显式配置。
- [禁用即自动省略] → 使用单独的显式提交开关，避免改变已有仅需禁用展示的字段行为。
