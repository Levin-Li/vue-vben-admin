# Design: Client App Auth Filter

## Flow

```
request
  -> TenantFilter sets current tenant
  -> ClientAppAuthFilter detects app headers
  -> BizClientAppAuthService validates app credentials
  -> AuthService.auth(serviceUserId) establishes request login context
  -> existing MVC interceptors and controllers run
```

## Headers

Primary headers:

- `X-Client-App-Id`
- `X-Client-Timestamp`
- `X-Client-Nonce`
- `X-Client-Signature`
- `X-Client-Body-Sha256`

Legacy-compatible fallbacks use `DefaultSignatureReq.Fields` names where available: `clientId`, `timestamp`, `nonceStr`, and `sign`.

## Canonical String

```
METHOD
path
queryString
timestamp
nonce
bodySha256
```

The signature is lowercase hex HMAC-SHA256 using the application's signing secret.

## Client App Restrictions

- `appId`: public stable app id.
- `serviceUserId`: service user to log in as after successful app auth.
- `allowedIpList`: optional JSON string array exact IP allowlist; `*` allows all.
- `allowedPathPatterns`: required JSON string array Ant-style path allowlist. Empty values are rejected at authentication time.
- `signType`: first version supports `HMAC_SHA256`.
- `expiredTime`: optional application expiry.
- `lastAccessTime`: updated after successful validation.

## Authorization Model

The filter performs authentication only. Authorization remains the existing RBAC model for the generated service user. The client application is still treated as a separate trust class by enforcing:

- mandatory path allowlist before request login context creation
- default-deny management/config paths such as client app, user, role, tenant, org, menu, setting, URL ACL, service plugin, and RBAC endpoints
- rejection of super-admin, SaaS admin, SaaS user, and abnormal/disabled bound service users

The path allowlist is a client-app safety boundary, not a replacement for RBAC.

## Security Notes

Nonce replay prevention is atomic through Redis/Redisson `fastPutIfAbsent` with a bounded replay window. Signature comparison is constant-time. The first version uses `request.getRemoteAddr()` for IP allowlist checks instead of trusting forwarding headers; deployments behind trusted proxies can add a dedicated resolver later.

## Token Behavior

Every app-auth request must arrive without normal user token credentials. The filter checks common token headers, query parameters, and cookies before app credential validation so a request cannot combine user-token and app-signature identities.

The filter still calls `AuthService.auth(serviceUserId)` after successful app credential validation so the existing downstream interceptors and controllers see the bound service user as logged in for the current request. It passes a request-local login flag so the auth service creates the Sa-Token session and stores the token only in the current request storage, avoiding automatic response cookie/header writes. That generated token is internal request plumbing for the reused authorization path; it is not returned as a client-application response credential.
