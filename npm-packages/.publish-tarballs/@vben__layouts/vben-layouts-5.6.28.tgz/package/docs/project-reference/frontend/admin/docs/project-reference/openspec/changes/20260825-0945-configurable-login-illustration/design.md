## Context

登录页在登录前通过 `tenantSiteInfo` 获取当前域名的 TenantSite。站点实体已提供 `title`、`titleImg`、`mainImg`，并已有 `logo`、`copyright`、`techSupport`。

## Decisions

- 后端将 TenantSite `siteInfo`、TenantSite 关联 Brand 和 Tenant `siteInfo` 合并为最终展示信息，再返回到 `tenantSiteInfo.siteInfo`；前端只读取此字段，不独立读取 Brand。
- 合并逐字段执行，固定顺序为 TenantSite `siteInfo` → Brand → Tenant `siteInfo` → 前端内置默认值。当前层字段仅在值为 `null` 时进入下一层；空字符串和空 Map 均是显式值，不得回退。`extParams` 按整个 Map 判断，只有为 `null` 时回退。Brand 的 `title` 仅在为 `null` 时映射为 Brand `name`。
- `tenantSiteInfo` 返回的展示扩展对象以 Tenant 为基底：`siteInfo` 的覆盖顺序为 Tenant → Brand → TenantSite；`uiExInfo` 的普通字段仅按第一层属性由 TenantSite 覆盖，不递归处理 JSON 子对象。`uiExInfo.admin-ui-base-setting` 是特殊的完整配置块，保持整块替换，优先级为 TenantSite → Tenant → Platform。合并方法提供 `allowEmptyStringOverride` 参数，默认 `false`：覆盖层只有在属性非 `null` 且不是空字符串时才覆盖；传 `true` 时空字符串也可覆盖。空对象和 `false` 始终是显式值。`exInfo` 在 `tenantSiteInfo` 接口中继续置空，不下发前端。
- `title` 用作登录页与后台布局标题，`titleImg`、`bannerImg`、`mainImg` 和 `bigImg` 均通过统一 SiteInfo 返回；其中 `titleImg` 和 `mainImg` 分别渲染标题图和左侧主图，`logo`、`copyright`、`techSupport` 分别用于 Logo、页脚版权与技术支持。
- 后台 UI 设置、Platform、旧顶层展示字段不参与登录页或后台布局信息解析；删除设置抽屉中此前的登录页与版权配置入口和保存逻辑。
- 图片 URL 为空或浏览器加载失败时，Logo 回退内置 Logo，主图回退内置 SVG，标题图隐藏；每项独立处理。
- TenantSite 字段变更后，先编译 `entities`，再运行 `simple-dao-codegen:gen-code` 刷新受保护的生成代码。

## Risks

- 站点图片存储不可用时，浏览器 `error` 事件会回退内置展示，不阻断登录。
- 站点字段只影响当前匹配域名，不影响其它站点。
