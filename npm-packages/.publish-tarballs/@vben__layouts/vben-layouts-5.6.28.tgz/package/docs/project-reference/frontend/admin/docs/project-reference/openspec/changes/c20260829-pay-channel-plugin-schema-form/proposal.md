## Why

支付通道页面当前只能编辑原始 JSON，管理员无法按支付提供商配置具备中文字段说明、默认值和安全边界的具体参数。项目已具备服务插件的全局供应商目录与 JsonSchema 编辑器能力，但支付通道尚未接入该路径。

## What Changes

- 将法定货币与数字货币支付插件的供应商目录登记为全局 `ServicePlugin.providerList`，每个供应商声明稳定编码和 `configEditor`。
- 支付通道页面按当前 `currencyType` 固定选择法币或数字货币插件目录；仅展示该插件已启用供应商，并按其 `configEditor` 生成 JsonSchema 表单。
- 在 `PayChannel` 上持久化稳定的 `providerCode`，保存时同步写入对应的 `@JsonSchema`；运行时优先以 `providerCode` 识别供应商。
- 修复共享 JsonSchema 服务请求路径，使 `class:` 配置编辑器通过 Oak 基础模块 API 前缀请求 Schema，而不是请求根路径。
- **BREAKING**：将 `PayChannel.type` 重命名为 `PayChannel.category`，原字段语义明确为管理员维护的通道类别，不再承载供应商路由；同时迁移其数据库列和字典编码。
- 补充服务插件开发规范，明确供应商配置模型、全局元数据、租户设置和 JsonSchema 的职责边界。

## Capabilities

### New Capabilities

- `pay-channel-plugin-schema-form`: 支付通道按货币插件族选择全局供应商配置模型，并以 JsonSchema 表单维护具体参数。
- `service-plugin-provider-configuration-convention`: 服务插件供应商目录、配置编辑器与全局/租户配置边界的开发规范。

### Modified Capabilities

- 无。

## Impact

- 后端：支付插件声明、服务插件初始化及支付通道配置绑定。
- 前端：支付通道 CRUD 页面及其定向测试；页面静态维护货币类型到支付插件实现标识的映射。
- 数据：启动时创建或同步全局服务插件供应商元数据；数据库迁移将 `type` 列和 `PayChannel.type` 字典编码重命名为 `category`，并从已保存的详情配置回填可识别的 `providerCode`。
- 安全：页面和后端均不允许输入 Java 类名；密钥仍只可填写运行时引用名。
