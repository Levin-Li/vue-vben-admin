## Why

公共 CRUD 查询区在页面展示配置重构后被强制设为展示全部查询字段，导致所有未单独配置的管理页面失去默认折叠和“更多”入口。该行为偏离原有交互，扩大了查询表单的默认高度。

## What Changes

- 恢复改动前的公共 CRUD 查询区折叠策略：读取 `query.unassignedExpandedRows`，未配置时默认展示一行。
- 保持改动前已配置为展示全部字段的页面仍可使用 `unassignedExpandedRows: 'all'`。
- 补充公共计算逻辑测试，防止默认值再次被替换为强制全展开。

## Capabilities

### New Capabilities

- `crud-query-default-collapse`: 公共 CRUD 查询区根据页面展示配置决定初始折叠状态，并在缺省配置时保持一行折叠。

### Modified Capabilities

- 无。

## Impact

- 影响 `@levin/admin-framework` 的公共 `CrudPage` 查询区及所有使用该组件的管理页面。
- 不影响后端接口、查询参数、权限判断和页面字段配置。
