## Why
查询区占用空间时，用户希望完整展示当前分页的实际行数，由页面滚动查看。

## What Changes
新增列表设置“显示完整分页”（`list.showAllPageRows`），默认关闭。开启后表格按当前页实际内容自然撑开，取消表格内部纵向滚动，超出可视区域时页面内容区滚动。保留分页和横向滚动，不加载其他页、不补空行、不设置最小高度。

## Capabilities
### New Capabilities
- `list-min-height`: 当前分页完整显示和页面滚动。

## Impact
共享 CRUD 页面布局、展示设置及其测试。
