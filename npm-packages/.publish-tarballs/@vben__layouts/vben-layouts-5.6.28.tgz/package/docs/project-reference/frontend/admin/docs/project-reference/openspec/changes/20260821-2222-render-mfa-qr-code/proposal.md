## Why

用户管理的 MFA 二维码操作将包含 `mfaQrCode` 的响应对象按普通详情表单展示，管理员只能看到 `otpauth://` 文本，无法直接使用认证器扫码绑定。

## What Changes

- 保持 MFA 二维码接口的成功动作声明为 `ShowForm`。
- 在表单详情渲染器中支持显式 `qrcode` 字段类型。
- 将用户页面的 `mfaQrCode` 声明为二维码字段；同一结果中的 ID、名称等字段继续按各自类型展示。
- 同步前端 API 元数据并添加回归测试。

## Capabilities

### New Capabilities

- `mfa-qr-code-display`: 用户管理中的 MFA 二维码操作以表单展示结果，其中二维码字段可扫码展示 URI，且不回显原始 URI 文本。

### Modified Capabilities

- 无。

## Impact

- `BizUserController` 的 CRUD 操作元数据。
- `@levin/oak-base-admin` 用户 API 和用户页面静态操作配置。
