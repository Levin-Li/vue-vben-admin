# Add Menu View And Source Columns

## Why

Menu management needs to expose the runtime page path and source file path directly in the list for troubleshooting, while keeping long paths from stretching the table.

## What Changes

- Add `viewPath` and `sourceFilePath` columns to the menu management table.
- Fix both new columns at 200px width and render single-line truncated values.
- Show the complete value in a tooltip after a 1.5 second hover delay.

## Impact

- Affects menu management list rendering only.
- No API contract changes.
