## ADDED Requirements

### Requirement: 平台用户新增和编辑请求携带租户上下文

公共 CRUD 在当前用户为平台用户时，内置新增和编辑请求 MUST 保留其显式选择的非空 `tenantId` 参数。

#### Scenario: 平台用户新增或编辑跨租户数据

- **WHEN** 平台用户将一条记录的 tenantId 从原租户改为另一租户后执行内置编辑
- **THEN** 请求保留新 tenantId；后端可按自身接口契约决定是否允许并持久化该变更

### Requirement: 非平台用户新增和编辑请求不携带租户上下文

公共 CRUD 在当前用户不是平台用户时，内置新增和编辑请求 MUST NOT 携带 `tenantId`；租户范围 MUST 由服务端登录态和数据范围校验确定。

#### Scenario: 非平台用户提交新增或编辑

- **WHEN** 非平台用户执行内置新增或编辑操作，且表单或转换结果包含 tenantId
- **THEN** 请求载荷不包含 tenantId

### Requirement: 基于 ID 的详情和删除请求不携带租户上下文

公共 CRUD 的内置详情和删除请求 MUST NOT 携带 `tenantId`，无论当前用户是否为平台用户。详情请求 MUST 包含主键和已有的非空 `orgId`；删除请求 MUST 仅使用既有主键参数。

#### Scenario: 平台用户查看详情

- **WHEN** 平台用户从列表打开一条带有 tenantId 的记录详情
- **THEN** 详情请求参数包含主键和已有 orgId，但不包含 tenantId

#### Scenario: 删除列表记录

- **WHEN** 任意用户删除一条带有 tenantId 的列表记录
- **THEN** 删除请求只使用既有主键参数，不包含 tenantId
