## Context

服务插件设置页通过字段插槽替换公共 CRUD 的选择控件，以便复用已加载的插件元数据、动态生成供应商选项并在插件切换时清理无效供应商值。该自定义 Select 未接入公共组件的本地 label/value 筛选。

## Goals / Non-Goals

**Goals:**

- 在当前已加载的插件选项中按显示名称或 ID 进行本地搜索。
- 复用与公共 CRUD 一致的大小写无关包含匹配语义。

**Non-Goals:**

- 不将下拉搜索改为远程分页查询。
- 不修改供应商选择器或其它页面。

## Decisions

- 为两个服务插件 Select 传入同一个本地筛选函数，匹配 `label` 和 `value`。
- 保持 `show-search`、现有选项来源和 `handlePluginChange` 不变，避免影响级联重置。

## Risks / Trade-offs

- [插件数量超过当前 500 条加载上限] → 本次只改善已加载项的检索；不把范围扩大为远程搜索。
