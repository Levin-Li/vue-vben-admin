# Enable Demo Batch Create For Import Testing

## Why

The client-side import flow needs a real CRUD target whose generated `batchCreate` operation is available. The Demo business controller already inherits the generated batch create method, but its business-level disable annotation currently blocks all batch operations.

## What Changes

- Keep the generated Demo `batchCreate` method unchanged.
- Narrow the Demo business controller's disabled batch operations so generated batch create remains accessible.
- Preserve disabled batch update and batch delete operations.

## Impact

- Demo can be used as the first import test target.
- No new backend import endpoints are introduced.
