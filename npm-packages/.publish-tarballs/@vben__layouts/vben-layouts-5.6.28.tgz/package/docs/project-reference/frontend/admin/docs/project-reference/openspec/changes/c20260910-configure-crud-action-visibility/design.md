## Context

公共 CRUD 的内置编辑、删除和详情分别有 API 权限、可编辑性、流程状态以及 `editVisibleOn`、`deleteVisibleOn`、`detailVisibleOn` 约束。自定义 `CrudRowAction` 已有权限、`visibleOn` 和 `visible` 约束。页面展示设置仅将操作作为一个列表列，无法对列内具体操作继续收紧。

## Goals / Non-Goals

**Goals:**

- 提供具体行操作的运行时展示配置。
- 复用现有显示表达式编辑器及 `row`、`user`、`org`、`tenant` 上下文。
- 让设置成为附加限制，永不放宽既有操作资格。

**Non-Goals:**

- 不在前端生成新业务操作或权限。
- 不取代后端 `@CRUD.Op.visibleOn`、API 权限或服务端授权。
- 不配置页面级和批量操作；本次范围为列表行内操作。

## Decisions

- `pageDisplay.list.actions` 保存每个操作的稳定键、显示名称与显示模式；显示模式沿用列表表头的 `always`、`hidden`、`script`。
- 候选项包括内置详情、编辑、删除，以及显式页面 `rowActions`。自定义操作支持 `displayKey`；未设置时用标签生成兼容键。
- 运行时条件与已有权限、可编辑性、流程状态、后端 `visibleOn` 逻辑相与。表达式失败时隐藏操作。
- 设置抽屉提供独立的“具体行操作展示条件”区域，避免把操作错误当成实体列表字段或虚拟列。

## Risks / Trade-offs

- [标签改名导致旧自定义操作设置不再匹配] → 页面自定义操作应声明稳定 `displayKey`；旧标签键只作为兼容兜底。
- [错误表达式隐藏合法操作] → 表达式失败按隐藏处理，设置面板提供当前行数据变量说明；权限仍不受影响。
- [设置误解为授权] → UI 文案和规则明确它只能隐藏，不能授予权限或绕过后端限制。
