## Context

`Partner` 通过 JOINED 继承扩展 `LegalSubject`，两张表复用同一主键。`Org.partnerId` 当前只用于把 Org 解析为 Partner 子类别，供菜单和 UI 设置的匹配使用；`Org.externalLegalSubjectId` 则是组织关联外部法人、机构或个体的通用字段。

## Goals / Non-Goals

**Goals:**

- Org 只维护一个外部主体 ID。
- 继续支持按 Partner 子类别匹配菜单和 UI 设置。
- 旧组织数据可无损迁移。

**Non-Goals:**

- 不改变 Partner 与 LegalSubject 的 JOINED 继承关系。
- 不要求每个外部法律主体都必须是 Partner。
- 不改变电子发票等业务对象自身的 `partnerId`。

## Decisions

- 移除 Org 的 `partnerId` 字段及其生成 API 模型。
- `externalLegalSubjectId` 指向的 LegalSubject 若存在同主键 Partner 记录，即可读取该 Partner 的 `subCategory`；否则返回空类型，继续匹配通用菜单/UI 设置。
- 数据迁移只在新字段为空时回填旧值，不覆盖已有 `external_legal_subject_id`；回填后删除 `partner_id`。
- 机构管理页面复用 `externalLegalSubjectId` 作为新增、编辑和查询字段；其选项加载器以 `containsSubjectName` 搜索。实体 `category` 为非空列，页面将其标记为必填。`areaCode` 继续使用单值远程选择：现有通用行政区划级联组件只会拆分写回省、市、区字段，不能安全映射到 Org 的单一 `areaCode` 字段。

## Risks / Trade-offs

- [历史 `partnerId` 未对应 LegalSubject] → 迁移前必须审计；由于 Partner 与 LegalSubject 共主键，正常数据应可回填。发现异常引用时应先修复数据，再删除旧列。
- [部分第三方代码仍调用 Org 的 `partnerId`] → 重新生成 API 模型将暴露编译错误，作为完整清理的门禁。
