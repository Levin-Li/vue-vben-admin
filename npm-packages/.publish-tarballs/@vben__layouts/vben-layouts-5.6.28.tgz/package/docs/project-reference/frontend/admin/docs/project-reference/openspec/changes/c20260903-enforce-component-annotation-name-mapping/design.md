## Context

项目中的 Spring 控制器和服务，会在 `@RestController`、`@Controller`、`@Service` 或 `@ConditionalOnProperty` 中声明 Bean 名或配置属性名。控制器直接使用控制器简单类名；服务实现使用自身简单类名，或直接实现的服务接口简单类名，例如 `BizMenuServiceImpl` 使用 `BizMenuService`。本变更将该对应关系固化为后端规则，避免重命名时只改 Java 声明而遗漏运行时标识。

## Goals / Non-Goals

**Goals:**

- 建立从控制器类名、服务实现类名或其直接服务接口名到注解中“该组件名称片段”的确定性映射规则。
- 覆盖显式 Bean 名、`@ConditionalOnProperty` 的 `name` 以及以 `value` 表示完整配置键的等价写法。
- 要求新增、修改、重命名控制器或服务时，同步复核该类全部相关注解。

**Non-Goals:**

- 不强制控制器的 `@RequestMapping` 路径等同类名；路径仍遵循现有接口命名与兼容性规则。
- 不修改不属于当前类组件标识的通用配置键、第三方约定键、共享 Bean 名或方法级 Bean 条件。
- 不为既有代码引入运行时扫描器、编译插件或新的依赖。

## Decisions

1. 采用“控制器用控制器简单类名；服务实现用自身简单类名或直接实现的服务接口简单类名”的规则：例如 `BizTenantController` 对应 `PLUGIN_PREFIX + "BizTenantController"`，`BizMenuServiceImpl` 对应 `PLUGIN_PREFIX + "BizMenuService"`，`DefaultBizPayServiceImpl` 可对应同名 Bean。这样同时覆盖项目已有的接口契约 Bean 和实现类契约 Bean，重命名时仍可直接核对。
2. 对同一类组件，`@RestController`/`@Controller` 或 `@Service` 与 `@ConditionalOnProperty` 的组件名称片段必须一致；服务的 `@Service` 注解被明确纳入检查，避免 Bean 名与启用开关分别漂移。
3. `@ConditionalOnProperty` 的 `prefix` 保持模块/命名空间语义，只有类级条件中标识当前组件的 `name` 或完整 `value` 片段必须映射；方法级 `@Bean` 的条件名称按该 Bean 的独立身份检查，不与配置类名比较。

## Risks / Trade-offs

- [共享 Bean 名、第三方配置键或方法级条件被误判] → 规则仅约束类级控制器和服务组件自身的名称；代码评审或对应 OpenSpec 必须记录例外的来源或共享语义。
- [控制器路由被错误改成类名] → 明确排除 `@RequestMapping` 等路由值，继续遵守已有 API 路径与兼容性规则。
- [重命名遗漏] → 将“成组检查全部相关注解”作为新增、修改和重命名的必做检查项。

## Migration Plan

1. 在后端开发规则的服务与控制器章节增加本约束和示例。
2. 复核现有生产控制器、服务及基础组件的相关注解，确认当前值与声明类名一致或属于已排除情形。
3. 通过 OpenSpec 严格校验并检查文档差异；规则为开发期约束，无需发布迁移或回滚步骤。

## Open Questions

无。
