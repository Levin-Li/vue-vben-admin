## Why

新建或不存在持久化登录配置时，系统当前默认开启登录验证码。根据当前产品要求，应将这一总开关的默认值调整为关闭，以减少首次配置时的登录阻碍。

## What Changes

- 将 `LoginCfg.enableLoginVerifyCode` 的默认值从开启改为关闭。
- 为该默认值补充回归测试。
- 不迁移、不覆盖任何已存在的 `UserLoginCfg` 持久化配置；管理员可继续在系统设置中显式启用验证码。

## Capabilities

### New Capabilities

- `login-verify-default`: 定义登录验证码总开关在未配置状态下的默认行为。

### Modified Capabilities

- 无。

## Impact

- 影响后端 `LoginCfg` 新建实例和首次创建的默认登录控制设置。
- 已有数据库配置、接口路径、权限及前端表单结构不变；本次不执行数据迁移。
