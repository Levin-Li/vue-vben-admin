## Why

服务插件实体已将供应商定义收敛到插件记录，并新增按插件保存配置的实体。现有内置插件仅在被调用时补建插件记录，且未提供标准化的插件实现标识、显示名称与供应商列表，无法保证每个已装配插件都有正确的插件元数据和可编辑配置记录。

## What Changes

- 新增 `SimpleServicePlugin` 作为所有服务插件接口的共同中间层，声明插件实现标识、名称和 `ServicePlugin.Provider` 供应商列表。
- 供应商列表是插件实现声明的固定能力，也是 `ServicePlugin.providerList` 的唯一事实源；每次启动初始化均会幂等校准该元数据。服务插件管理页仅提供供应商只读查看与插件启用/禁用，不提供插件或供应商的新增、删除和元数据编辑入口。
- 在每个 `SimpleServicePlugin` Bean 完成初始化后，幂等创建或补全对应的一条 `ServicePlugin` 记录；一条记录对应一个插件实现类。
- `ServicePlugin` 的 `configEditor` 与 `baseConfig` 表示插件级共享基础配置：编辑器由插件实现声明并在初始化时回填，基础配置独立保存；不得与供应商 `configEditor` 或租户/域名的 `ServicePluginSetting.value` 混用。服务插件管理页提供独立的“基本配置”编辑入口，沿用系统设置的 JSON Schema 编辑能力。
- 服务启动时，每个已装配插件实现均生成一条 `ServicePlugin` 记录及一条公共默认 `ServicePluginSetting` 记录。
- `ServicePluginSetting` 按“租户 + 域名 + ServicePlugin”保存一条配置；一条设置记录在同一时刻只选择一个供应商，供应商编码保存在 `servicePluginProviderCode`，`value` 继续按 `{供应商编码: 配置}` 保存供应商配置。
- 手工新增设置时，超级管理员可选择租户，其他用户固定使用当前租户；表单支持选择插件、填写域名和选择供应商。列表行提供独立的配置编辑操作，按当前 `servicePluginProviderCode` 从 `value` 取出对应配置、依据供应商的 `configEditor` 打开 JSON Schema 编辑器，并只回写该供应商编码对应的配置。
- 运行期读取插件设置必须通过标准 `ServicePluginSettingService.loadCacheList(...)` 获取缓存数据，再在内存中按插件和域名解析最具体的生效配置，避免为单次插件调用直接查询数据库。
- SSL 证书申请纳入服务插件体系：固定 ACME 供应商列表由插件声明，插件基础参数保存在 `ServicePlugin.baseConfig`，当前选中供应商的参数保存在 `ServicePluginSetting.value[供应商编码]`；申请时按租户与域名解析缓存配置，不再读取旧的 `SslApplyConfig` 系统设置。
- 保持既有插件排序、启用状态和已有用户配置不变；插件实现声明的名称、类型与供应商列表由启动初始化校准，不再保留与代码声明不一致的供应商元数据。

## Impact

- 影响 `ServicePlugin` 与 `ServicePluginSetting` 的默认生成 CRUD 层、所有服务插件接口和实现类，以及 `BizServicePluginService` 的初始化逻辑。
- 影响 SSL 证书申请及域名证书申请调用链；现有系统设置中的 `SslApplyConfig` 保留为历史数据，但不再参与运行期读取。
- 不覆盖已有设置记录；插件元数据按代码声明校准，设置读取改为缓存列表的内存筛选。
