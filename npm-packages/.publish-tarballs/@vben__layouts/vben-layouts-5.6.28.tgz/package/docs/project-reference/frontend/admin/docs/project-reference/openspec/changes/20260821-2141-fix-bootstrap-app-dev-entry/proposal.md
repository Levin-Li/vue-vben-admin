## Why

`bootstrap-app` 开发服务器继承的 Vite 预热清单包含 `src/bootstrap.ts`，但应用只提供 `main.ts`，导致开发环境报模块不存在且登录页无法渲染。

## What Changes

- 为 `bootstrap-app` 补充无副作用的 `src/bootstrap.ts` 预热入口。
- 保持现有 `main.ts` 作为唯一应用挂载入口，避免重复启动。

## Capabilities

### New Capabilities

- `bootstrap-app-dev-entry`: Bootstrap 管理端开发服务器可解析预热入口并渲染登录页。

### Modified Capabilities

- 无。

## Impact

- 前端开发环境和验证码登录页面烟测；不修改后端 API 或生产运行时挂载流程。
