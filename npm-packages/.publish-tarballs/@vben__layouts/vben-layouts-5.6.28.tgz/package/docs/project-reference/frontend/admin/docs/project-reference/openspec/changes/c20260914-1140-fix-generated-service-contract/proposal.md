## Why

当前工作区的全量 `services-impl` 编译被两个服务契约不一致阻断：平台领域业务实现声明了接口不存在的状态机方法，导入导出模板的受保护默认服务实现声明了接口未提供的方法。该问题阻止 DataScope 等无关变更完成正常回归。

## What Changes

- 同步平台领域业务服务接口与已实现的状态机能力，保留状态读取、校验、迁移和事件可见性填充的明确契约。
- 依照 simple-dao 生成规则重新生成导入导出模板默认服务，使其与当前服务接口和实体模型一致；不手改受保护生成目录。
- 增加构建回归，证明 `services-impl` 可完整编译并执行目标测试。

## Capabilities

### New Capabilities

- `generated-service-contract-integrity`: 业务服务接口、业务实现与默认生成服务必须保持可编译的一致契约。

### Modified Capabilities

- 无。

## Impact

- `services` 中的平台领域业务接口。
- `services-impl` 中的平台领域业务实现及导入导出模板生成服务。
- simple-dao-codegen 生成链与后端模块测试构建。
