## Decisions

- 使用长度为 64 的可空字符串 `partnerId` 保存关联，匹配 `Partner` 的主键类型。
- 同时在 `Org` 声明只读、延迟加载的 `partner` JPA 关联；其 `JoinColumn` 复用 `partnerId`，不直接通过对象字段写入关系。
- 代码生成器会依据该关联自动给 `partnerId` 生成 `@Options(refTargetType = Partner.class)`，因此创建、更新请求能够选择合作伙伴，无需手改受保护的生成目录。
- 不在此变更中限制组织类型或 `isExternal`。字段的业务语义用于关联外部机构、独立主体或个体，但保留调用方按实际业务决定是否关联的兼容性。
