# Remove ServicePluginProvider

## Summary

Remove the `ServicePluginProvider` model surface after the entity class was deleted, including its default generated services/controllers and matching business extension files.

## Motivation

`ServicePluginProvider` is no longer part of the entity model. Leaving generated request/info/service/controller classes in the source tree would keep stale API and service references that no longer compile once the entity is absent.

## Scope

- Remove `ServicePluginProvider` default generated service API, mapper, request, info, implementation, and controller files.
- Remove `BizServicePluginProvider*` business extension service/controller files and related statistics request.
- Regenerate code from the current entity module so generated surfaces reflect the remaining entities.
- Verify there are no Java source references to `ServicePluginProvider` after cleanup.

## Acceptance Criteria

- No `ServicePluginProvider` Java source files or package directories remain under the generated service/controller surfaces.
- No Java source references remain to `ServicePluginProvider`, `E_ServicePluginProvider`, `ServicePluginProviderService`, or `BizServicePluginProviderService`.
- Entity compilation and `simple-dao-codegen:gen-code` complete successfully.
- Related module compilation is run and any unrelated blockers are recorded.
