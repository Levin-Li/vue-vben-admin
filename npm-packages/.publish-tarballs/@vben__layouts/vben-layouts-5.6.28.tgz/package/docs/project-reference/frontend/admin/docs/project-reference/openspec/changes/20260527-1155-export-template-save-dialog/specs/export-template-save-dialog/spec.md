# export-template-save-dialog Specification

## ADDED Requirements

### Requirement: Export Template Save Dialog Clarity

The CRUD export-template save dialog SHALL clearly ask for a template name and SHALL avoid displaying internal role-visibility explanations in the scope choices.

#### Scenario: Template name is explicit

- **WHEN** the operator opens “另存为导出模板”
- **THEN** the dialog SHALL show a field labeled “模板名称”
- **AND** the field SHALL keep the current default name seed.

#### Scenario: Scope labels hide business-rule wording

- **WHEN** the operator views the template scope choices
- **THEN** the choices SHALL be labeled only as personal, platform shared, tenant shared, and organization shared
- **AND** role visibility wording such as “超管可见” or “管理员可见” SHALL NOT be displayed.

#### Scenario: Dialog is roomier

- **WHEN** the save-template dialog opens
- **THEN** it SHALL render wider and taller than the previous compact confirm dialog
- **AND** the scope behavior and submitted payload SHALL remain unchanged.

### Requirement: Export Template Selection Applies Configuration

The CRUD export modal SHALL keep the template selector in sync with saved templates and SHALL apply a selected template to the current export field settings.

#### Scenario: Newly saved template appears and is applied

- **WHEN** the operator saves the current export settings as a template
- **THEN** the template selector SHALL refresh and include the saved template
- **AND** the saved template SHALL become the selected template
- **AND** the current export field selection, aliases, and ordering SHALL remain applied from that saved template.

#### Scenario: Existing template selection applies settings

- **WHEN** the operator selects an export template
- **THEN** the export field checkboxes, alias inputs, and ordering controls SHALL update from the selected template configuration.

#### Scenario: Compatible template types are listed

- **WHEN** the operator opens the export dialog
- **THEN** the template selector SHALL list templates whose type is `Export`
- **AND** it SHALL also list templates whose type is `ImportAndExport`
- **AND** it SHALL NOT list import-only templates.

#### Scenario: Legacy target type keys remain visible

- **WHEN** templates were saved with an older target type key for the same CRUD page
- **THEN** the export dialog SHALL query compatible target type variants
- **AND** the selector SHALL include the matching saved templates instead of showing an empty list.
