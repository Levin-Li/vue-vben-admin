# Omit empty i18n upload context fields

## Why

The i18n upload modal currently sends `appVersion: ""` when the version input is empty. Empty optional text dimensions should not be submitted because downstream services may treat an explicit empty string differently from an omitted scope field.

## What Changes

- Omit `appVersion` from the i18n upload payload when it is blank or whitespace-only.
- Keep existing omission behavior for the other optional text dimensions.
- Preserve non-empty upload context values after trimming.

## Impact

- Affected packages: `@levin/admin-framework`, `@levin/oak-base-admin`
- Affected area: i18n label upload payload construction and modal submit behavior.
