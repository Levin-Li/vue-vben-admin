# Design

## Architecture

数字货币支付采用完全独立 `CryptoPayServicePlugin` / `CryptoPayService` 插件族：独立接口、独立订单/结算事件实体、独立供应商适配器和独立 JSON Schema 配置类，不再直接实现面向传统支付的 `BizPayService`。原 `BizPayService`、支付宝和微信适配器保持不变。两者只共享 `PayChannel` 的动态选择能力；数字货币插件只在最终状态变化时通过桥接服务更新关联的 `PayOrder` 并发送既有业务通知。

支付插件注册表不再以 `PayChannel.type` 作为硬编码路由前提。它将完整通道传给每个插件族判断：`BLOCK_CHAIN_TOKEN_COIN` 由数字货币插件处理，`LEGAL_TENDER` 由传统支付插件处理。插件再根据 `detailInfo.@JsonSchema` 对应的配置类和配置内容选择 NOWPayments、CoinPayments、BitPay、支付宝或微信的具体适配器。通道 `type` 继续作为动态字典和展示/筛选信息，不限制后端扩展。

每个供应商适配器都必须有同名的本地模拟服务实现。模拟服务采用与真实适配器相同的统一供应商契约，但不模拟或伪造真实的供应商签名算法：它使用仅限测试的确定性密钥与事件格式。测试通过模拟服务驱动 `created`、`pending`、`confirmed`、`completed`、`expired`、重复回调和异常金额/网络事件，验证本地订单的完整状态流转与幂等性。

模拟服务还必须暴露供应商风格的测试 HTTP 接口：NOWPayments 的 payment 创建/查询、CoinPayments 的 v2 merchant invoice 创建与状态、BitPay 的 invoice 创建/查询。请求字段、响应标识、支付状态和回调行为必须按各供应商公开文档的语义映射；测试适配器通过 HTTP 调用这些端点，不能直接访问模拟器内存对象。

支付模拟工作台是正式管理端功能页，而非临时测试页面。它在模拟器已显式启用的环境中装配，并使用独立资源类型和操作权限控制访问；页面必须明确标记“模拟支付”，展示主订单、数字货币附属订单、结算事件和通知审计。工作台只允许创建隔离的模拟订单并调用本机模拟器，禁止读取或驱动真实供应商通道、真实钱包、真实资金或生产订单。未启用模拟器的环境页面可以存在，但必须清晰显示不可用状态且不暴露任何模拟动作。

首期采用“托管网关或只读链上观察器”模式：插件创建一笔支付指令并返回收款地址、网络、USDT 精确金额和过期时间；供应商 Webhook 或观察器把经过验证的结算事件转换为内部回调。私钥不进入应用、数据库、日志或支付通道详情。

`PayChannel.detailInfo` 仅保存受脱敏保护的通道配置，例如供应商地址、商户 ID、Webhook 验签公钥/密钥引用、USDT 合约地址、允许网络和最小确认数。密钥值应通过安全配置引用注入，不允许将明文私钥写入通道配置。

每家供应商使用独立的 `@Schema` 配置类。字段 `title` 采用简短管理界面标签，`description` 完整说明供应商 API 对应字段、格式、是否必填、回调/金额影响和密钥安全规则。四家配置类共享网络、资产标识、确认数、有效期和回调地址等通用约束，但不将 API Key、client secret、私钥或助记词定义为可保存字段；只接受部署环境中的密钥引用名。

`PayChannel.detailInfo` 保持为现有 JSON 字段，不新增平行通道实体。创建或更新通道时，管理端在详情中明确给出 `providerCode` 或 `@JsonSchema`；业务切面据此将 JSON 对象中的 `@JsonSchema` 设为 `class:<供应商配置类全限定名>`。通道 `type` 不参与该动作；更新配置时必须保留已有 `@JsonSchema` 值，避免管理端 JSON Schema 编辑器退化为原始 JSON 编辑器。

当通道类型是动态字典时，自动绑定不能把字典值当作唯一供应商标识。业务配置入口应允许管理员明确选择配置类/插件供应商，并将其写入 `@JsonSchema`；运行时以该 Schema 元数据为准。系统可为内置字典值预填默认 Schema，但管理员可新增类型而不需要后端发布新枚举。

该绑定机制同时覆盖既有 `Alipay` 和 `Wxpay` 通道。它们的配置类以支付业务字段描述 SDK 所需配置，密钥、证书和私钥仍只填写部署环境引用名；现有运行时适配器需在读取配置时解析引用而不再期待管理员把秘密材料直接写进 `detailInfo`。

真实适配器实现前，必须建立供应商协议清单：官方文档 URL、文档版本或最后更新日期、核对日期、使用的官方 SDK 坐标与版本（如有）、SDK 与项目 Java/Spring Boot 版本的兼容性结论。不得以博客、非官方 SDK、旧接口示例或普通交易 API 替代商户支付 API。缺少 Java 官方 SDK 时，适配器必须按该版本官方协议实现请求、响应、验签与状态映射，并由本地 HTTP 模拟服务回归验证。

## Payment Order Model

新增 `CryptoPayOrder` 作为数字货币支付插件的主订单，使用唯一 `payOrderId` 关联原 `PayOrder`，并保存通道、供应商订单号、支付指令和当前结算状态。新增 `CryptoSettlementEvent` 保存每次供应商查询或 Webhook 的事件 ID、验签结果、原始 payload 摘要、处理结果与发生时间。

`PayOrder` 是统一业务支付主单，始终由消费者选择 `PayChannel` 的统一入口创建；法币支付仅使用主单，数字货币支付在主单创建后建立唯一关联的 `CryptoPayOrder`。`CryptoPayOrder` 是数字货币结算事实来源，只有其进入终态时桥接层同步 `PayOrder` 的用户可见状态和原有业务通知。

`PayOrder.amount` 仍表达业务订单的报价金额，不能作为链上资产的唯一金额事实。`CryptoPayOrder` 至少包括：

- `settlementNetwork`：如 TRON、Ethereum；必须是通道允许的网络。
- `settlementAsset`：首期固定 USDT，并记录合约地址或资产标识以避免同名资产混淆。
- `settlementAtomicAmount`：字符串或整数形式的最小单位金额；不得用四位小数的 `BigDecimal amount` 代替。
- `settlementAddress`、`chainTransactionHash`、`chainOutputIndex`。
- `confirmationCount`、`requiredConfirmationCount`、`quoteRate`、`quoteExpireTime`。

为使统一业务订单也能准确表达加密资产报价，`PayOrder.amount`、`discountAmount`、`productPrice` 和 `refundAmount` 的 JPA 列精度统一改为 `precision = 38, scale = 18`。这是向上兼容的扩容迁移：既有四位小数值保持不变。链上结算和供应商核验不依赖该十进制表示，继续比较 `CryptoPayOrder` 中的原子金额字符串。

链上交易的唯一性以 `network + transactionHash + outputIndex` 约束；若网络没有输出序号，则用确定的事件/日志索引替代。交易哈希、地址和网络是可查询字段，不能只放在截断风险较高的支付快照 JSON 中。

## Status and Confirmation

订单创建后必须将可恢复的支付指令和 `prepayId`/供应商 invoice ID 一并写回订单，并把状态从 `Accepted` 转为 `Processing`。这样已有查询入口能够主动获取状态，避免未支付订单永久停在 `Accepted`。

收到结算事件时，适配层先完成供应商签名验证或链上数据验证，再按以下顺序处理：

1. 定位本系统订单，并校验通道、USDT 网络、资产/合约、收款地址和原子金额。
2. 以链上交易唯一键原子登记或更新确认数，重复事件不得重复发货或发送通知。
3. 未达到最小确认数时，订单保持 `Processing`；达到时才进入 `Succeed`。
4. 达到 `Succeed` 后遇到重组、作废或金额不匹配，创建需人工处理的异常记录；不得静默改写已交付订单。

对于付款金额不足、资产不符、网络不符、地址不符、过期报价或无效签名，订单不得成功，适配层需要记录可审计但已脱敏的拒绝原因。

## Webhook Security

回调端点仍可匿名访问，但只允许支付供应商投递。插件必须验证签名、时间窗口、事件 ID 重放和来源配置；不能相信 URL 上或请求体中的订单号。处理前后均需使用已存储订单进行金额、网络与地址比对。

模拟服务端点只允许 `test` Profile 启用，使用显式测试开关并绑定在本地回环地址；任何 `dev` 或 `prod` Profile 不得装配模拟供应商，也不得接受模拟密钥或模拟回调。

回调日志不得记录 API key、签名原文、完整鉴权头或钱包敏感配置。回调响应必须在幂等处理完成后才返回供应商认可的成功格式。

## Refund Policy

USDT 退款不走现有“原路退款”假设。插件在首期明确返回不支持自动退款；管理端的退款申请可保留审核痕迹，但不得调用自动出款。独立链上退款需要单独的 OpenSpec 变更和资金安全设计。

## Provider Decision

实际支付指令的 HTTP 请求、签名算法、Webhook 格式和支持网络都取决于供应商。首期支持 NOWPayments、CoinPayments 与 BitPay，但每个适配器必须在配置中显式声明其允许的 USDT 网络；尚未通过开户、地区/KYB 审核或未确认支持指定网络的适配器必须保持禁用。默认只将已验证可用的网络暴露给用户。
