## Why

业务模型字段缺少元数据时，接口文档、CRUD 表单和 JSON Schema 驱动的展示无法表达字段含义。现有实体内部快照类及部分 VO、DTO、BO 尚未完全遵守字段级 `@Schema` 描述要求。

## What Changes

- 明确所有 VO、DTO、BO，以及实体中承担相同数据模型职责的内部类，均须为每个实例字段提供 `@Schema` 中文说明。
- 扫描并补齐当前源码中符合该范围的缺失字段注解。
- 以可重复的静态检查验证字段元数据完整性。

## Capabilities

### New Capabilities

- `business-model-field-schema`: 统一业务数据模型字段的 OpenAPI/Schema 中文元数据约束。

### Modified Capabilities

- 无。

## Impact

- 影响 `entities` 中的内部 JSON/快照模型和各服务模块的 VO、DTO、BO 源码。
- 不改变数据库结构、接口字段名或运行时业务行为；仅补充接口与表单元数据。
- 不新增依赖，也不修改代码生成目录。
