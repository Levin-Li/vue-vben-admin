# admin-ui-setting-upload-target Specification

## ADDED Requirements

### Requirement: Choose Admin UI Setting Upload Target

The admin UI setting upload action SHALL allow an operator to choose whether to save the admin UI base setting to the current tenant site or to the current tenant.

#### Scenario: Default Tenant Site Target

- **WHEN** the upload setting modal opens
- **THEN** the selected upload target SHALL default to tenant site
- **AND** submitting without changing the target SHALL preserve the existing tenant-site save behavior

#### Scenario: Tenant Target

- **WHEN** the operator selects tenant as the upload target
- **AND** submits the admin UI base setting
- **THEN** the frontend SHALL send the selected target to the backend
- **AND** the backend SHALL save `admin-ui-base-setting` into the current tenant `uiExInfo`
- **AND** tenant-site `uiExInfo` SHALL NOT be modified by that request

#### Scenario: Tenant Site Target

- **WHEN** the operator selects tenant site as the upload target
- **AND** submits the admin UI base setting
- **THEN** the frontend SHALL send the selected target to the backend
- **AND** the backend SHALL save `admin-ui-base-setting` into the current tenant site `uiExInfo`
