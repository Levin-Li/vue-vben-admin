# Secure Local Console Control

## Why

The bootstrap `BlockingFilter` exposes local stop/start controls based only on the request Host value. Host is not an authentication factor, so a reachable backend or permissive reverse proxy could allow an external caller to stop service.

## What Changes

- Require both a loopback peer address and a configured secret token before `/local/console/stop` or `/local/console/start` changes process state.
- Disable those commands by default when the token is not configured.
- Apply the same protection to both admin and client bootstrap applications.

## Impact

- Operators must set `localConsoleControlToken` and send it in `X-Local-Console-Token` when using the local console controls.
- Other request blocking behavior is unchanged.
