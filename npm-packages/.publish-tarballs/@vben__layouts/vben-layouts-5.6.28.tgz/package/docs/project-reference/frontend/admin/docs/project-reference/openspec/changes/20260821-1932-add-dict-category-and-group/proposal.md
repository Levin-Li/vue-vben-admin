## Why

现有数据字典只能按名称、编码和类型进行维护，无法表达字典所属的业务类别和更细粒度的分组，影响后台筛选、归类和后续业务复用。

## What Changes

- 为数据字典新增可选的“类别”和“分组”文本字段，分别使用 `category` 与 `groupName` 持久化。
- 在字典创建、更新、详情和列表查询模型中贯通两个字段，并支持按字段精确查询。
- 在数据字典管理页提供类别、分组的查询、编辑与列表展示。
- 为新字段建立数据库索引，保证按类别或分组筛选的基本查询性能。

## Capabilities

### New Capabilities

- `dict-category-and-group`: 支持数据字典按类别和分组维护、展示与筛选。

### Modified Capabilities

- 无。

## Impact

- 后端：`Dict` 实体及由 `simple-dao-codegen` 生成的请求、响应、服务和控制器模型。
- 前端：`@levin/oak-base-admin` 的数据字典 CRUD 静态页面配置及其测试。
- 数据库：字典表新增两个可空字符串列及单列索引；不影响存量记录。
- 权限与接口：沿用既有 `BizDictController` CRUD 接口和权限元数据，不新增接口或权限点。
