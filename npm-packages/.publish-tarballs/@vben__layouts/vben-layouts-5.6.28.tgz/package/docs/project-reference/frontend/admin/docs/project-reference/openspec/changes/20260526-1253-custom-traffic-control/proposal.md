# Proposal: Custom Traffic Control

## Summary

Add an independent custom traffic-control module for API request rate limiting. The module will support rules scoped by API path, HTTP method, tenant, user, role, user type, domain, region, client IP, request parameters, and request headers, while keeping the existing URL access-control module focused on access decisions such as deny, login requirement, redirect, and dynamic verification.

## Motivation

The existing URL access-control rule model already matches request dimensions such as URL, method, domain, IP, region, user type, and role, but its runtime action model is access-oriented. Custom traffic control needs stateful counting, distributed rate-limit keys, time windows, and `429 Too Many Requests` responses. Mixing those concerns into `UrlExAcl` would make access control harder to reason about and harder to operate.

## Scope

- Add a new traffic-control rule entity and generated CRUD surface.
- Reuse the existing URL ACL-style request matching semantics where appropriate.
- Add a dedicated traffic-control interceptor or filter that evaluates enabled rules and enforces rate limits before business controllers execute.
- Support limit keys composed from tenant, user, IP, API path, HTTP method, and rule id.
- Support structured matching for query/form request parameters and HTTP headers.
- Support at least one first-version distributed limit algorithm backed by Redisson.
- Return clear HTTP `429` responses and optional rate-limit headers when a request is rejected.
- Add admin management entry for traffic-control rules, separate from URL access control.
- Add focused backend tests for matching, key composition, threshold behavior, and bypass cases.

## Non-Goals

- Do not replace URL access control, controller authorization, RBAC, or resource authorization.
- Do not implement quota billing, package entitlements, or commercial usage accounting in the first version.
- Do not add a gateway service or require deployment behind a gateway.
- Do not make CPU load protection configurable through this rule model.
- Do not put rate-limit configuration into `UrlExAcl.exInfo` as the primary model.

## Operating Model

Traffic-control rules are managed independently from URL access-control rules. Operators can create rules such as:

- `/api/pay/**`, tenant + IP, 60 requests per minute.
- `/api/order/export`, tenant + user, 5 requests per 10 minutes.
- `/api/**`, IP only, 600 requests per minute for anonymous traffic.
- `/api/admin/**`, tenant + user + API path, stricter thresholds.
- `/api/pay/**` with header `X-Client-App-Id=abc*`, tenant + client header, 120 requests per minute.
- `/api/order/list` with parameter `status=Pending`, tenant + user, 30 requests per minute.

When multiple enabled rules match a request, each matched rule is evaluated. The request is allowed only if every matched traffic-control rule allows it.

## Risks

- Overly broad rules may block legitimate traffic. The admin UI and docs should make scope and key dimensions visible.
- Distributed counters can introduce Redis load under very high traffic. The implementation should keep key generation bounded and avoid per-request database reads.
- IP-based limits can be inaccurate behind proxies unless the deployment has a trusted client-IP resolver. The first implementation should document which IP source is used.
- Rule ordering and multiple matches can surprise operators if not explained clearly.
