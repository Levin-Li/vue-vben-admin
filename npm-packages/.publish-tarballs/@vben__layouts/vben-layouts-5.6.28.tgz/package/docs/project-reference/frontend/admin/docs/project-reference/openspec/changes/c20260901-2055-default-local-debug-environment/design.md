## Context

现有后端启动说明把默认 profile 设为 `env1-dev`，与本项目本地联调默认使用 `local` 的团队约定不一致。后端的 Maven profile 会决定资源过滤结果，因此仅在 Java 启动参数中指定 Spring profile 不能可靠地切换到 `local`。

## Goals / Non-Goals

**Goals:**

- 让本地前后端启动的默认环境明确且可重复执行。
- 让后端编译和运行使用同一个 `env0-local` / `local` 环境选择。
- 保留用户显式指定环境的优先级。

**Non-Goals:**

- 不改变 `dev`、`test`、`prod` 环境的定义或发布流程。
- 不修改启动脚本实现、业务代码、数据库结构或前端代理配置。

## Decisions

- 以根目录 `后端启动说明.md` 作为规范承载点，因为后端启动技能已明确将其作为事实来源。相比只修改技能说明，该文档也能约束人工与其它自动化入口。
- 默认选择 `env0-local`，并同时传递 Spring `local` profile；两者必须一致。拒绝仅在 Java 命令添加 profile 参数，因为 Maven 资源过滤仍可能留下非 local 的 `application.properties`。
- 用户显式的环境选择优先于默认规则，以满足联调、测试和生产排障的明确需求。

## Risks / Trade-offs

- [旧脚本仍默认使用 dev] → 本次仅更新规范；调用方须依据规范在 local 场景使用匹配的 Maven profile。
- [local 数据库状态与代码不一致] → 启动前继续按既有流程验证 PostgreSQL、Redis 与数据库迁移状态，不将环境异常误判为功能问题。
