## Why

运行环境识别服务尚不能表达 Spring `mock` Profile。调用方因此无法通过统一的环境服务明确判断当前是否为 mock 环境。

## What Changes

- 为运行环境模型增加 `Mock` 类型。
- 为 `BizEnvService` 增加 `isMock()` 查询接口及其 Spring Profile 实现。
- 保持既有生产优先级：激活 `prod` 时，即使同时存在 `mock`，`isMock()` 也必须返回 `false`。
- 为上述判定补充回归测试。

## Capabilities

### New Capabilities

- `runtime-environment-recognition`: 统一识别 mock 运行环境并维持生产环境的排它语义。

### Modified Capabilities

无。

## Impact

- 后端：修改 `Env`、`BizEnvService`、`BizEnvServiceImpl` 及其单元测试。
- API：Java 服务接口新增 `isMock()` 方法。
- 配置：本次不新增、启用或修改任何 Spring/Maven Profile 配置。
- 安全：本次不改变现有验证码、第三方登录或外部协议模拟功能的启用条件。
