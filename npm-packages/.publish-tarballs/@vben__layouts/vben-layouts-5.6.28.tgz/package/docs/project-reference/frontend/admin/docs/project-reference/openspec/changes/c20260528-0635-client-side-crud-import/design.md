# Design

## Import Availability

The shared CRUD page computes import availability from the page API service:

- `config.apiService.batchCreate` must exist and be callable.
- The service method must not be filtered out by disabled-operation metadata.
- The user must satisfy the existing permission checks for `batchCreate`.

The first implementation will use the same metadata utilities already used for CRUD operations where possible, and otherwise degrade to method presence plus permission metadata.

## Client-Side Import Flow

1. Operator clicks the framework-level `导入` toolbar button.
2. Import dialog opens.
3. Operator selects an Excel or CSV file.
4. Browser parses the first sheet or CSV content into rows.
5. Operator chooses an import template or edits mappings manually.
6. Preview table shows transformed records and row-level client-side validation errors.
7. Operator clicks `开始导入`.
8. A separate console modal opens and appends log lines.
9. Records are split into batches of 2000 and submitted via `batchCreate`.
10. The console reports final imported, failed, batch count, and error messages.

## Templates

Template storage continues to use `ImportExportTemplate`.

Import template query uses:

- `category = CrudImport`
- `fileType = Excel` or `Csv`
- `inType = [Import, ImportAndExport]`
- compatible current and legacy target type variants.

Export templates continue to use `category = CrudExport`.

Template config stores:

```json
{
  "version": 1,
  "headerRow": 1,
  "dataStartRow": 2,
  "sheetName": "Sheet1",
  "fields": [
    {
      "source": "用户名称",
      "target": "name",
      "required": true,
      "converter": "trim",
      "defaultValue": ""
    }
  ]
}
```

## Template Save And Delete

Default import template name uses the current business title as prefix, for example `Demo导入模板`. The save scope and payload follow export template save behavior.

Template delete is shared by import and export:

- Requires the ImportExportTemplate delete API to be available to the user.
- Requires `editable !== false`.
- Personal template: owner, tenant admin, or TopSuperAdmin.
- Organization shared template: owner, org admin, tenant admin, or TopSuperAdmin.
- Tenant shared template: tenant admin or TopSuperAdmin.
- Platform shared template: TopSuperAdmin only.

Deletion calls the existing ImportExportTemplate standard `delete` API only.

## Conversion

Initial conversions are front-end built-ins:

- none
- trim
- number
- boolean
- date/datetime string normalization
- json

No script conversion is included in the first implementation.

## Error Handling

Preview catches file parsing, missing target fields, required values, and conversion failures. Final business validation remains backend-owned through `batchCreate` responses.

Import console supports clear/copy logs and keeps failed batch details in memory for final report.
