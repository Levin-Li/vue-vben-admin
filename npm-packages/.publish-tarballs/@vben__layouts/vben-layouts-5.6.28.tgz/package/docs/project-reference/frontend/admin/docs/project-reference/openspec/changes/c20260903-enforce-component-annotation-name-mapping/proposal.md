## Why

控制器和服务类的 Spring 注解中经常同时声明 Bean 名和启用配置键名。若这些名称未随类名同步，重命名后可能出现 Bean 冲突、配置失效或难以追踪的运行时行为，因此需要将现有的一一映射约定明确为可复核规则。

## What Changes

- 在后端开发规则中新增组件注解命名映射要求。
- 要求控制器和服务注解中用于标识组件的名称，从其约定的类型名称直接派生，并在新增、修改或重命名时成组检查。控制器使用控制器类名；服务实现使用其自身类名或直接实现的服务接口名。
- 明确 `@RestController`、`@Controller`、`@Service` 与 `@ConditionalOnProperty` 的适用范围；不把独立的接口路由语义或方法级 Bean 条件误作类组件名称。

## Capabilities

### New Capabilities

- `component-annotation-name-mapping`: 约束 Spring 控制器、服务及组件注解中与类名对应的名称保持可验证的一一映射。

### Modified Capabilities

无。

## Impact

- 影响根目录的后端开发规则文档。
- 不改变现有接口、数据库、依赖或运行时默认行为；后续类新增、修改和重命名时须依规则完成注解复核。
