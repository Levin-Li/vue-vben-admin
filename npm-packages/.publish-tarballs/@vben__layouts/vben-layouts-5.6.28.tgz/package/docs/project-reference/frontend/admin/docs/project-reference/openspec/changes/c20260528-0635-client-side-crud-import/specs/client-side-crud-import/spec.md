# client-side-crud-import Specification

## ADDED Requirements

### Requirement: Import Uses Existing Batch Create

CRUD import SHALL submit records only through the current resource's existing standard `batchCreate` method.

#### Scenario: Import button is shown

- **WHEN** a CRUD page's active list toolbar renders
- **AND** the API service exposes an enabled `batchCreate` method
- **AND** the current user is allowed to call it
- **THEN** the page SHALL show the framework-level import button beside the list export action.

#### Scenario: Import button is hidden

- **WHEN** `batchCreate` is absent, disabled, or not permitted
- **THEN** the page SHALL NOT show the import button.

#### Scenario: Import follows active list context

- **WHEN** the operator opens import from a CRUD page with multiple list views
- **THEN** import templates SHALL use the active list target context in the same way as export templates.

### Requirement: Client Parses And Previews Import Files

The import flow SHALL parse Excel and CSV files in the browser and preview transformed data before submission.

#### Scenario: Operator previews a file

- **WHEN** the operator selects a file and maps columns to target fields
- **THEN** the UI SHALL show preview rows, transformed values, and client-side validation errors.

### Requirement: Import Templates Are Supported

The import flow SHALL load, save, and apply templates through the existing ImportExportTemplate CRUD service.

#### Scenario: Import templates are listed

- **WHEN** the import dialog opens
- **THEN** it SHALL list matching `Import` and `ImportAndExport` templates for the current target type.

#### Scenario: Import template is saved

- **WHEN** the operator saves a mapping as a template
- **THEN** the default name SHALL use the current business controller title as prefix
- **AND** the template SHALL use the same ownership scope flow as export templates.

### Requirement: Templates Can Be Deleted

Import and export template selectors SHALL support deleting templates when permission and ownership rules allow it.

#### Scenario: Delete is visible

- **WHEN** the operator has delete permission
- **AND** the template is editable
- **AND** the template ownership allows deletion by the current user
- **THEN** the selector SHALL show a delete action.

#### Scenario: Delete is hidden

- **WHEN** delete permission is missing, the template is not editable, or ownership does not allow deletion
- **THEN** the delete action SHALL be hidden.

### Requirement: Import Runs In Frontend Batches

Confirmed imports SHALL run in the frontend by calling `batchCreate` repeatedly in batches of 2000.

#### Scenario: Import console reports progress

- **WHEN** the operator starts importing previewed rows
- **THEN** a console-style modal SHALL open
- **AND** each batch SHALL append start, success, or failure log lines
- **AND** the final log SHALL report total success and failure counts.

#### Scenario: Running import can be stopped

- **WHEN** the operator clicks stop import while batches are running
- **THEN** the frontend SHALL stop before submitting the next batch
- **AND** already accepted batches SHALL NOT be rolled back
- **AND** the console SHALL append a stopped summary.

### Requirement: No Import Backend Endpoint Is Added

The implementation SHALL NOT add backend import, preview, progress, or error-file endpoints.

### Requirement: Import And Export UI Responsibilities Are Split

The shared CRUD page SHALL keep import/export orchestration in the page while moving import/export modal rendering and reusable helper logic into focused modules.

#### Scenario: CRUD page remains the orchestration boundary

- **WHEN** import or export state changes
- **THEN** `crud-page.vue` SHALL own the page-level state, permission checks, list context, and API calls.

#### Scenario: Import and export panels render independently

- **WHEN** the import or export dialog opens
- **THEN** the dialog UI SHALL be rendered by dedicated panel components
- **AND** these components SHALL communicate through props and events rather than owning CRUD service calls.

#### Scenario: Shared helpers are reusable

- **WHEN** template matching, template delete visibility, or Excel XML export generation is needed
- **THEN** reusable logic SHALL live in focused TypeScript helper modules rather than in the large CRUD page component.
