## Why

系统会为带有字典选项的字段自动初始化字典和一个占位字典项，但当前占位项使用“字典项1-完整字典编码”和通用的 `item_code_1`，难以从管理界面识别其所属字段，也不利于后续维护。

## What Changes

- 自动初始化的占位字典项名称改为“字段显示名称1”，例如“合同类别1”。
- 自动初始化的占位字典项编码改为“字段 Java 名称_1”，例如 `category_1`。
- 仅迁移仍可识别为旧自动生成占位项的数据；用户新增或已修改的字典项保持不变。

## Capabilities

### New Capabilities

- `default-dictionary-item-naming`: 为字段选项自动创建可读且稳定的默认字典项，并安全兼容旧占位项。

### Modified Capabilities

- 无。

## Impact

- 影响 `ModuleDataInitializer` 的系统字典初始化逻辑和相应单元测试。
- 不新增外部依赖，不调整已有字典的字典编码、接口或用户维护的字典项。
