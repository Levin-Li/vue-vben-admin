# Design

`ForwardEmailInboundEmailRelayServicePlugin` 是本期唯一的邮件中转插件。每条 `EmailRelayRoute` 以租户、邮件域名和别名唯一，并保存多个投递目标。目标类型只有 `Email` 与 `Webhook`；禁用目标不会同步到 Forward Email alias。

运行时按既有 `ServicePluginSetting` 解析提供商配置：租户配置优先，缺省时回退平台公共配置。配置 JSON 与目标列表使用服务端数据脱敏，不能在普通查询和日志中暴露 Token 或 Webhook 地址中的敏感信息。

同步时先确保 Forward Email 域名存在，再按本系统保存的 provider alias ID 或别名更新 alias 的 recipient 列表。系统不修改没有 provider alias ID 的非受管资源；删除操作只删除已绑定的 provider alias。

DNS 完全手动管理。页面调用 Forward Email 的记录验证接口展示所需状态和说明；不会写入、替换或删除 MX/TXT 记录。

Webhook 直接由 Forward Email 投递。页面仅说明其原生 JSON payload、`X-Webhook-Signature` 验证和失败重试；本系统不读取、存储或再转发邮件正文和附件。
