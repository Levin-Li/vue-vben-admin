## Why

第三方 OAuth 平台配置仍由旧的 `Setting` 记录按 `oauth_platform_*` 编码动态创建和读取，导致系统设置中出现大量不应由管理员逐项维护的供应商配置，并且与现有服务插件配置模型并存。OAuth 凭据需要统一进入按租户、域名和供应商管理的服务插件设置，避免重复配置入口和敏感信息落在错误的配置边界。

## What Changes

- 新增 OAuth 第三方登录服务插件：以 JustAuth 支持的平台作为稳定供应商目录，并使用 `ServicePluginSetting` 保存租户/域名级供应商选择及凭据。
- 迁移 OAuth 运行时读取逻辑，停止创建或读取 `Setting` 中的 `oauth_platform_*` 配置。
- 提供可重复执行的数据迁移脚本，将历史 `oauth_platform_*` 配置转换为 OAuth 服务插件设置，并移除已转换的旧配置。
- 系统设置列表不再展示遗留 OAuth 配置；前端服务插件设置页能按 OAuth 插件的供应商配置模型维护这些配置。
- 将服务插件设置页面的操作文案从“编辑当前供应商配置”简化为“编辑供应商配置”。
- 为运行时配置解析、历史数据迁移和前端页面配置补充回归测试。

## Capabilities

### New Capabilities

- `oauth-service-plugin-settings`: 以服务插件设置为 OAuth 平台配置的唯一管理与运行时读取边界，并安全迁移历史系统设置。

### Modified Capabilities

- 无。

## Impact

- 后端：OAuth 业务服务、服务插件元数据/设置解析、数据库迁移脚本及相关测试。
- 前端：服务插件设置页面的 OAuth 供应商配置展示与系统设置页面的遗留配置过滤。
- 数据：历史 `Setting` 表中编码为 `oauth_platform_*` 的记录会在执行迁移脚本后写入 `ServicePluginSetting` 并删除旧记录。
- 不新增第三方依赖；不重启或启动后端服务。
