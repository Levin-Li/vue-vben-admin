# Backend Locale Alias Fallback

## Why

Runtime i18n endpoints currently require full locale codes such as `zh-CN`.
Common callers may send short or variant locale inputs such as `zh`, `en`, or
`zh_cn`. These values should not cause runtime i18n APIs to fail before local
fallback resources can be used.

## What Changes

- Normalize backend i18n locale input by trimming, converting `_` to `-`, and
  canonicalizing segment case.
- Resolve known language-family aliases to supported default locales:
  `zh -> zh-CN` and `en -> en-US`.
- Keep runtime i18n resource lookup exact after normalization, using the
  normalized `languageCode` and `nationCode` in existing cache keys and queries.
- Return normalized language metadata in `runtimeLabels` and `serverLabels`
  responses.

## Impact

- Affects `BizI18nResServiceImpl` locale parsing for i18n sync, server label,
  runtime label, and module upload paths.
- Prevents valid common locale aliases from failing with a missing country code.
- Does not add broad resource fallback across different regions.
