## ADDED Requirements

### Requirement: SSL 证书文件内容未变化时必须跳过写入

以数据库证书记录生成本地 SSL 证书文件时,系统 MUST 在写入 `domain.pem` 和 `domain.key` 前比较现有文件与待写入内容的哈希值. 当证书链和私钥两个文件都已存在且哈希值均相同时,系统 MUST 跳过备份和写入,避免定时任务反复保存未变化的证书文件.

#### Scenario: 证书链和私钥文件哈希均一致

- **WHEN** 本地 `domain.pem` 和 `domain.key` 均已存在
- **AND** 两个文件内容的哈希值分别与数据库证书链和私钥一致
- **THEN** 系统不得备份现有证书文件
- **AND** 系统不得重写 `domain.pem` 或 `domain.key`

#### Scenario: 任一证书文件内容不同

- **WHEN** 本地 `domain.pem` 或 `domain.key` 的哈希值与待写入内容不一致
- **THEN** 系统必须继续执行现有证书覆盖保护规则
- **AND** 只有通过现有保护规则后才能覆盖写入

#### Scenario: 任一证书文件不存在

- **WHEN** 本地 `domain.pem` 或 `domain.key` 不存在
- **THEN** 系统必须继续生成缺失的证书文件
