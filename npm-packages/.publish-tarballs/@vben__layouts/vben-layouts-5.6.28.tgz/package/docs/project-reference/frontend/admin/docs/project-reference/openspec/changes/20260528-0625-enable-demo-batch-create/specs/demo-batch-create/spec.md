# demo-batch-create Specification

## ADDED Requirements

### Requirement: Demo Generated Batch Create Is Available

The Demo business API SHALL expose its generated batch create operation for client-side import testing while continuing to avoid custom import-specific backend endpoints.

#### Scenario: Batch create is not disabled

- **WHEN** Demo API metadata and access checks evaluate disabled operations
- **THEN** the generated `batchCreate` operation SHALL NOT be disabled by the Demo business controller.

#### Scenario: Other generated batch mutations remain disabled

- **WHEN** Demo API metadata and access checks evaluate disabled operations
- **THEN** generated batch update and batch delete operations SHALL remain disabled.
