## Why
登录首页主视觉区错误展示技术支持，与页脚重复。用户已确认各位置内容映射。
## What Changes
- 技术支持只在底部，与版权信息并列。
- 主视觉仅展示标题图及主图/默认插画，不补技术支持或默认宣传文案。
- 核验Logo、站点名、表单标题说明、标签页标题/图标既有绑定。
## Capabilities
### New Capabilities
- `login-brand-placement`: 登录首页品牌元素位置。
### Modified Capabilities
无。
## Impact
仅admin-framework登录布局和回归测试；无后端字段、数据和权限变化。
