# 让管理前端 CRUD 页面与实体/控制器元数据保持一致

当前管理前端已经出现了多处围绕 `UiSetting`、`TenantCustomMenu`、`OpenArea`、`User` 和 `Org` 的字段与操作调整，但全量页面仍缺少一次系统性的覆盖审计。为避免出现字段漏配、按钮缺失、页面标题不一致或 CRUD 行为与后端元数据脱节，本次变更要对管理前端的 CRUD 页面做一次完整核对，并把发现的缺口补齐。

本次变更的目标是：

- 对 `packages/business/oak-base-admin/src/modules/com_levin_oak_base/views` 下的页面做一次实体/控制器覆盖审计。
- 对已经绑定到实体或控制器的页面，逐项核对字段、查询项、表格列、创建/编辑/删除操作与后端元数据的一致性。
- 修正已经识别出的页面偏差，优先收口当前已经变更的 `UiSetting`、`TenantCustomMenu`、`GlobalOrgSelectorSetting` 和 `OpenArea` 相关页面。
- 对不该存在的“伪页面”或缺少绑定的页面，只记录为缺口，不凭前端猜测新造页面。
- 完成后用浏览器验证关键页面、清理验证数据并保留截图证据。

本次增量需求为 `UiSetting` 和 `TenantCustomMenu` 增加独立的“组织类型”范围字段。该字段复用 `Org.Type` 枚举，与既有“组织类别”并存；需要更新实体、受控生成的请求/信息对象、运行时匹配逻辑、管理页面及数据库迁移记录。
