## Context

新版生成器将 `QueryXxxReq` 改为继承 `SimpleQueryXxxReq`。后者的泛型链式 setter 返回 `SimpleQueryXxxReq`，即使实际对象是 `QueryXxxReq`，在先调用继承 setter 后，Java 的静态类型也会退化，从而无法继续调用完整查询字段的 setter，或不能传给需要 `QueryXxxReq` 的服务方法。

## Goals / Non-Goals

**Goals:**

- 仅修复新版生成契约导致的编译错误。
- 保持原有查询条件和数据范围语义不变。

**Non-Goals:**

- 不修改生成目录中的请求对象。
- 不改变业务接口或重新设计查询逻辑。

## Decisions

保留 `new QueryXxxReq()` 的实际对象。在任何继承 setter 之后需要继续调用完整字段 setter，或需要把链式表达式传给要求 `QueryXxxReq` 的下游方法时，在链式表达式末尾或类型退化点调用 `.cast()`。`Castable.cast()` 是框架提供的泛型自转换，不复制对象，因此保留原有查询条件和数据范围。

新版生成器还在三个客户端默认控制器中写入对应业务 BO 包的通配符导入，但这些包不存在，且控制器代码没有引用其中的类型。按用户明确授权，删除这三条无效导入；后续生成器模板应修复其客户端 BO 导入判定，避免再次生成。

## Risks / Trade-offs

- [在类型退化前继续调用完整字段 setter] → 在该 setter 前调用 `.cast()`，并在编译中确认链式类型。
- [生成器再次调整类型] → 以生成对象的实际继承链和 `Castable.cast()` 合约作为调用方类型恢复依据。
