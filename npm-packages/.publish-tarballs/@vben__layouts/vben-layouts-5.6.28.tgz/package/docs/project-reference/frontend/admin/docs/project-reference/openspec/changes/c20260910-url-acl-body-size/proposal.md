# URL访问控制请求体大小限制

新增 RequestBodyLimit 拦截类型，通过 exInfo.maxRequestBodyBytes 设置请求体字节上限，默认1048576。Content-Length未知（包括分块传输）直接411，超过上限413；判断不得读取正文、Reader或表单参数。不新增数据库列，不迁移数据。
