## Context

Generated ID request objects carry data-range filters. A downstream request must retain the original trusted scope; reconstructing it with only an ID leaves those filters unset.

## Decisions

Each affected service will create a new generated request only when it needs a different target ID or update type. It copies the original request's common properties first, then explicitly sets the target ID and operation fields. A scoped preload occurs before any external side effect or update.

The electronic-invoice red request changes from tenant-only to tenant/organization/personal scope because it reads and creates personal, organization-owned invoices. Internal scheduler and verified provider-callback paths remain separate and continue to use their trusted system context rather than pretending to be end-user requests.

## Verification

Focused unit tests capture downstream requests and assert tenant, organization, owner, and ID preservation. Relevant service modules compile and their tests run with the test-skipping Maven profile disabled.
