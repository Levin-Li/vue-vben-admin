## Why

当前项目已经迁移到 Spring Boot 4，但各模块 POM 中仍保留了部分明显来自 Spring Boot 2 时代的第三方构件，或者保留了未实际使用的旧依赖管理项。这类构件即使短期内不直接报错，也容易在自动配置、类路径冲突、运行时反射、Jakarta 迁移和启动链上引入隐蔽问题，因此需要做一次集中审计和收口。

## What Changes

- 审计根 POM 和各子模块 POM，识别与 Spring Boot 4 不匹配或高风险的第三方构件。
- 升级仍在使用、但版本明显偏旧的构件到更接近 Spring Boot 4 生态的版本。
- 移除未实际使用、且继续保留只会增加兼容风险的构件或依赖管理项。
- 统一将版本控制尽量收敛在根 POM，减少模块之间的版本漂移。
- 增加编译级验证，确认构件调整后不会引入新的构建层问题。

## Capabilities

### New Capabilities
- `spring-boot4-dependency-compatibility`: 项目各模块必须仅保留与 Spring Boot 4 兼容或已验证可工作的第三方构件；对不兼容、无效或未使用构件进行升级或移除。

### Modified Capabilities
- 无

## Impact

- 影响文件主要为 [pom.xml](/Users/lilw/IdeaProjects/levin-framework-base/pom.xml) 及各模块 `pom.xml`。
- 影响范围包括第三方构件版本管理、自动配置装配链、可选集成能力和构建稳定性。
- 不涉及实体模块业务模型设计，不修改默认生成类和受 `code-gen.md` 保护目录。
