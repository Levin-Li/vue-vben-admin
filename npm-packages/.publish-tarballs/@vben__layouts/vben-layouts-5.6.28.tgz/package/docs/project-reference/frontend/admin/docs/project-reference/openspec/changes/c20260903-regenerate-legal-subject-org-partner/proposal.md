## Why

法律主体、组织和合作伙伴实体已调整字段与枚举模型；受保护的默认请求、信息、服务和控制器必须由生成器与实体模型同步，避免实体、接口元数据和前端页面契约漂移。

## What Changes

- 为 `Org` 新增当前组织类型 `Team`、`TempOrg`，移除仅用于读取的 `Area` 对象关联，保留单值 `areaCode`。
- 将 `Partner.industries` 的数据库列长度扩展为 512，并整理法律主体实体注解格式。
- 按项目受控流程重新生成 `LegalSubject`、`Org`、`Partner` 对应的默认服务、请求/信息对象和默认控制器；不得手改生成目录。
- 复核生成结果及受影响的前端元数据，确认新增组织类型和移除关联在当前 API 模型中一致。
- 当前实体继续调整后，按同一受控流程刷新 `EContractTemplate`、`EInvoice`、`OpenArea`、`Tenant`、`User` 及其枚举关联的默认生成物；本次只做离线编译和生成，不重启后端服务。
- 根据实体字段 `@Schema` 的省、市、区县行政编码语义，静态配置前端区域选择器的可选层级，避免把任意层级编码写入语义明确的字段。
- 为公共区域选择器提供可选的六码补全参数，以便页面明确要求统一保存六码编码时复用。

## Capabilities

### New Capabilities

- `legal-subject-org-partner-model`: 约束法律主体、组织和合作伙伴实体变更后默认生成物与接口模型的一致性。

### Modified Capabilities

- 无。

## Impact

- 后端实体：`LegalSubject`、`Org`、`Partner`、`EContractTemplate`、`EInvoice`、`OpenArea`、`Tenant`、`User` 及其关联枚举。
- 生成物：`services`、`services-impl`、`admin-api`、`client-api` 受 `code-gen.md` 保护的默认模型与控制器。
- 前端：组织类型选项和实体驱动 CRUD 元数据可能随生成结果更新。
- 前端公共组件和页面配置：区域级联选择器、地址、法律主体、合作伙伴和示例页面。
- 前端组件文档：`admin-framework` 的区域选择器使用说明。
- 前端测试入口：在既有 Demo 页面提供无需后端写入的区域选择器交互测试台。
- 数据库：`Partner.industries` 列长度由 JPA Schema 元数据扩展；本次不在运行时执行历史数据迁移。
