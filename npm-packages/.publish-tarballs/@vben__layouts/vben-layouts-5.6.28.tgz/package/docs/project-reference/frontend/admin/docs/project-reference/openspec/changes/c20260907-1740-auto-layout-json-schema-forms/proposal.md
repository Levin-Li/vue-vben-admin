# 自动优化 JSON Schema 配置表单布局

公共 JSON Schema 表单在宽屏会生成过多列。默认限制为两列，并让长文本、模板、JSON、代码和嵌套内容独占整行；Schema 显式布局继续优先。
