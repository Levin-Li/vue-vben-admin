# Frontend Vitest Storage Setup

Full frontend Vitest runs under Node 25 can expose an incomplete `localStorage` implementation, causing storage-dependent tests and modules that load preferences at import time to fail before feature assertions run.

This change adds a test-only setup guard that installs complete in-memory Web Storage APIs when the runtime-provided storage object is missing required methods. Production code and package output are unchanged.
