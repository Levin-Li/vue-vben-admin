## Context
auth.vue在主视觉p元素和页脚都绑定techSupport。
## Goals / Non-Goals
落实用户确认位置映射，不改站点配置，不改变公开品牌API，不增加替代文案。
## Decisions
删除主视觉中的重复段落，保留标题图、主图回退、右侧登录表单与页脚。使用已有组件测试确认非空技术支持仅在页脚出现，空版权/技术支持不产生分隔符。
## Risks / Trade-offs
主视觉间距随重复段落删除自然缩短，需浏览器检查布局。

## 标签页标题
实际核验发现bootstrap动态标题始终使用preferences.app.name。登录/auth区域改为订阅useAuthBrand.appName，随站点信息异步更新；后台其他路由继续使用既有应用名称，保留dynamicTitle开关。
