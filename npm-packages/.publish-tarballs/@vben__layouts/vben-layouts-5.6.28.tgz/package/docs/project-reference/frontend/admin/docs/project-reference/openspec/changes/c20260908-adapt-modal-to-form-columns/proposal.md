## Why

表单因视口和可用宽度从多列回落为一列时，普通页面的显式弹窗宽度仍被当作最小宽度，留下大面积空白。弹窗宽度应与当前有效列数同步收敛。

## What Changes

- 非严格 `modalWidth` 与用户页面展示设置中的弹窗最大宽度都改为弹窗宽度上限，而不是最低宽度。
- 表单列数回落时，弹窗按当前列数的推荐宽度收窄；空间恢复后自动恢复适合多列的宽度。
- 保留 `modalWidthStrict` 作为页面显式要求固定宽度的例外。
- 更新表单运行时规则、单元测试和 OpenSpec。

## Capabilities

### New Capabilities

- `responsive-form-modal-width`: 弹窗宽度随有效表单列数响应式收敛。

### Modified Capabilities

无。

## Impact

影响管理前端公共 CRUD 的新增和编辑弹窗。不会改变字段顺序、列数计算、接口请求或已保存的用户弹窗尺寸设置；已保存宽度改为限制内容适配后的最大值。
