# 修复上传界面设置未应用

## Summary

修复超级管理员通过“上传界面设置”保存后台基础界面配置后，服务端回传配置没有被前端应用的问题。

## Motivation

后台基础界面配置包含配置本体 `setting` 和是否优先使用服务端设置的 `preferServerSetting` 参数。服务端应按保存内容原样写入并原样返回 `uiExInfo.admin-ui-base-setting`；如果保存进去的是 `{ preferServerSetting, setting }`，后续读取也应得到同样结构。

## Scope

- 后端保存后台基础界面配置时，把请求体原样写入 `uiExInfo.admin-ui-base-setting`，不做额外同名包装。
- 后端 `tenantSiteInfo` 返回时按库中 `uiExInfo` 原样返回，不做历史嵌套结构的运行时兼容或规范化。
- 前端按当前 `{ preferServerSetting, setting }` 契约消费服务端返回，不再为历史同名嵌套结构做递归解包。
- 增加定向回归测试覆盖后端保存不额外包装。
