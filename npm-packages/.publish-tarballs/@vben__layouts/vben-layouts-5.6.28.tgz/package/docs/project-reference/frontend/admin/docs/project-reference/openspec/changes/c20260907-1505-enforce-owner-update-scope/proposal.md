## Why

Generated personal request objects intentionally do not add an owner predicate during updates. The default update controller can therefore update another owner's record when only the ID and optimistic lock are supplied.

## What Changes

- Business controllers for UserSetting, Address, and Demo preload the update target through the corresponding scoped ID request.
- A non-administrator must match the preloaded record's owner before the default update executes.
- Administrators retain the existing ability to manage records within their authorized data range.

## Impact

Changes three business controller update overrides and adds focused controller tests. No generated files, APIs, database fields, or dependencies change.
