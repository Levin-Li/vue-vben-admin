## Why

管理后台顶部的面包屑在可用宽度不足时会将标题折成多行，挤占导航与页面内容的垂直空间。面包屑是紧凑导航区域，应保持单行并在空间不足时裁切内容。

## What Changes

- 调整通用面包屑列表，使其不再自动换行或按词断行。
- 约束面包屑项及其标题在可用宽度不足时收缩并隐藏溢出内容，避免撑高顶部栏或覆盖相邻控件。
- 补充回归验证，覆盖正常与背景两种面包屑呈现方式。

## Capabilities

### New Capabilities

- `single-line-breadcrumb-display`: 管理后台面包屑以单行显示，并安全裁切超出可用宽度的标题内容。

### Modified Capabilities

- 无。

## Impact

- 受影响代码：`frontend/admin/packages/@core/ui-kit/shadcn-ui` 中的通用面包屑组件及其测试。
- 不涉及后端接口、控制器注解、权限、数据模型或新增依赖。
