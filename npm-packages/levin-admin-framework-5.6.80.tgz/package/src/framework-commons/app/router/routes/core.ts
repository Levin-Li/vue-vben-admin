import type { RouteRecordRaw } from 'vue-router';

import { LOGIN_PATH } from '@vben/constants';
import { preferences } from '@vben/preferences';

import { $t } from '@levin/admin-framework/framework-commons/app/locales';
import { resolveAdminPage } from '@levin/admin-framework/framework-commons/app/pages';

import homeRoutes from './modules/home';
import { resolveRootRedirectPath } from './root-redirect';

const BasicLayout = () =>
  import('@levin/admin-framework/framework-commons/app/layouts/basic.vue');
const AuthPageLayout = () =>
  import('@levin/admin-framework/framework-commons/app/layouts/auth.vue');

/** 全局404页面 */
const fallbackNotFoundRoute: RouteRecordRaw = {
  component: resolveAdminPage('/_core/fallback/not-found.vue'),
  meta: {
    hideInBreadcrumb: true,
    hideInMenu: true,
    hideInTab: true,
    title: '404',
  },
  name: 'FallbackNotFound',
  path: '/:path(.*)*',
};

/** 基本路由，这些路由是必须存在的 */
const coreRoutes: RouteRecordRaw[] = [
  /**
   * 根路由
   * 使用基础布局，作为所有页面的父级容器，子级就不必配置BasicLayout。
   * 此路由必须存在，且不应修改
   */
  {
    component: BasicLayout,
    meta: {
      hideInBreadcrumb: true,
      title: 'Root',
    },
    name: 'Root',
    path: '/',
    redirect: () => resolveRootRedirectPath(preferences.app.defaultHomePath),
    children: [
      ...homeRoutes.map((route) => ({
        ...route,
        meta: {
          ...route.meta,
          requiresAccess: true,
        },
      })),
      {
        name: 'PublicComponentDemosDirect',
        path: '/demos/public-components',
        redirect: '/demos/public-components/user-org-selector',
        meta: {
          hideInMenu: true,
          title: $t('demos.publicComponents'),
        },
      },
      {
        name: 'UserOrgSelectorDemosDirect',
        path: '/demos/public-components/user-org-selector',
        component: resolveAdminPage('/demos/public-components/index.vue'),
        meta: {
          hideInMenu: true,
          title: $t('demos.userOrgSelector'),
        },
      },
      {
        name: 'PermissionDemosDirect',
        path: '/demos/public-components/permissions',
        component: resolveAdminPage('/demos/public-components/permissions.vue'),
        meta: {
          hideInMenu: true,
          title: $t('demos.permissions'),
        },
      },
    ],
  },
  {
    component: AuthPageLayout,
    meta: {
      hideInTab: true,
      title: 'Authentication',
    },
    name: 'Authentication',
    path: '/auth',
    redirect: LOGIN_PATH,
    children: [
      {
        name: 'Login',
        path: 'login',
        component: resolveAdminPage('/_core/authentication/login.vue'),
        meta: {
          title: $t('page.auth.login'),
        },
      },
      {
        name: 'CodeLogin',
        path: 'code-login',
        component: resolveAdminPage('/_core/authentication/code-login.vue'),
        meta: {
          title: $t('page.auth.codeLogin'),
        },
      },
      {
        name: 'QrCodeLogin',
        path: 'qrcode-login',
        component: resolveAdminPage('/_core/authentication/qrcode-login.vue'),
        meta: {
          title: $t('page.auth.qrcodeLogin'),
        },
      },
      {
        name: 'ForgetPassword',
        path: 'forget-password',
        component: resolveAdminPage(
          '/_core/authentication/forget-password.vue',
        ),
        meta: {
          title: $t('page.auth.forgetPassword'),
        },
      },
      {
        name: 'Register',
        path: 'register',
        component: resolveAdminPage('/_core/authentication/register.vue'),
        meta: {
          title: $t('page.auth.register'),
        },
      },
    ],
  },
];

export { coreRoutes, fallbackNotFoundRoute };
