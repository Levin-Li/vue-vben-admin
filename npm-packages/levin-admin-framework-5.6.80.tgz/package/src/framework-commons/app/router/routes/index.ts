import type { RouteRecordRaw } from 'vue-router';

import { collectAdminModuleRoutes } from '@levin/admin-framework';

import { getEnabledFrontendModules } from '@levin/admin-framework/framework-commons/app/options';
import { buildCoreRouteNames } from './access-route-names';
import { coreRoutes, fallbackNotFoundRoute } from './core';
import backendPagesRoutes from './modules/backend-pages';
import demosRoutes from './modules/demos';
import myMessagesRoutes from './modules/my-messages';
import systemRoutes from './modules/system';
import vbenRoutes from './modules/vben';

// 有需要可以自行打开注释，并创建文件夹
// const externalRouteFiles = import.meta.glob('./external/**/*.ts', { eager: true });
// const staticRouteFiles = import.meta.glob('./static/**/*.ts', { eager: true });

/** 动态路由 */
const dynamicRoutes: RouteRecordRaw[] = [
  ...backendPagesRoutes,
  ...demosRoutes,
  ...myMessagesRoutes,
  ...systemRoutes,
  ...vbenRoutes,
];
const frontendModuleRoutes = collectAdminModuleRoutes(
  getEnabledFrontendModules(),
);

/** 外部路由列表，访问这些页面可以不需要Layout，可能用于内嵌在别的系统(不会显示在菜单中) */
// const externalRoutes: RouteRecordRaw[] = mergeRouteModules(externalRouteFiles);
// const staticRoutes: RouteRecordRaw[] = mergeRouteModules(staticRouteFiles);
const staticRoutes: RouteRecordRaw[] = [];
const externalRoutes: RouteRecordRaw[] = [];

/** 路由列表，由基本路由、外部路由和404兜底路由组成
 *  无需走权限验证（会一直显示在菜单中） */
const routes: RouteRecordRaw[] = [
  ...coreRoutes,
  ...externalRoutes,
  fallbackNotFoundRoute,
];

/** 基本路由列表，这些路由不需要进入权限拦截 */
const coreRouteNames = buildCoreRouteNames(coreRoutes);

/** 有权限校验的路由列表，包含动态路由和静态路由 */
const accessRoutes = [
  ...dynamicRoutes,
  ...frontendModuleRoutes,
  ...staticRoutes,
];
export { accessRoutes, coreRouteNames, routes };
export { rememberLastVisitedPath, resolveRestorablePath } from './root-redirect';
