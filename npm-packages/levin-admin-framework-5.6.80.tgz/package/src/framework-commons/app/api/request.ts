/**
 * 该文件可自行根据业务逻辑进行调整
 */
import type { RequestClientOptions } from '@vben/request';

import { useAppConfig } from '@vben/hooks';
import { preferences } from '@vben/preferences';
import {
  authenticateResponseInterceptor,
  errorMessageResponseInterceptor,
  RequestClient,
} from '@vben/request';
import { useAccessStore } from '@vben/stores';

import { message } from 'ant-design-vue';

import { useAuthStore } from '@levin/admin-framework/framework-commons/app/store';

import { createDynamicVerifyCodeInterceptor } from './dynamic-verify-code';
import { applyCurrentGlobalUserOrgContextToParams } from '../global-org-context-state';
import { emitApiRequestEvent } from './request-events';
import {
  getHttpAuthorizationMessage,
  getServiceRespMessage,
  isBusinessErrorResponse,
  isServiceResp,
  unwrapServiceResp,
} from './service-resp';

const { apiURL } = useAppConfig(import.meta.env, import.meta.env.PROD);
const REQUEST_TIMEOUT_MS = 180_000;

function getUnifiedErrorMessage(msg: string, error: any) {
  const responseData = error?.response?.data ?? {};
  const httpAuthorizationMessage = getHttpAuthorizationMessage(
    error?.response?.status,
    responseData,
  );
  if (httpAuthorizationMessage) {
    return httpAuthorizationMessage;
  }

  if (isServiceResp(responseData)) {
    return getServiceRespMessage(responseData);
  }

  const backendMessage =
    responseData?.error ??
    responseData?.msg ??
    responseData?.message ??
    responseData?.detailMsg ??
    msg;

  if (isBusinessErrorResponse(responseData)) {
    return backendMessage || '业务处理失败';
  }

  return responseData?.errorType || backendMessage || '网络或服务器异常';
}

function applyCommonInterceptors(client: RequestClient) {
  client.addResponseInterceptor(createDynamicVerifyCodeInterceptor(client));

  client.addResponseInterceptor({
    fulfilled: (response: any) => {
      const { config, data: responseData, status } = response;

      if (config.__dynamicVerifyKeepRaw) {
        emitApiRequestEvent({
          config,
          data: response,
          rawData: responseData,
          response,
        });
        return response;
      }

      if (config.responseReturn === 'raw') {
        emitApiRequestEvent({
          config,
          data: response,
          rawData: responseData,
          response,
        });
        return response;
      }

      try {
        if (status >= 200 && status < 400) {
          const data = unwrapServiceResp(responseData);
          emitApiRequestEvent({
            config,
            data,
            rawData: responseData,
            response,
          });
          return data;
        }

        throw Object.assign({}, response, { response });
      } catch (error) {
        emitApiRequestEvent({
          config,
          error,
          rawData: responseData,
          response,
        });
        throw error;
      }
    },
    rejected: (error: any) => {
      emitApiRequestEvent({
        config: error?.config ?? error?.response?.config,
        error,
        rawData: error?.response?.data,
        response: error?.response,
      });
      return Promise.reject(error);
    },
  });

  client.addResponseInterceptor(
    errorMessageResponseInterceptor((msg: string, error) => {
      if (error?.config?.__silentError) {
        return;
      }

      message.error(getUnifiedErrorMessage(msg, error));
    }),
  );
}

function createRequestClient(baseURL: string, options?: RequestClientOptions) {
  const client = new RequestClient({
    ...options,
    baseURL,
  });

  /**
   * 重新认证逻辑
   */
  async function doReAuthenticate() {
    console.warn('Access token or refresh token is invalid or expired. ');
    const accessStore = useAccessStore();
    const authStore = useAuthStore();
    accessStore.setAccessToken(null);
    if (
      preferences.app.loginExpiredMode === 'modal' &&
      accessStore.isAccessChecked
    ) {
      accessStore.setLoginExpired(true);
    } else {
      await authStore.logout();
    }
  }

  /**
   * 刷新token逻辑
   */
  async function doRefreshToken() {
    const accessStore = useAccessStore();
    const { refreshTokenApi } = await import('./core/auth');
    const resp = await refreshTokenApi();
    const newToken =
      typeof resp === 'string' ? resp : resp?.data || resp?.accessToken || '';
    accessStore.setAccessToken(newToken);
    return newToken;
  }

  function formatToken(token: null | string) {
    return token || null;
  }

  // 请求头处理
  client.addRequestInterceptor({
    fulfilled: async (config) => {
      const accessStore = useAccessStore();

      config.headers.Authorization = formatToken(accessStore.accessToken);
      config.headers['Accept-Language'] = preferences.app.locale;
      config.params = applyCurrentGlobalUserOrgContextToParams(config.params, {
        skip: config.__skipGlobalUserOrgContext === true,
      });
      return config;
    },
  });

  // token过期的处理
  client.addResponseInterceptor(
    authenticateResponseInterceptor({
      client,
      doReAuthenticate,
      doRefreshToken,
      enableRefreshToken: preferences.app.enableRefreshToken,
      formatToken,
    }),
  );

  applyCommonInterceptors(client);

  return client;
}

export const requestClient = createRequestClient(apiURL, {
  paramsSerializer: 'repeat',
  responseReturn: 'data',
  timeout: REQUEST_TIMEOUT_MS,
});

export const baseRequestClient = new RequestClient({
  baseURL: apiURL,
  paramsSerializer: 'repeat',
  responseReturn: 'data',
  timeout: REQUEST_TIMEOUT_MS,
});

applyCommonInterceptors(baseRequestClient);
