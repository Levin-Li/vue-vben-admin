<script lang="ts" setup>
import type {
  PermissionTreeNode,
  RbacMenuNode,
  RbacModuleNode,
} from './data-permission-types';

import { computed, ref, watch } from 'vue';

import { Alert, message, Modal, Spin } from 'ant-design-vue';

import { rbacService } from '../app/api/rbac-service';
import { requestClient } from '../runtime';
import {
  collectKnownPermissionTreeValues,
  collectKnownPermissionValues,
  collectPermissionValues,
  splitMappedAndUnmappedPermissions,
} from './data-permission-transform';
import ResourcePermissionTreeEditor from './resource-permission-tree-editor.vue';

const props = withDefaults(
  defineProps<{
    apiBase?: string;
    open: boolean;
    permissionField?: string;
    record: null | Record<string, any>;
    subjectLabel?: string;
    title?: string;
  }>(),
  {
    apiBase: '/Role',
    permissionField: 'permissionList',
    subjectLabel: '主体',
    title: '资源权限分配',
  },
);

const emit = defineEmits<{
  saved: [];
  'update:open': [boolean];
}>();

const detail = ref<null | Record<string, any>>(null);
const errorMessage = ref('');
const loading = ref(false);
const modules = ref<RbacModuleNode[]>([]);
const menuTree = ref<RbacMenuNode[]>([]);
const permissionTree = ref<PermissionTreeNode[]>([]);
const saving = ref(false);
const selectedPermissions = ref<string[]>([]);

const summaryText = computed(() => {
  if (!detail.value) {
    return '';
  }

  return [detail.value.name, detail.value.code].filter(Boolean).join(' / ');
});

const dialogTitle = computed(() => props.title);

const saveDisabled = computed(
  () => loading.value || saving.value || !detail.value?.id,
);

const knownPermissionValues = computed(() => {
  const treeValues = collectKnownPermissionTreeValues(permissionTree.value);
  return treeValues.size > 0
    ? treeValues
    : collectKnownPermissionValues(modules.value);
});

function closeDialog() {
  emit('update:open', false);
}

async function loadData() {
  if (!props.open || !props.record?.id) {
    return;
  }

  loading.value = true;
  errorMessage.value = '';

  try {
    const [detailResp, permissionTreeResp, modulesResp, menuTreeResp] =
      await Promise.all([
      requestClient.get<Record<string, any>>(`${props.apiBase}/retrieve`, {
        params: {
          id: props.record.id,
        },
      }),
      rbacService.fetchAuthorizedPermissionTree(),
      rbacService.fetchAuthorizedResourceModules(),
      rbacService.getAuthorizedMenuList(),
    ]);

    detail.value = detailResp;
    permissionTree.value = (permissionTreeResp || []) as PermissionTreeNode[];
    modules.value = (modulesResp || []) as RbacModuleNode[];
    menuTree.value = (menuTreeResp || []) as RbacMenuNode[];

    const permissionState = splitMappedAndUnmappedPermissions(
      detailResp[props.permissionField] || [],
      modules.value,
      permissionTree.value,
    );
    selectedPermissions.value = permissionState.mapped;
  } catch (error) {
    console.error(error);
    errorMessage.value = '加载资源权限信息失败，请稍后重试。';
  } finally {
    loading.value = false;
  }
}

async function handleSave() {
  if (!detail.value?.id) {
    return;
  }

  const permissions = collectPermissionValues(selectedPermissions.value);
  const invalidPermissions = permissions.filter(
    (permission) =>
      !permission || !knownPermissionValues.value.has(permission),
  );

  if (invalidPermissions.length > 0) {
    errorMessage.value = `存在无效权限表达式，未提交保存：${invalidPermissions.join('、')}`;
    return;
  }

  saving.value = true;

  try {
    const payload: Record<string, any> = {
      autoForceUpdateField: false,
      forceUpdateFields: [props.permissionField],
      id: detail.value.id,
      [props.permissionField]: permissions,
    };

    if (detail.value.optimisticLock !== undefined) {
      payload.optimisticLock = detail.value.optimisticLock;
    }

    await requestClient.put(`${props.apiBase}/update`, payload);
    message.success('资源权限保存成功');
    emit('saved');
    closeDialog();
  } finally {
    saving.value = false;
  }
}

watch(
  () => [props.open, props.record?.id] as const,
  ([open]) => {
    if (open) {
      loadData();
    }
  },
  {
    immediate: true,
  },
);
</script>

<template>
  <Modal
    :confirm-loading="saving"
    :mask-closable="false"
    :ok-button-props="{ disabled: saveDisabled }"
    :open="open"
    :title="dialogTitle"
    :width="1080"
    destroy-on-close
    @cancel="closeDialog"
    @ok="handleSave"
  >
    <div class="max-h-[calc(100vh-220px)] space-y-4 overflow-y-auto pr-2">
      <div class="rounded-xl bg-slate-50 px-4 py-3 text-sm text-slate-600">
        {{ summaryText || `正在加载${subjectLabel}信息...` }}
      </div>

      <Alert
        v-if="errorMessage"
        :message="errorMessage"
        show-icon
        type="error"
      />

      <Spin :spinning="loading">
        <ResourcePermissionTreeEditor
          v-model:value="selectedPermissions"
          :menu-tree="menuTree"
          :modules="modules"
          :permission-tree="permissionTree"
        />
      </Spin>
    </div>
  </Modal>
</template>
