<script lang="ts" setup>
import { computed, ref, watch } from 'vue';

import { Button, Input, Modal } from 'ant-design-vue';

import {
  DEFAULT_CONTENT_MODAL_BODY_STYLE,
  DEFAULT_CONTENT_MODAL_MAX_HEIGHT,
} from './config-helpers';

const props = withDefaults(
  defineProps<{
    disabled?: boolean;
    inline?: boolean;
    language?: string;
    modalStyle?: Record<string, any>;
    modalWidth?: number | string;
    modelValue?: string;
    title?: string;
  }>(),
  {
    disabled: false,
    inline: false,
    language: 'text',
    modalWidth: 'min(80vw, 1280px)',
    title: '内容',
  },
);

const emit = defineEmits<{
  'update:modelValue': [value: string];
}>();

const open = ref(false);
const draftValue = ref('');

const previewText = computed(() => props.modelValue || '');
const modalTitle = computed(() => `编辑${props.title}`);
const editorClass = computed(() => ({
  'font-mono': props.language !== 'rich-text',
}));
const contentModalStyle = computed(() => ({
  maxHeight: DEFAULT_CONTENT_MODAL_MAX_HEIGHT,
  ...(props.modalStyle || {}),
}));

function openEditor() {
  if (props.disabled) {
    return;
  }

  draftValue.value = props.modelValue || '';
  open.value = true;
}

function handleOk() {
  emit('update:modelValue', draftValue.value);
  open.value = false;
}

function setInlineValue(value: string) {
  draftValue.value = value;
  emit('update:modelValue', value);
}

watch(
  () => props.modelValue,
  (nextValue) => {
    if (!open.value) {
      draftValue.value = nextValue || '';
    }
  },
  { immediate: true },
);
</script>

<template>
  <Input.TextArea
    v-if="inline"
    :auto-size="{ minRows: 18, maxRows: 28 }"
    :class="editorClass"
    :disabled="disabled"
    :value="draftValue"
    @update:value="setInlineValue"
  />

  <div v-else class="crud-code-editor-field">
    <Input
      :disabled="disabled"
      placeholder="点击编辑内容"
      readonly
      :value="previewText"
      @click="openEditor"
    />
    <Button :disabled="disabled" @click="openEditor">编辑</Button>

    <Modal
      v-model:open="open"
      :body-style="DEFAULT_CONTENT_MODAL_BODY_STYLE"
      destroy-on-close
      :mask-closable="false"
      ok-text="保存"
      :style="contentModalStyle"
      :title="modalTitle"
      :width="modalWidth"
      @ok="handleOk"
    >
      <Input.TextArea
        v-model:value="draftValue"
        :auto-size="{ minRows: 18, maxRows: 28 }"
        :class="editorClass"
      />
    </Modal>
  </div>
</template>

<style scoped>
.crud-code-editor-field {
  display: flex;
  width: 100%;
  gap: 8px;
}

.crud-code-editor-field :deep(.ant-input[readonly]) {
  cursor: pointer;
}
</style>
