import type { CrudFieldConfig } from './types';

import { isSuperAdminUser } from './user-identity';

export type CrudFormMode = 'create' | 'edit';

export function isEditableControlField(field: Pick<CrudFieldConfig, 'key'>) {
  return field.key === 'editable';
}

export function shouldShowCrudFormField(
  field: CrudFieldConfig,
  mode: CrudFormMode,
  userInfo: unknown,
) {
  if (field.formVisibleForSuperAdmin && !isSuperAdminUser(userInfo)) {
    return false;
  }

  if (
    mode === 'edit' &&
    isEditableControlField(field) &&
    !isSuperAdminUser(userInfo)
  ) {
    return false;
  }

  return mode === 'edit' ? field.formEdit !== false : field.formCreate !== false;
}

export function shouldSubmitCrudFormField(
  field: Pick<CrudFieldConfig, 'omitOnEdit'>,
  mode: CrudFormMode,
) {
  return mode !== 'edit' || field.omitOnEdit !== true;
}
