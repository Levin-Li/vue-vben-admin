import type { CrudPageConfig } from '@levin/admin-framework/framework-commons/shared/types';

import { simpleApiService } from '../../api/simple-api-service';
import { buildApiMethodPermissions } from '@levin/admin-framework/framework-commons/shared/crud-permissions';

import {
  DEFAULT_CRUD_MODAL_WIDTH,
  buildDictOptionsLoader,
  buildEnumOptionsLoader,
  tenantOptionsLoader,
} from '../api-module';

const simpleApiCategoryOptionsLoader = buildDictOptionsLoader(
  'com.levin.oak.base.entities.SimpleApi.category',
);
const simpleApiTypeOptionsLoader = buildEnumOptionsLoader(
  'com.levin.oak.base.entities.SimpleApi$Type',
);
const simpleApiLanguageOptions = [{ label: 'Groovy', value: 'Groovy' }];
const httpMethodOptions = [
  { label: 'GET', value: 'GET' },
  { label: 'POST', value: 'POST' },
  { label: 'PUT', value: 'PUT' },
  { label: 'DELETE', value: 'DELETE' },
  { label: 'PATCH', value: 'PATCH' },
];
const simpleStatusOptionsLoader = buildEnumOptionsLoader(
  'com.levin.oak.base.entities.enums.SimpleFlowStatus',
);
const confidentialLevelOptionsLoader = buildEnumOptionsLoader(
  'com.levin.commons.rbac.ConfidentialLevel',
);
type FlowActionMethod =
  | 'archived'
  | 'auditApproved'
  | 'auditCommit'
  | 'auditReject'
  | 'offline'
  | 'publish';

function buildFlowAction(methodName: FlowActionMethod) {
  return async (record: Record<string, any>) =>
    simpleApiService[methodName]({
      _operatorAction: record._operatorAction,
      id: record.id,
    });
}

function buildFlowActionPermission(methodName: FlowActionMethod) {
  return buildApiMethodPermissions(simpleApiService, methodName);
}

export const pageMeta = {
  name: 'SimpleApi',
  title: '简单接口管理',
  description: '维护简单接口配置。',
} as const;

export const simpleApiPageCrudConfig: CrudPageConfig = {
  apiBase: '/SimpleApi',
  domainObject: true,
  apiService: simpleApiService,
  defaultFormValues: {
    editable: true,
    enable: true,
    language: 'Groovy',
    methods: 'POST',
    orderCode: 100,
    status: 'Draft',
    type: 'R',
  },
  defaultQuery: {
    pageIndex: 1,
    pageSize: 10,
  },
  fields: [
    {
      key: 'tenantId',
      label: '归属租户',
      loadOptions: tenantOptionsLoader,
      remoteSearch: true,
      search: true,
      type: 'select',
      visibleForPlatformUser: true,
    },
    {
      key: '__tenant',
      detail: false,
      label: '归属租户',
      fixed: 'left',
      form: false,
      table: true,
      type: 'tenant',
      visibleForPlatformUser: true,
      width: 180,
    },
    {
      key: 'id',
      label: '接口ID',
      fixed: 'left',
      form: false,
      search: true,
      table: true,
      width: 180,
    },
    {
      key: 'inType',
      label: 'API类型',
      form: false,
      loadOptions: simpleApiTypeOptionsLoader,
      multiple: true,
      search: true,
      type: 'select',
    },
    { key: 'containsName', label: '名称', form: false, search: true },
    {
      key: 'methods',
      label: 'HTTP方法',
      form: false,
      options: httpMethodOptions,
      search: true,
      type: 'select',
    },
    {
      key: 'inLanguage',
      label: '脚本语言',
      form: false,
      multiple: true,
      options: simpleApiLanguageOptions,
      search: true,
      type: 'select',
    },
    { key: 'endsWithDomain', label: '域名', form: false, search: true },
    {
      key: 'confidentialLevel',
      label: '机密等级',
      loadOptions: confidentialLevelOptionsLoader,
      search: true,
      form: false,
      type: 'select',
      valueType: 'number',
    },
    {
      key: 'inCategory',
      label: '分类',
      form: false,
      loadOptions: simpleApiCategoryOptionsLoader,
      multiple: true,
      search: true,
      type: 'select',
    },
    { key: 'containsGroupName', label: '分组名称', form: false, search: true },
    {
      key: 'inStatus',
      label: '状态',
      form: false,
      loadOptions: simpleStatusOptionsLoader,
      multiple: true,
      search: true,
      type: 'select',
    },
    {
      key: 'gteCreateTime',
      label: '创建时间开始',
      form: false,
      search: true,
      type: 'datetime',
    },
    {
      key: 'lteCreateTime',
      label: '创建时间结束',
      form: false,
      search: true,
      type: 'datetime',
    },
    { key: 'name', label: '名称', required: true, table: true, width: 180 },
    {
      key: 'type',
      label: 'API类型',
      loadOptions: simpleApiTypeOptionsLoader,
      required: true,
      table: true,
      type: 'select',
      width: 120,
    },
    {
      key: 'methods',
      label: 'HTTP方法',
      options: httpMethodOptions,
      table: true,
      type: 'select',
      width: 120,
    },
    {
      key: 'language',
      label: '脚本语言',
      options: simpleApiLanguageOptions,
      required: true,
      table: true,
      type: 'select',
      width: 120,
    },
    { key: 'domain', label: '域名', table: true, width: 140 },
    {
      key: 'confidentialLevel',
      label: '机密等级',
      loadOptions: confidentialLevelOptionsLoader,
      table: true,
      type: 'select',
      valueType: 'number',
      width: 120,
    },
    { key: 'icon', label: '图标', type: 'image' },
    {
      key: 'category',
      label: '分类',
      loadOptions: simpleApiCategoryOptionsLoader,
      table: true,
      type: 'select',
      width: 140,
    },
    { key: 'groupName', label: '分组名称', table: true, width: 140 },
    {
      key: 'status',
      label: '状态',
      loadOptions: simpleStatusOptionsLoader,
      table: true,
      type: 'select',
      width: 120,
    },
    { key: 'versionName', label: '版本号', table: true, width: 120 },
    { key: 'path', label: '访问路径', table: true, width: 220 },
    {
      key: 'enable',
      label: '是否启用',
      search: true,
      table: true,
      type: 'switch',
      valueType: 'boolean',
      width: 100,
    },
    {
      key: 'editable',
      label: '是否可编辑',
      search: true,
      table: true,
      type: 'switch',
      valueType: 'boolean',
      width: 110,
    },
    {
      key: 'requireAuthorizations',
      label: '权限或角色',
      form: false,
      fullRow: true,
      type: 'tags',
    },
    {
      key: 'content',
      label: '内容',
      form: false,
      fullRow: true,
      type: 'textarea',
    },
    { key: 'setting', label: '设置', form: false, type: 'json' },
    { key: 'auditRemark', label: '审核说明', fullRow: true, type: 'textarea' },
    { key: 'orderCode', label: '排序代码', type: 'number' },
    {
      key: 'createTime',
      label: '创建时间',
      form: false,
      table: true,
      type: 'datetime',
      width: 180,
    },
    {
      key: 'lastUpdateTime',
      label: '更新时间',
      form: false,
      table: true,
      type: 'datetime',
      width: 180,
    },
  ],
  modalWidth: DEFAULT_CRUD_MODAL_WIDTH,
  rowActions: [
    {
      handler: buildFlowAction('auditCommit'),
      label: '提交审核',
      permission: buildFlowActionPermission('auditCommit'),
    },
    {
      handler: buildFlowAction('auditReject'),
      label: '审核拒绝',
      permission: buildFlowActionPermission('auditReject'),
    },
    {
      handler: buildFlowAction('auditApproved'),
      label: '审核通过',
      permission: buildFlowActionPermission('auditApproved'),
    },
    {
      handler: buildFlowAction('publish'),
      label: '发布',
      permission: buildFlowActionPermission('publish'),
    },
    {
      handler: buildFlowAction('offline'),
      label: '下线',
      permission: buildFlowActionPermission('offline'),
    },
    {
      handler: buildFlowAction('archived'),
      label: '存档',
      permission: buildFlowActionPermission('archived'),
    },
  ],
  title: '简单接口管理',
};
