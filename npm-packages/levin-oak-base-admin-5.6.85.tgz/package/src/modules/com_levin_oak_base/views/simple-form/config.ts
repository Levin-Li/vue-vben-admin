import type { CrudPageConfig } from '@levin/admin-framework/framework-commons/shared/types';

import { simpleFormService } from '../../api/simple-form-service';
import { buildApiMethodPermissions } from '@levin/admin-framework/framework-commons/shared/crud-permissions';

import {
  DEFAULT_CRUD_MODAL_WIDTH,
  buildDictOptionsLoader,
  buildEnumOptionsLoader,
  tenantOptionsLoader,
} from '../api-module';

const simpleFormCategoryOptionsLoader = buildDictOptionsLoader(
  'com.levin.oak.base.entities.SimpleForm.category',
);
const simpleFormTypeOptionsLoader = buildEnumOptionsLoader(
  'com.levin.oak.base.entities.SimpleForm$Type',
);
const simpleStatusOptionsLoader = buildEnumOptionsLoader(
  'com.levin.oak.base.entities.enums.SimpleFlowStatus',
);
const confidentialLevelOptionsLoader = buildEnumOptionsLoader(
  'com.levin.commons.rbac.ConfidentialLevel',
);
type FlowActionMethod =
  | 'archived'
  | 'auditApproved'
  | 'auditCommit'
  | 'auditReject'
  | 'offline'
  | 'publish';

function buildFlowAction(methodName: FlowActionMethod) {
  return async (record: Record<string, any>) =>
    simpleFormService[methodName]({
      _operatorAction: record._operatorAction,
      id: record.id,
    });
}

function buildFlowActionPermission(methodName: FlowActionMethod) {
  return buildApiMethodPermissions(simpleFormService, methodName);
}

export const pageMeta = {
  name: 'SimpleForm',
  title: '简单表单管理',
  description: '维护简单表单配置。',
} as const;

export const simpleFormPageCrudConfig: CrudPageConfig = {
  apiBase: '/SimpleForm',
  domainObject: true,
  apiService: simpleFormService,
  defaultFormValues: {
    editable: true,
    enable: true,
    orderCode: 100,
    status: 'Draft',
    type: 'json',
  },
  defaultQuery: {
    pageIndex: 1,
    pageSize: 10,
  },
  fields: [
    {
      key: 'tenantId',
      label: '归属租户',
      loadOptions: tenantOptionsLoader,
      remoteSearch: true,
      search: true,
      type: 'select',
      visibleForPlatformUser: true,
    },
    {
      key: '__tenant',
      detail: false,
      label: '归属租户',
      fixed: 'left',
      form: false,
      table: true,
      type: 'tenant',
      visibleForPlatformUser: true,
      width: 180,
    },
    {
      key: 'id',
      label: '表单ID',
      fixed: 'left',
      form: false,
      search: true,
      table: true,
      width: 180,
    },
    {
      key: 'inType',
      label: '类型',
      form: false,
      loadOptions: simpleFormTypeOptionsLoader,
      multiple: true,
      search: true,
      type: 'select',
    },
    { key: 'containsName', label: '名称', form: false, search: true },
    { key: 'commitApi', label: '提交地址', form: false, search: true },
    { key: 'endsWithDomain', label: '域名', form: false, search: true },
    {
      key: 'confidentialLevel',
      label: '机密等级',
      loadOptions: confidentialLevelOptionsLoader,
      search: true,
      form: false,
      type: 'select',
      valueType: 'number',
    },
    {
      key: 'inCategory',
      label: '分类',
      form: false,
      loadOptions: simpleFormCategoryOptionsLoader,
      multiple: true,
      search: true,
      type: 'select',
    },
    { key: 'containsGroupName', label: '分组名称', form: false, search: true },
    {
      key: 'inStatus',
      label: '状态',
      form: false,
      loadOptions: simpleStatusOptionsLoader,
      multiple: true,
      search: true,
      type: 'select',
    },
    {
      key: 'gteCreateTime',
      label: '创建时间开始',
      form: false,
      search: true,
      type: 'datetime',
    },
    {
      key: 'lteCreateTime',
      label: '创建时间结束',
      form: false,
      search: true,
      type: 'datetime',
    },
    { key: 'name', label: '名称', required: true, table: true, width: 180 },
    {
      key: 'type',
      label: '类型',
      loadOptions: simpleFormTypeOptionsLoader,
      required: true,
      table: true,
      type: 'select',
      width: 120,
    },
    { key: 'commitApi', label: '提交地址', table: true, width: 220 },
    { key: 'domain', label: '域名', table: true, width: 140 },
    {
      key: 'confidentialLevel',
      label: '机密等级',
      loadOptions: confidentialLevelOptionsLoader,
      table: true,
      type: 'select',
      valueType: 'number',
      width: 120,
    },
    { key: 'icon', label: '图标', type: 'image' },
    {
      key: 'category',
      label: '分类',
      loadOptions: simpleFormCategoryOptionsLoader,
      table: true,
      type: 'select',
      width: 140,
    },
    { key: 'groupName', label: '分组名称', table: true, width: 140 },
    {
      key: 'status',
      label: '状态',
      loadOptions: simpleStatusOptionsLoader,
      table: true,
      type: 'select',
      width: 120,
    },
    { key: 'versionName', label: '版本号', table: true, width: 120 },
    { key: 'path', label: '访问路径', table: true, width: 220 },
    {
      key: 'enable',
      label: '是否启用',
      search: true,
      table: true,
      type: 'switch',
      valueType: 'boolean',
      width: 100,
    },
    {
      key: 'editable',
      label: '是否可编辑',
      search: true,
      table: true,
      type: 'switch',
      valueType: 'boolean',
      width: 110,
    },
    {
      key: 'requireAuthorizations',
      label: '权限或角色',
      form: false,
      fullRow: true,
      type: 'tags',
    },
    {
      key: 'content',
      label: '内容',
      form: false,
      fullRow: true,
      type: 'textarea',
    },
    { key: 'orderCode', label: '排序代码', type: 'number' },
    { key: 'setting', label: '设置', type: 'json' },
    { key: 'auditRemark', label: '审核说明', fullRow: true, type: 'textarea' },
    {
      key: 'createTime',
      label: '创建时间',
      form: false,
      table: true,
      type: 'datetime',
      width: 180,
    },
    {
      key: 'lastUpdateTime',
      label: '更新时间',
      form: false,
      table: true,
      type: 'datetime',
      width: 180,
    },
  ],
  modalWidth: DEFAULT_CRUD_MODAL_WIDTH,
  rowActions: [
    {
      handler: buildFlowAction('auditCommit'),
      label: '提交审核',
      permission: buildFlowActionPermission('auditCommit'),
    },
    {
      handler: buildFlowAction('auditReject'),
      label: '审核拒绝',
      permission: buildFlowActionPermission('auditReject'),
    },
    {
      handler: buildFlowAction('auditApproved'),
      label: '审核通过',
      permission: buildFlowActionPermission('auditApproved'),
    },
    {
      handler: buildFlowAction('publish'),
      label: '发布',
      permission: buildFlowActionPermission('publish'),
    },
    {
      handler: buildFlowAction('offline'),
      label: '下线',
      permission: buildFlowActionPermission('offline'),
    },
    {
      handler: buildFlowAction('archived'),
      label: '存档',
      permission: buildFlowActionPermission('archived'),
    },
  ],
  title: '简单表单管理',
};
