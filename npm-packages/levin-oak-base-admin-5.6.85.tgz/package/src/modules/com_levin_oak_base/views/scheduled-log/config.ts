import type { CrudPageConfig } from '@levin/admin-framework/framework-commons/shared/types';

import { scheduledLogService } from '../../api/scheduled-log-service';
import { DEFAULT_CRUD_MODAL_WIDTH, tenantOptionsLoader } from '../api-module';

export const pageMeta = {
  name: 'ScheduledLog',
  title: '定时任务日志管理',
  description: '查询定时任务日志。',
} as const;

export const scheduledLogPageCrudConfig: CrudPageConfig = {
  apiBase: '/ScheduledLog',
  domainObject: true,
  apiService: scheduledLogService,
  allowCreate: false,
  allowDelete: false,
  allowEdit: false,
  allowRetrieve: true,
  defaultQuery: {
    pageIndex: 1,
    pageSize: 10,
  },
  fields: [
    {
      key: 'tenantId',
      label: '归属租户',
      loadOptions: tenantOptionsLoader,
      remoteSearch: true,
      search: true,
      type: 'select',
      visibleForPlatformUser: true,
    },
    {
      key: '__tenant',
      detail: false,
      label: '归属租户',
      fixed: 'left',
      form: false,
      table: true,
      type: 'tenant',
      visibleForPlatformUser: true,
      width: 180,
    },
    {
      key: 'id',
      label: '日志ID',
      fixed: 'left',
      form: false,
      search: true,
      table: true,
      width: 180,
    },
    { key: 'taskId', label: '任务ID', search: true, table: true, width: 180 },
    {
      key: 'executionCycle',
      label: '执行周期',
      search: true,
      table: true,
      width: 180,
    },
    {
      key: 'gteCreateTime',
      label: '执行时间开始',
      form: false,
      search: true,
      type: 'datetime',
    },
    {
      key: 'lteCreateTime',
      label: '执行时间结束',
      form: false,
      search: true,
      type: 'datetime',
    },
    {
      key: 'executionSnapshot',
      form: false,
      label: '内容快照',
      fullRow: true,
      type: 'textarea',
    },
    {
      key: 'isError',
      label: '是否错误',
      search: true,
      table: true,
      type: 'switch',
      valueType: 'boolean',
      width: 100,
    },
    {
      key: 'executionResult',
      form: false,
      label: '执行结果',
      fullRow: true,
      type: 'textarea',
    },
    {
      key: 'createTime',
      label: '创建时间',
      form: false,
      table: true,
      type: 'datetime',
      width: 180,
    },
  ],
  modalWidth: DEFAULT_CRUD_MODAL_WIDTH,
  title: '定时任务日志管理',
};
