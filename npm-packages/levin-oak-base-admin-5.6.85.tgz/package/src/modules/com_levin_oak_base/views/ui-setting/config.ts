import type { CrudPageConfig } from '@levin/admin-framework/framework-commons/shared/types';

import { uiSettingService } from '../../api/ui-setting-service';
import {
  buildDictOptionsLoader,
  buildEnumOptionsLoader,
  DEFAULT_CRUD_MODAL_WIDTH,
  tenantOptionsLoader,
} from '../api-module';

const orgCategoryOptionsLoader = buildDictOptionsLoader(
  'com.levin.oak.base.entities.Org.category',
);
const orgTypeOptionsLoader = buildEnumOptionsLoader(
  'com.levin.oak.base.entities.Org$Type',
);
const userCategoryOptionsLoader = buildEnumOptionsLoader(
  'com.levin.oak.base.entities.User$Category',
);
const userTypeOptionsLoader = buildDictOptionsLoader(
  'com.levin.oak.base.entities.User.type',
);

function transformUiSettingSubmit(
  values: Record<string, any>,
  record: null | Record<string, any>,
) {
  if (record || values.editable !== undefined) {
    return values;
  }

  return {
    ...values,
    editable: true,
  };
}

export const pageMeta = {
  name: 'UiSetting',
  title: '界面设置管理',
  description: '维护界面设置。',
} as const;

export const uiSettingPageCrudConfig: CrudPageConfig = {
  apiBase: '/UiSetting',
  domainObject: true,
  apiService: uiSettingService,
  defaultFormValues: {
    editable: true,
    enable: true,
    orderCode: 100,
  },
  defaultQuery: {
    pageIndex: 1,
    pageSize: 10,
  },
  fields: [
    {
      key: 'tenantId',
      label: '归属租户',
      layoutGroup: 'scope',
      layoutGroupTitle: '适用范围',
      layoutOrder: 10,
      loadOptions: tenantOptionsLoader,
      remoteSearch: true,
      search: true,
      type: 'select',
      visibleForPlatformUser: true,
    },
    {
      key: '__tenant',
      detail: false,
      label: '归属租户',
      fixed: 'left',
      form: false,
      table: true,
      type: 'tenant',
      visibleForPlatformUser: true,
      width: 180,
    },
    {
      key: 'id',
      label: '界面设置 ID',
      fixed: 'left',
      form: false,
      search: true,
      table: true,
      width: 180,
    },
    { key: 'containsName', label: '名称', form: false, search: true },
    { key: 'code', label: '设置项编码', form: false, search: true },
    { key: 'domain', label: '域名', form: false, search: true },
    {
      key: 'orgCategory',
      label: '组织类别',
      form: false,
      loadOptions: orgCategoryOptionsLoader,
      search: true,
      type: 'select',
    },
    {
      key: 'orgType',
      label: '组织类型',
      form: false,
      loadOptions: orgTypeOptionsLoader,
      search: true,
      type: 'select',
    },
    {
      key: 'userCategory',
      label: '用户类别',
      form: false,
      loadOptions: userCategoryOptionsLoader,
      search: true,
      type: 'select',
    },
    {
      key: 'userType',
      label: '用户类型',
      form: false,
      loadOptions: userTypeOptionsLoader,
      search: true,
      type: 'select',
    },
    {
      key: 'name',
      label: '名称',
      layoutGroup: 'scope',
      layoutOrder: 15,
      required: true,
      table: true,
      width: 180,
    },
    {
      key: 'code',
      label: '设置项编码',
      layoutGroup: 'scope',
      layoutOrder: 18,
      required: true,
      table: true,
      width: 180,
    },
    {
      key: 'type',
      label: '设置项类型',
      layoutGroup: 'scope',
      layoutOrder: 19,
      table: true,
      width: 140,
    },
    {
      key: 'domain',
      label: '域名',
      layoutGroup: 'scope',
      layoutOrder: 20,
      table: true,
      width: 180,
    },
    {
      key: 'orgCategory',
      label: '组织类别',
      layoutGroup: 'scope',
      layoutOrder: 30,
      loadOptions: orgCategoryOptionsLoader,
      table: true,
      type: 'select',
      width: 140,
    },
    {
      key: 'orgType',
      label: '组织类型',
      layoutGroup: 'scope',
      layoutOrder: 40,
      loadOptions: orgTypeOptionsLoader,
      table: true,
      type: 'select',
      width: 140,
    },
    {
      key: 'userCategory',
      label: '用户类别',
      layoutGroup: 'scope',
      layoutOrder: 50,
      loadOptions: userCategoryOptionsLoader,
      table: true,
      type: 'select',
      width: 140,
    },
    {
      key: 'userType',
      label: '用户类型',
      layoutGroup: 'scope',
      layoutOrder: 60,
      loadOptions: userTypeOptionsLoader,
      table: true,
      type: 'select',
      width: 140,
    },
    {
      key: 'editor',
      label: '值编辑器',
      fullRow: true,
      layoutNewRow: true,
      layoutOrder: 10,
      type: 'text',
    },
    {
      key: 'valueContent',
      label: '内容值',
      form: false,
      table: false,
      type: 'json',
    },
    {
      key: 'orderCode',
      label: '排序代码',
      layoutGroup: 'status',
      layoutOrder: 10,
      type: 'number',
    },
    {
      key: 'enable',
      label: '是否启用',
      layoutGroup: 'status',
      layoutOrder: 20,
      search: true,
      table: true,
      type: 'switch',
      valueType: 'boolean',
      width: 100,
    },
    {
      key: 'editable',
      label: '是否可编辑',
      layoutGroup: 'status',
      layoutOrder: 30,
      search: true,
      table: true,
      type: 'switch',
      valueType: 'boolean',
      width: 110,
    },
    {
      key: 'createTime',
      label: '创建时间',
      form: false,
      table: true,
      type: 'datetime',
      width: 180,
    },
    {
      key: 'lastUpdateTime',
      label: '更新时间',
      form: false,
      table: true,
      type: 'datetime',
      width: 180,
    },
    {
      key: 'remark',
      label: '备注',
      fullRow: true,
      layoutOrder: 10,
      type: 'textarea',
    },
  ],
  formMaxColumns: 3,
  modalWidth: DEFAULT_CRUD_MODAL_WIDTH,
  title: '界面设置管理',
  transformSubmit: transformUiSettingSubmit,
};
