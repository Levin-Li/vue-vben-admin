<script lang="ts" setup>
import { computed } from 'vue';
import { useRouter } from 'vue-router';

import { buildApiMethodPermissions } from '@levin/admin-framework/framework-commons/shared/crud-permissions';
import { tenantSiteService } from '../../api/tenant-site-service';

import CrudPage from '../crud-page.vue';
import { tenantSitePageCrudConfig } from './config';

const router = useRouter();

const pageConfig = computed(() => ({
  ...tenantSitePageCrudConfig,
  rowActions: [
    ...(tenantSitePageCrudConfig.rowActions || []),
    {
      confirmText: '确认生成当前站点的NG配置吗？',
      handler: async (record: Record<string, any>) => {
        return tenantSiteService.generateNginxConfig(String(record.id || ''));
      },
      label: '生成NG配置',
      permission: buildApiMethodPermissions(
        tenantSiteService,
        'generateNginxConfig',
      ),
      visible: canGenerateSiteFiles,
    },
    {
      confirmText: '确认生成当前站点的证书文件吗？',
      handler: async (record: Record<string, any>) => {
        return tenantSiteService.generateSslCertFiles(String(record.id || ''));
      },
      label: '生成证书文件',
      permission: buildApiMethodPermissions(
        tenantSiteService,
        'generateSslCertFiles',
      ),
      visible: canGenerateSiteFiles,
    },
    {
      handler: async (record: Record<string, any>) => {
        await router.push({
          path: '/clob/V1/DomainSslCert',
          query: {
            action: 'apply',
            domain: normalizeSiteHost(String(record.domain || '')),
          },
        });
      },
      label: '申请SSL证书',
      visible: canApplySslCert,
    },
  ],
}));

function canGenerateSiteFiles(record: Record<string, any>) {
  const domain = String(record?.domain || '').trim();
  return Boolean(record?.id && domain && !isLocalHostDomain(domain));
}

function canApplySslCert(record: Record<string, any>) {
  const domain = String(record?.domain || '').trim();
  return Boolean(record?.id && domain && !isLocalHostDomain(domain));
}

function isLocalHostDomain(domain: string) {
  const host = normalizeSiteHost(domain);
  return (
    host === 'localhost' ||
    host.endsWith('.localhost') ||
    host === '::1' ||
    host === '0:0:0:0:0:0:0:1' ||
    host === '0.0.0.0' ||
    host === '127.0.0.1' ||
    host.startsWith('127.')
  );
}

function normalizeSiteHost(domain: string) {
  let host = domain.trim().toLowerCase();

  try {
    host = new URL(host.includes('://') ? host : `http://${host}`).hostname;
  } catch {
    host = host.split('/')[0] || '';
  }

  host = host.replace(/^\[(.*)]$/, '$1');
  return host.replace(/\.$/, '');
}
</script>

<template>
  <CrudPage :config="pageConfig" />
</template>
