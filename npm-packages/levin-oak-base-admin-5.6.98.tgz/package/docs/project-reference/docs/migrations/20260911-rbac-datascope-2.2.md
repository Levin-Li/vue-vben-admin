# service-support 2.2 DataScope 数据迁移

本版本不读取、转换或写回旧 `SimpleOrgScope` JSON。升级前执行同目录
`20260911-rbac-datascope-2.2-preflight.sql`；它会补齐新增 JSON 列，并在发现旧对象数组时停止。

旧组织规则不能一律自动转换：`_USER_ORG_`、`IdPath`、`NamePath`、`Groovy`、SpringEL 和租户匹配表达式都依赖运行时对象或脚本语义。自动猜测会造成权限扩大，因此必须人工确认。

人工转换规则：

- 六个新字段均允许 `null`（继承角色）或 `[]`（显式为空）。
- 静态组织规则写为 `起点组织ID|匹配模式`；匹配模式仅使用 `Self`、`DirectChild`、`SelfAndDirectChild`、`SelfAndAllChild`。
- 旧允许规则写入 `org_scope_list`，旧拒绝规则写入 `denied_org_scope_list`。
- `_ALL_ROOT_`、`_DEFAULT_`、`_NONE_` 只能在确认操作者实际拥有对应范围时使用。
- 租户和领域范围分别写入四个独立字段；不要把旧租户表达式嵌入组织字符串。

转换后重新运行预检脚本，确认没有对象型 `org_scope_list`，再部署应用。保留迁移前备份以便回滚。
