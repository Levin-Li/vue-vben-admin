# 六项安全修复验收（2026-09-09）

## 范围及结论

本轮修复用户确认的六项问题：操作绑定、MFA 重用、安全服务缺失放行、限流故障放行、短信邮箱随机性/防刷、请求体无限读取。原业务页面不增加验证代码；公共上传仅在挑战后编码，未触发验证的上传保持原传输方式。

六项对应实现和验收已完成。没有修改实体模型、用户 MFA 密钥、根 revision 或外部项目；没有新增依赖。完整配置及自定义插件升级要求见 [安全加固说明](../../../docs/URL访问控制安全加固说明.md)。本结论不覆盖既有全量前端类型错误、业务自身幂等性、响应体大小或任意多验证类型组合。

## 受影响入口

| 范围 | 变化与保护 |
| --- | --- |
| 所有命中动态验证码 ACL 的业务接口 | 服务器随机 VerifyId，绑定主体/登录会话/当前域租户/Host/应用/类型/方法/path/query/真实正文；有限尝试并原子消费 |
| 普通短信、邮箱验证码及 scoped 验证 | SecureRandom 6–12 位；按收件人发送和尝试限额；按租户/类型总发送配额；scope 缓存隔离 |
| 普通及 scoped 图片/行为验证码 | 隔离操作作用域；行为验证码失败不复活已消费状态，采用 watchdog 锁 |
| MFA 登录及操作验证 | Redis 一次性消费；跨 app、scope、账号别名共享；失败或 Redis 不可用拒绝 |
| URL ACL 签名/加密接口 | 委托缺失 503；真实有界摘要，客户端 RequestHash 不可信；加密明文再次检查上限 |
| 所有命中流量规则的接口 | 引擎/Redis故障、无效阈值、无实现算法均 503；正常限额 429；Redis 原子计数和 TTL |
| 客户端应用认证入口 | 前置读流同上限；有界解析后拒绝表单/multipart 混入用户 token，身份上下文覆盖下游并最终恢复 |

主体、会话和域租户来自已验证服务端上下文。查询串和正文仅参与摘要绑定，不被解释为脚本/SQL。请求体限制在参数解析前执行；对候选安全路径保守执行大小限制，不以用户/IP条件绕过读流保护。

## 自动化证据

JDK 25、Maven env0-local；已显式启用测试。以下均 BUILD SUCCESS，无失败/错误/跳过：

```sh
ACL_REDIS_TEST_URL=redis://127.0.0.1:6379 mvn -Penv0-local -pl admin-api,services-impl -am test -Dmaven.test.skip=false -DskipTests=false -Dtest='UrlAcl*,DefaultUrlAcl*,TrafficControl*,RedissonFixedWindow*,GoogleMfa*,DefaultSms*,DefaultEmail*,AbstractCaptcha*,OtpSecurity*,DefaultHmi*,ClientAppAuthFilterTest,BizAclTestControllerTest' -Dsurefire.failIfNoSpecifiedTests=false
ACL_REDIS_TEST_URL=redis://127.0.0.1:6379 mvn -Penv0-local -pl admin-api -am test -Dmaven.test.skip=false -DskipTests=false -Dtest='UrlAcl*,DefaultUrlAcl*,TrafficControl*,RedissonFixedWindow*,ClientAppAuthFilterTest,BizAclTestControllerTest' -Dsurefire.failIfNoSpecifiedTests=false
ACL_REDIS_TEST_URL=redis://127.0.0.1:6379 mvn -Penv0-local -pl web-commons -am test -Dmaven.test.skip=false -DskipTests=false -Dtest=RateLimitEngineRegistrationTest,TrafficControlInterceptorTest,RedissonFixedWindowRateLimitEngineTest -Dsurefire.failIfNoSpecifiedTests=false
```

首组结果为 services-impl 90 项、web-commons 150 项、admin-api 6 项。补充上下文/域租户绑定回归后 web-commons 156 项、admin-api 6 项通过；新增装配测试组 14 项通过（包含已经覆盖的限流用例，不能直接累加为总数）。真实 Redis 用例实际执行：挑战跨实例并发只能消费一次、过期/有限尝试；限流 40 并发限 5、无 TTL 修复及窗口恢复。

前端在 frontend/admin 执行：

```sh
pnpm exec vitest run packages/business/admin-framework/src/framework-commons/app/api/__tests__/dynamic-verify-code.test.ts packages/business/admin-framework/src/framework-commons/app/api/__tests__/global-org-request.test.ts packages/business/oak-base-admin/src/modules/com_levin_oak_base/views/acl-test/__tests__
```

5 文件 43 项通过。包括 JSON/DELETE 和 multipart POST/DELETE 的待决、确认、两种取消；Apply/Verify 二进制与 boundary 一致；普通上传不提前整包读取；503/413/429 不误触发退出登录。新增 helper 和 request 接入 lint 通过；旧动态组件及既有测试的样式 lint、全量类型问题未作为本轮修复目标。两个 Git 仓库 diff --check 通过。

## 真实 HTTP/浏览器证据

实际后端连接独立 acl_test_20260909，仍关闭自动 DDL 和无关定时任务。没有暂停共享 Redis 进行故障演练；依赖异常使用测试注入验证，真实 Redis 验证正常原子语义。

`python3 scripts/qa/security-live-smoke.py` 全部通过：

- 改正文、伪造 RequestHash、改 query、换验证类型均不能使用原挑战。
- 发送间隔拒绝新申请，原挑战仍可正常验证。
- 同一有效挑战四并发只成功一次，后续重放拒绝。
- 未签发的可计算摘要无法当作 VerifyId。
- 恰好 1 MiB 的合法签名 JSON 完整回显。
- 已知长度与未知长度/chunked 超限均 413/no-store；额外实测携带 X-Client-* 的前置认证请求超限同样 413。

`python3 scripts/qa/acl-live-smoke.py run` 全部通过：五类匿名未验证拒绝；短信/邮箱模拟正确、错误、单次消费；MFA 独立算法成功后申请新作用域，同一有效码再次提交被拒绝（脚本断言仍处 SDK 接受窗口）；Hmi 返回真实 scoped 题面；签名正常、错误、篡改、过期、重放。

浏览器重新加载公共代码后，真实 MFA 登录成功；短信/邮箱六位模拟码通过随机操作挑战并回显；新的 MFA 码正常通过，重用码被拒绝；Hmi 新挑战题面显示正常，取消不返回业务成功。本轮没有重新完成 Hmi 浏览器点选，新增 Hmi scope/并发消费由服务层回归覆盖；此前点选链路证据保留在前轮记录中，不混淆验证范围。

最终 `python3 scripts/qa/traffic-live-smoke.py` 九组再次全部通过：3秒/3次阈值、429与恢复、停用、条件不匹配、路径排除、Header/Param分桶、20并发仅5成功、租户隔离。另直接读实际 Redis `traffic-control:<本次规则>-concurrent` 为 20，确认不是本地计数降级。

## 调试中发现并闭环的问题

- Redisson 4.3.0 RScript 返回类型为 LIST，修正旧常量后编译通过。
- 过滤器不能无条件读取尚未建立的 Sa-Token 上下文；只在需要身份时使用有界请求建立/恢复作用域，新增真实上下文回归。
- 全局用户的 operator.tenantId 可能为空，挑战额外绑定当前域租户及 Host，避免跨域使用。
- 默认 Redis 限流引擎不使用过早的 ConditionalOnBean 判断。移入独立 RateLimitConfiguration，由原 MVC 配置显式 Import，晚注册的 Redis 可正常注入；缺 Redis仍拒绝，不恢复自动本地降级。
- 直接重编码所有普通上传会增加内存开销，已改为轻量条目快照，只有挑战后才编码一次。

## 升级注意

旧在途挑战需要重新申请；自定义验证码插件须实现 verifyScoped；刚用于登录的 MFA 码不能再用于另一操作。默认受保护请求体上限 1 MiB，可通过正值配置调整。故障不再放行，旧 TokenBucket 占位规则不会静默按 FixedWindow 执行。本轮未发布或提交代码。
