# 最佳匹配编译与验证结果

## 实现

- BizUiSettingServiceImpl、BizTenantCustomMenuServiceImpl、BizOpenAreaServiceImpl 的 findBestMatch 统一委托对应标准服务，删除业务层重复条件/排序。
- OpenArea 补充 SelfOverridableObject 元数据，实体 clean/compile 后运行生成器成功，生成标准最佳匹配方法；保留原行政编码校验能力。
- ClientApp 获取统一使用标准 findBestMatch，主键映射后的应用认证、Demo初始化和测试夹具同步更新。Demo主键由标准创建流程生成。
- 证书 domain 已不可更新，移除业务更新中的重复设置及测试模拟中的旧getter引用。
- 通用历史服务单参数 snapshot(Object) 与恢复代码完成编译及回归。

## 验证

运行环境 JDK25（Corretto 25.0.2），profile env0-local。

完整编译：`mvn -U -Penv0-local compile -DskipTests`。根项目及10个后端模块全部成功，包括管理/客户端启动模块。

定向测试：`mvn -Penv0-local -pl services-impl,admin-api -am test -Dmaven.test.skip=false -DskipTests=false -Dtest=ClientAppCredentialDefaultsTest,BizUiSettingServiceImplTest,BizTenantCustomMenuServiceImplTest,BizSettingHistoryServiceImplTest,BizClientAppAuthServiceImplTest,DefaultUrlAclSecurityServiceTest,UrlAclSecurityFullChainMockMvcTest,ModuleDataInitializerTest,BizDomainSslCertServiceImplTest,BizAreaServiceImplTest,RbacResServiceImplTest -Dsurefire.failIfNoSpecifiedTests=false`。

结果：entities 2项、services-impl 54项、web-commons 23项、admin-api 2项，共81项通过，0失败、0错误、0跳过。生成器导入缺陷已由用户修复，本轮未修改相邻项目。

未重启服务、未执行业务数据库迁移、未进行浏览器验收。本结果不代表全量测试或前端类型检查全部通过。生成目录中其他既存格式问题未手工修订。
