# @levin/oak-base-admin

Levin Oak 基础后台前端业务模块，提供 `com.levin.oak.base` 的基础管理页面、API service、页面注册表、后端菜单路由映射和国际化资源。本包依赖 `@levin/admin-framework` 的基础组件和公共运行时能力。

## 安装

```bash
pnpm add @levin/admin-framework@5.6.45 @levin/oak-base-admin@5.6.43
```

## 启用

```ts
import type { AdminFrontendModule } from '@levin/admin-framework';

import { createOakBaseAdminModule } from '@levin/oak-base-admin';

export const enabledFrontendModules: AdminFrontendModule[] = [
  createOakBaseAdminModule(),
];
```

默认 API 前缀为 `/com.levin.oak.base/V1/api`，默认 CRUD 父级路由为 `/clob/V1/index`，子页面路由为 `/clob/V1/<Resource>`。真实菜单应以后端当前用户授权菜单为准，前端根据菜单路径匹配模块注册页面。上传页面路由时，模块 ID 必须使用后端 Java 根 POM 约定的模块包名 `com.levin.oak.base`，不能由前端自定义；前端目录名使用 `com_levin_oak_base`，短包名 `clob` 只用于后端菜单路径。用户可见展示名称如果后端 Java 根 POM 配置了中文名称，应优先使用该中文名称。

包的正式入口指向 `dist` 构建结果；随包携带的 `src` 只用于源码查看、调试和问题定位，不应通过 `@levin/oak-base-admin/src/...` 参与第三方应用编译。

基础组件项目第三方使用手册见 `@levin/admin-framework` 包内的 `src/framework-commons/docs/第三方用户手册.md`；本模块补充手册见 `src/modules/com_levin_oak_base/docs/第三方用户手册.md`。发布包会携带 `src`，构建后的 `dist/modules/com_levin_oak_base/docs/第三方用户手册.md` 也会包含同一份手册，第三方项目可在安装后的 `node_modules/@levin/oak-base-admin` 下查看。

## 子项目开发规范

使用本包进行二次开发、配置、扩展或升级的子项目，必须遵循包内的[模块使用与二次开发规范](docs/MODULE-DEVELOPMENT-STANDARD.md)。该规范不要求子项目采用本包发布方的代码包名、源码目录或业务实现。

## 模块开发与设计资料

使用本模块的子项目必须遵循 [模块开发规范](docs/MODULE-DEVELOPMENT-STANDARD.md)。[项目设计和开发参考资料](docs/project-reference/INDEX.md) 提供发布方的设计、需求及规则背景，不构成下游强制约束。
