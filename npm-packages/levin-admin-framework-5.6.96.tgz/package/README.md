# @levin/admin-framework

Levin 后台基础组件和公共运行时框架包，面向第三方后台系统提供应用启动、布局、路由、权限、菜单同步、通用 CRUD、页面注册、页面覆盖、事件总线、顶部栏扩展区和窗口级可拖拽悬浮面板等基础能力。

## 安装

```bash
pnpm add @levin/admin-framework@5.6.45
```

通常还会按业务需要安装基础模块：

```bash
pnpm add @levin/oak-base-admin@5.6.43
```

## 使用方式

第三方最终应用应保持薄宿主结构，只负责启动、配置后端地址、启用模块、主题偏好和页面覆盖。公共框架和业务模块通过 npm 私服包安装，不建议复制源码长期集成。包的正式入口指向 `dist` 构建结果；随包携带的 `src` 只用于源码查看、调试和问题定位，不应通过 `@levin/admin-framework/src/...` 参与第三方应用编译。

```ts
import {
  configureAdminApplication,
  defineAdminPageOverrides,
  type AdminPageMap,
} from '@levin/admin-framework';

const pageOverrides = defineAdminPageOverrides(
  import.meta.glob('./pages/**/*.vue') as AdminPageMap,
);

configureAdminApplication({
  modules: enabledFrontendModules,
  pageOverrides,
});
```

完整第三方使用手册见 `src/framework-commons/docs/第三方用户手册.md`。发布包会携带 `src`，构建后的 `dist/framework-commons/docs/第三方用户手册.md` 也会包含同一份手册，第三方项目可在安装后的 `node_modules/@levin/admin-framework` 下查看。

组件专用文档位于包根 `docs/components/`，例如 [UserOrgSelector 用户与组织选择器](docs/components/user-org-selector.md)。该目录随 npm tarball 发布，适合第三方项目直接阅读，无需依赖 `src` 或 `dist` 的构建布局。

全局选中记录、组织 ID、用户 ID 和变化监听的用法见[全局组织与用户选择器：选中状态使用说明](docs/global-user-org-context.md)。

## 子项目开发规范

使用本包进行二次开发、配置、扩展或升级的子项目，必须遵循包内的[模块使用与二次开发规范](docs/MODULE-DEVELOPMENT-STANDARD.md)。该规范不要求子项目采用本包发布方的代码包名、源码目录或业务实现。

## 模块开发与设计资料

使用本模块的子项目必须遵循 [模块开发规范](docs/MODULE-DEVELOPMENT-STANDARD.md)。[项目设计和开发参考资料](docs/project-reference/INDEX.md) 提供发布方的设计、需求及规则背景，不构成下游强制约束。

公共组件：[通用行为验证码组件](docs/behavior-captcha.md)，登录与 API 二次验证共用，包含操作指引、题面刷新和验证结果事件。
